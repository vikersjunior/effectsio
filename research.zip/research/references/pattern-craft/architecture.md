# Pattern Craft — Architecture & Component Structure

- **Framework**: Next.js + Tailwind CSS.
- **State Management**: Zustand store managing active pattern category, foreground color, background color, scale ($4\text{px}$ to $128\text{px}$), stroke width, and rotation angle ($0^{\circ}$ to $360^{\circ}$).
- **Export Modalities**:
  1. Tailwind CSS config snippet.
  2. Pure CSS snippet.
  3. Raw SVG code snippet.
  4. Data URL (`data:image/svg+xml;utf8,...`).
  5. High-resolution PNG raster download ($1920\times 1080$, $4K$).
