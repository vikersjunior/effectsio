# Pattern Craft — Product & Feature Inventory

- **Repository**: `https://github.com/megh-bari/pattern-craft`
- **Demo URL**: `https://patterncraft.fun/`
- **License**: MIT License (Open Source)
- **Category**: Procedural CSS & SVG Pattern Generator
- **Core Value Proposition**: High-performance, zero-runtime procedural background patterns for modern web applications and UI surfaces.

## Pattern Catalog (100+ Procedural Variations)
- **Grid Systems**: Square grid, dot grid, cross grid, diamond grid, isometric grid.
- **Geometric Weaves**: Herringbone, houndstooth, tartan, chevron, basketweave.
- **Radial & Harmonic**: Concentric circles, radial spokes, Archimedean spirals, moiré interference.
- **Modern Tech / Abstract**: Hexagonal honeycomb, circuit board traces, halftone dots, topography contours.
