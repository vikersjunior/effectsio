# Pattern Craft — Source Code Audit & Insights

## Key Files
- `src/data/patterns.ts`: Comprehensive dictionary of pattern generators with dynamic parameter interpolators.
- `src/components/PatternPreview.tsx`: Live responsive viewport with zoom and pan.
- `src/components/Controls.tsx`: Color pickers, scale sliders, and opacity adjustments.

## Value for EffectsIO
Provides the complete mathematical and parametric foundation for EffectsIO's **Generative Pattern Sub-Layers** (allowing users to add procedural dot grids, lines, and textures underneath or over image frames).
