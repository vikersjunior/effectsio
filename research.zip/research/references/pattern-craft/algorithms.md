# Pattern Craft — Procedural Pattern Algorithms

## SVG Tiling Engine
Every pattern is constructed as an infinitely repeatable SVG `<pattern>` element defined within `<defs>`:

```xml
<pattern id="dot-grid" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">
  <circle cx="12" cy="12" r="1.5" fill="var(--pattern-foreground)" />
</pattern>
```

## Pure CSS Gradient Tiling
For zero-DOM environments, Pattern Craft synthesizes multi-stop linear and radial gradients:

```css
background-color: #0f172a;
background-image: 
  radial-gradient(circle at 1px 1px, #38bdf8 1px, transparent 0),
  radial-gradient(circle at 21px 21px, #38bdf8 1px, transparent 0);
background-size: 40px 40px;
```
