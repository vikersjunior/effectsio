# Pryzm Studio — Multi-Layer Rendering Pipeline

## Compositing Equation
The final frame $F(x, y)$ is evaluated as:

$$F(x, y) = \text{Blend}\Big(\mathbf{L}_{\text{pattern}}(x, y), \text{Blend}\big(\mathbf{L}_{\text{image}}(x, y), \mathbf{L}_{\text{gradient}}(x, y), M_{\text{image}}\big), M_{\text{pattern}}\Big)$$

Where $M_{\text{layer}}$ represents the layer's alpha mask or luminance clipping path. The entire stack is then fed into the global post-processing rail:
- Optics (Lens distortion, chromatic dispersion)
- Glass (Refraction normal map)
- ASCII / Dither / Halftone / Film Grain
