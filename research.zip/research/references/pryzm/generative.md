# Pryzm Studio — Generative Patterns & Bento Masking

## Bento Grid & Pattern Generators
- **Bento Grid**: Procedural rectangular mosaic with adjustable gutter width ($0\text{px}$ to $32\text{px}$), corner radius ($0\text{px}$ to $48\text{px}$), and aspect ratio distribution.
- **Mosaic Tiles**: Polygonal tessellations where each tile samples luminance from the underlying Image Layer and modulates its fill color or opacity.
- **Plaid Weave**: Intersecting horizontal and vertical color bands with variable alpha blending (`multiply`, `screen`, `overlay`).
