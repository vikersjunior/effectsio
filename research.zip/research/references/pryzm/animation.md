# Pryzm Studio — Seamless Loop Animation Engine

## Time Loop Mechanics
- User specifies duration $T \in [2.0\text{s}, 10.0\text{s}]$ and frame rate ($30$ or $60\text{fps}$).
- All procedural generators (waves, noise, rotation, optical flicker) use circular phase parameterization:

$$\theta(t) = \frac{2\pi t}{T}, \quad t \in [0, T)$$
$$\text{noise}(x, y, t) = \text{snoise4D}(x, y, R \cos\theta, R \sin\theta)$$

By embedding time into a 2D circle $(R\cos\theta, R\sin\theta)$ in 4D simplex noise space, the animation achieves perfect mathematical loop closure without seam blending.
