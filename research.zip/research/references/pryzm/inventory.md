# Pryzm Studio — Product & Feature Inventory

- **URL**: `https://pryzm.design/studio`
- **Category**: Layered Graphic & Motion Compositor
- **Target Audience**: Motion graphic designers, brand agencies, creative coders.
- **Core Value Proposition**: A rigid, highly intuitive 3-tier compositing pipeline allowing seamless blending of procedural gradients, photographic base assets, and mosaic/bento pattern masks with loopable video exports.

## 3-Tier Layer Pipeline Model
```
┌────────────────────────────────────────────────────────┐
│                   3. PATTERN LAYER                     │
│      (Bento Grid, Halftone Mosaic, Voronoi Mask)       │
├────────────────────────────────────────────────────────┤
│                    2. IMAGE LAYER                      │
│        (Base Photography, Textures, Alpha Cutout)      │
├────────────────────────────────────────────────────────┤
│                   1. GRADIENT LAYER                    │
│      (Underlying Ramp, Noise Waves, OKLab Flow)        │
└────────────────────────────────────────────────────────┘
```
