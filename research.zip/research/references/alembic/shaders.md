# Alembic Shader Lab — Shader Uniform Architecture (Cleanroom)

## Cleanroom Uniform Schema Design
In cleanroom architectural terms, multi-pass post-processing shaders conform to a standardized uniform buffer layout:

```glsl
// Standard Cleanroom Uniform Interface
uniform sampler2D u_image;       // Source image buffer
uniform sampler2D u_texture;     // Procedural displacement/LUT texture
uniform vec2      u_resolution;  // Viewport dimensions in pixels
uniform float     u_time;        // Elapsed time in seconds
uniform float     u_intensity;   // Normalized effect strength [0, 1]
uniform float     u_scale;       // Spatial frequency scale
uniform vec2      u_offset;      // Spatial translation offset
uniform vec4      u_tint;        // Color grading tint / tint mode
```
