# Alembic Shader Lab — Technical Deconstruction & Epistemic Audit

- **Frontend Framework**: Next.js (React 18) with client-side Three.js / WebGL2 rendering.
- **UI Architecture**: Tailwind CSS + custom dark HUD layout.
- **Command Palette (`Cmd+K`)**: Highly efficient developer UX allowing direct keyboard execution without searching through nested menus.
- **Key Takeaways for EffectsIO**:
  1. The immense visual demand for **physical glass materials** (pressed glassware, brick lattices, frosted panes).
  2. The unique aesthetic power of **chemical degradation shaders** (toner melt, water damage, LCD leak).
  3. The superiority of a **ping-pong FBO multi-pass compositor** for chaining disparate shader effects.
