# Alembic Shader Lab — Motion & Modulation

## Temporal Dynamics
- Uniform `u_time` advances continuously on `requestAnimationFrame`.
- Shaders implement looping drift using sinusoidal temporal modulation or periodic domain-wrapped coordinates.
- Interactive pointer uniforms (`u_mouse`, `u_mouse_velocity`) allow tactile physical fluid dragging.
