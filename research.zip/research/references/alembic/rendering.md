# Alembic Shader Lab — Multi-Pass Pipeline Architecture

## Pass Graph Topology
Alembic processes layers sequentially using two alternating WebGL2 Framebuffer Objects (Ping-Pong FBOs):

```
Base Image ──► [FBO A] ──► Pass 1 (e.g. Glass Refraction) ──► [FBO B]
                             │
                             ▼
               [FBO B] ──► Pass 2 (e.g. Toner Melt)       ──► [FBO A]
                             │
                             ▼
               [FBO A] ──► Pass 3 (e.g. Paper Texture)    ──► Screen
```
Each pass renders a fullscreen quad (`vec2(-1, -1)` to `vec2(1, 1)`), executing its fragment shader and writing into the opposite FBO.
