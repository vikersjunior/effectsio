# Alembic Shader Lab — Product & Feature Inventory

- **URL**: `https://lab.alembic.space/`
- **Creator**: Lauri Paronen
- **Legal Status**: **PROPRIETARY / CLOSED SOURCE**
- **Strict Extraction Standard**: **CLEANROOM ANALYSIS ONLY**. In strict accordance with Project Invariants and Alembic TOS, zero proprietary shader code is duplicated. All concepts, uniform architectures, multi-pass topologies, and interaction mechanics are analyzed and documented in cleanroom technical language.
- **Category**: High-End Multi-Pass WebGL2 Shader Compositor
- **Core Value Proposition**: Museum-grade optical and physical material simulation (pressed glassware, crystal lenses, chemical degradation, LCD leak) through composable shader layers and typed keyboard commands.

## Architecture Highlights
- 120+ fragment shaders organized into `imageShaderRegistry` and `proceduralShaderRegistry`.
- Composable layer stack with standard blend modes (`normal`, `screen`, `multiply`, `overlay`, `soft-light`, `difference`).
- Command palette (`Cmd+K`) with rich natural language command parser (`browse`, `add 3 random`, `opacity 50`, `blend screen`).
- Constellation 3D shader map visualizing neighbor relationships.
- URL state serialization and `.shaderlab` project export.
