# Alembic Shader Lab — Cleanroom Shader Catalog

## 1. Physical Glass & Optical Material Simulations
- **Mariskooli Pressed Glass**: Simulates the relief fluting, scalloped rim, and internal caustic refractions of Finnish decorative pressed glassware. Uses normal perturbation based on concentric scalloped heightmaps.
- **Glass Brick Lattice / Waffle Wall**: Emulates 20th-century architectural cast glass blocks with interior grid ribbing. Samples background image through refractive lens cells with edge dispersion.
- **Broken Glass / Stained Glass**: Voronoi cell partitioning with darkened lead caming borders and interior color tinting.

## 2. Analog Chemical & Physical Degradation
- **Xerox Toner Melt**: Simulates heated fuser roller failure where black toner powder melts, smears, and coalesces along horizontal transport rollers.
- **Water Damage / Tide Line**: Models capillary action of liquid invading printed paper fibers, producing dark chromatographic dye accumulation along evaporating boundary perimeters.
- **Broken LCD / TFT Leak**: Emulates cracked glass substrate in active-matrix displays, showing black fluid liquid-crystal bleed, color subpixel line dropouts, and electric polarization fringing.
- **Polarized Light Microscopy (PLM)**: Birefringence simulation generating vibrant interference color fringes (Michel-Lévy color chart) on crystal stress structures.
- **Ink Chromatography**: Separation of compound inks into constituent dye pigments moving outward via radial capillary diffusion.

## 3. Generative & Fluid Shaders
- **Emerald Tablet**: Deep marbled green mineral substrate with golden veining, evaluated using procedural marble LUT and fractional Brownian motion.
- **Oil Pool**: Thin-film interference iridescence (soap bubble / petrol slick) based on optical path difference:
  $$OPD = 2 n d \cos\theta_2$$
- **Thermal Topography**: False-color infrared heatmap gradient mapping luminance to ironbow/rainbow spectrum with contour lines.
- **Xenon Plasma Arc**: High-voltage electrical discharge filaments branching via dielectric breakdown simulation.
