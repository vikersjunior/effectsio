# Alembic Shader Lab — Layer Compositing & Blend Modes

## Supported Blend Equations (Cleanroom Formulations)
- **Normal**: $C_{\text{out}} = \alpha C_{\text{src}} + (1 - \alpha) C_{\text{dst}}$
- **Screen**: $C_{\text{out}} = 1 - (1 - C_{\text{src}})(1 - C_{\text{dst}})$
- **Multiply**: $C_{\text{out}} = C_{\text{src}} \cdot C_{\text{dst}}$
- **Overlay**:
  $$C_{\text{out}} = \begin{cases} 2 C_{\text{src}} C_{\text{dst}} & \text{if } C_{\text{dst}} < 0.5 \\ 1 - 2(1 - C_{\text{src}})(1 - C_{\text{dst}}) & \text{otherwise} \end{cases}$$
- **Soft Light**: Pegtop's formulation:
  $$C_{\text{out}} = (1 - 2 C_{\text{src}}) C_{\text{dst}}^2 + 2 C_{\text{src}} C_{\text{dst}}$$
