# Alembic Shader Lab — Source & Licensing Audit

> [!CAUTION]
> **LEGAL NOTICE & CLEANROOM COMPLIANCE**
> - Alembic Shader Lab is a proprietary commercial product authored by Lauri Paronen.
> - The application bundle (`chunk 37531` and `chunk 30591`) contains proprietary GLSL shader routines.
> - **In accordance with Rule 14, Rule 15, and the Mission Brief, NO PROPRIETARY SHADER CODE IS COPIED OR STORED IN THIS REPOSITORY.**
> - All technical descriptions in this dossier describe publicly observed physical phenomena, published mathematical principles (Fresnel equations, Snell's law, chromatographic diffusion), and generic architectural patterns.
