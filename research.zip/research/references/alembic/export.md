# Alembic Shader Lab — Project Serialization & Export

## State Serialization (`.shaderlab`)
Project state is stored as a JSON document:
```json
{
  "version": 1,
  "canvas": { "width": 1920, "height": 1080 },
  "layers": [
    {
      "id": "layer-1",
      "shaderId": "mariskooli-glass",
      "enabled": true,
      "opacity": 0.85,
      "blendMode": "screen",
      "uniforms": {
        "u_flute_density": 24.0,
        "u_refraction_index": 1.52,
        "u_scallop_depth": 0.4
      }
    }
  ]
}
```
State is also compressed via `lz-string` into URL hashes for instantaneous one-click sharing.
