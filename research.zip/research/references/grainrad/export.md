# Grainrad — Export Modalities & Standalone Code Generation

## Export Types
1. **Static Raster**: PNG, JPEG, WebP ($1\times$, $2\times$, $4\times$ supersampling).
2. **Vector Graphic**: SVG export of halftone cells and pixel blocks.
3. **Motion Video**: WebCodecs MP4 hardware video encoding; animated GIF.
4. **Plain Text**: ASCII representation copied directly to clipboard.
5. **Standalone Three.js HTML**: Exports a fully self-contained HTML file containing Three.js boilerplate, embedded base64 texture, and the active WGSL/GLSL shader pipeline ready for embedding in external websites!
