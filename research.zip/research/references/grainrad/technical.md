# Grainrad — Technical Architecture & WebGPU Runtime

## Epistemic Audit: Source-Inspected (`index-D5s-AdpN.js`)
- **WebGPU Initialization**: Direct calls to `navigator.gpu.requestAdapter()` and `adapter.requestDevice()`.
- **Pipeline Architecture**:
  - `GPUBindGroup` bindings for texture sampler, uniforms struct, and compute storage buffers.
  - Multi-pass render loop switching textures via double-buffered ping-pong targets.
- **Relevance to EffectsIO**:
  - Validates the feasibility of client-side WebGPU compute shaders for high-demand effects (e.g. real-time pixel sorting).
  - Demonstrates the high market demand for standalone Three.js HTML export.
