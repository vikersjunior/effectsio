# Grainrad — Product & Feature Inventory

- **URL**: `https://grainrad.com/`
- **Category**: WebGPU Retro Graphic & Print Studio
- **Architecture**: 100% Pure WebGPU WGSL Pipeline (60fps Real-Time)
- **Verified Bundle Assets**: `assets/index-D5s-AdpN.js` containing 209 WGSL shader routines.
- **Core Value Proposition**: Unmatched real-time retro texture rendering on the modern WebGPU compute stack, supporting VHS CRT emulation, directional pixel sorting, oscillating halftones, and standalone Three.js HTML exports.

## Feature Categories
1. **Dithering**: Bayer 2–16, Interleaved Gradient Noise, Blue Noise, Temporal Blue Noise, Floyd-Steinberg, Atkinson, Sierra Lite, Stucki, Burkes.
2. **Halftone & Print**: Oscillating Halftone, Clustered Dot, Adaptive Dot, Crosshatch, Stipple, Engraving, Woodcut.
3. **CRT & VHS**: Curvature distortion, scanline offset, interlace flicker, block shift, block scramble, chromatic aberration, tape jitter.
4. **Pixel Sorting**: Compute shader pass (`@compute`) with luminance thresholding and directional span detection.
5. **Color Processing**: RGB <-> CMYK, RGB <-> HSL, OKLab palette mapping.
