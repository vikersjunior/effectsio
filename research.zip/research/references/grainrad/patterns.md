# Grainrad — Halftone & Procedural Pattern Stack

## Oscillating Halftone Algorithm
Unlike standard static dot screens, Grainrad's oscillating halftone modulates dot radius with a periodic harmonic function of time:

$$R(x, y, t) = R_0 \cdot \big(1.0 - Y(x, y)\big) \cdot \left[1.0 + A \sin\left(2\pi f t + \phi(x, y)\right)\right]$$

This creates living, breathing print raster graphics where ink dots expand and contract in organic rhythmic waves.
