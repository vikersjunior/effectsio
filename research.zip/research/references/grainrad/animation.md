# Grainrad — Temporal Modulation & Noise Blue Jitter

## Temporal Blue Noise
To avoid repetitive crawling patterns when dithering video or animated scenes, Grainrad uses temporal blue noise:

$$\mathbf{N}(x, y, t) = \left(\text{BlueNoise}(x, y) + t \cdot \Phi\right) \pmod{1.0}$$

Where $\Phi = \frac{\sqrt{5}-1}{2} \approx 0.6180339887$ (the golden ratio). This distributes quantization noise uniformly across space AND time, eliminating low-frequency flashing artifacts.
