# Grainrad — Shader Algorithms & WGSL Routines

## Empirical Inspection: WebGPU WGSL Pipelines

### 1. Directional Pixel Sort Compute Shader
Grainrad implements pixel sorting as a multi-stage WebGPU compute shader (`@compute @workgroup_size(64, 1, 1)`):
- Stage 1: Compute luminance per pixel $Y = 0.2126R + 0.7152G + 0.0722B$.
- Stage 2: Mark span boundaries (`isSpanStart = (Y >= threshold_min && Y <= threshold_max)`).
- Stage 3: Perform parallel bitonic sort or odd-even transposition sort along rows or columns within identified active spans.

### 2. CRT Curvature & Scanlines
```wgsl
fn crtDistortion(uv: vec2<f32>, bend: f32) -> vec2<f32> {
    var cc = uv - 0.5;
    let dist = dot(cc, cc);
    cc = cc * (1.0 + dist * bend);
    return cc + 0.5;
}

fn applyScanlines(color: vec3<f32>, uv: vec2<f32>, count: f32, intensity: f32) -> vec3<f32> {
    let sl = sin(uv.y * count * 3.14159) * 0.5 + 0.5;
    return color * (1.0 - intensity * (1.0 - sl));
}
```
