# Basement Shader Lab — Technical Architecture & Integration

## Epistemic Classification: Source-Inspected & Code-Audited
- **Package Anatomy**:
  - `@basementstudio/shader-lab/core`: Headless timeline and parameter graph engine.
  - `@basementstudio/shader-lab/ui`: React UI components (timeline, curve editor, layer stack).
  - `@basementstudio/shader-lab/r3f`: React Three Fiber canvas integration wrappers.
- **Config Serialization**:
  - State serializes into a standard JSON schema containing timeline tracks, keyframe timestamps, easing cubic coordinates `[x1, y1, x2, y2]`, and layer uniform values.
- **Relevance to EffectsIO**:
  - Direct blueprint for EffectsIO's planned Frame/Layer procedural compositor and keyframe animation engine.
