# Basement Shader Lab — Product & Feature Inventory

- **URL**: `https://eng.basement.studio/tools/shader-lab`
- **NPM Package**: `@basementstudio/shader-lab`
- **License**: MIT License (Open Source)
- **Category**: WebGPU Node Shader Editor & Timeline Animation Tool
- **Core Value Proposition**: Bridging motion design and modern WebGPU shaders by providing a Photoshop-style layer stack, node compositing, and timeline keyframing using Three.js TSL (Three Shading Language).

## Core Capabilities
- Layer-based shader compositing (Noise, Distortion, Blur, Color Grade, Blend Modes).
- WebGPU and WebGL2 dual-backend support via Three.js r165+.
- Full timeline keyframe editor with cubic Bézier curve easing.
- Real-time parameter modulation via LFOs, audio input, and pointer coordinates.
- Export as standalone JSON config (`ShaderLabConfig`), GLSL code, or React Three Fiber components.
