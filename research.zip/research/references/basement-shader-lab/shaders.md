# Basement Shader Lab — TSL Architecture & Node System

## Three Shading Language (TSL) Paradigm
Basement Shader Lab operates on the paradigm that shader logic should be represented as composable JavaScript/TypeScript AST nodes rather than monolithic string templates.

### Example TSL Pipeline Node
```typescript
import { uv, time, sin, vec2, float, texture } from 'three/tsl';

export const wavyDistortion = (inputTexture, speed = 1.0, frequency = 10.0, amplitude = 0.05) => {
  const coord = uv();
  const wave = sin(coord.y.mul(frequency).add(time.mul(speed))).mul(amplitude);
  const distortedCoord = vec2(coord.x.add(wave), coord.y);
  return texture(inputTexture, distortedCoord);
};
```

## Layer Blending Architecture
Each layer exposes:
- Input node
- Mask node (luminance, alpha, procedural)
- Blend mode node: `Add`, `Multiply`, `Screen`, `Overlay`, `SoftLight`, `Difference`, `ColorDodge`, `ColorBurn`.
- Opacity multiplier.
