# EffectsIO — Master Reference Intelligence & Technical Study

## Executive Overview
This research directory contains an exhaustive reference intelligence investigation across 14 state-of-the-art creative web tools. The objective of this study is to analyze product architecture, rendering pipelines, shader mathematics, interaction paradigms, preset formats, and export engines to inform the independent, native evolution of EffectsIO.

**Governing Standards:**
- **Strict Invariant**: Zero application modifications. All research resides outside the EffectsIO codebase in `/tmp/effectsio-reference-intelligence/` and `/tmp/effectsio-implementation/`.
- **Epistemic Classification**: Every finding is classified as **Observed** (empirically tested in browser), **Source-inspected** (verified via bundle/code inspection), **Inferred** (deduced from behavior), or **Unknown** (opaque or unverified).
- **Cleanroom Compliance**: Full respect of intellectual property. Proprietary tools (notably Alembic Shader Lab) are analyzed cleanroom without duplicating proprietary shader code.

## Architecture Taxonomy Across 14 References
```
┌─────────────────────────────────────────────────────────────────────────────┐
│                             CREATIVE WEB TOOLS TAXONOMY                     │
├──────────────────────┬──────────────────────┬───────────────────────────────┤
│ 1. Canvas 2D CPU     │ 2. WebGL / WebGL2    │ 3. WebGPU / WGSL / TSL        │
├──────────────────────┼──────────────────────┼───────────────────────────────┤
│ • The Ladybug (67fx) │ • Alembic (120+ glsl)│ • Grainrad (209 wgsl routines)│
│ • fxstudio.site      │ • GradLab (OKLab/gl) │ • Basement Shader Lab (TSL)   │
│ • Light Stroke Rail  │ • Pryzm Studio       │                               │
│ • Pattern Craft (SVG)│ • zoxilsi/studio     │                               │
│ • Durves (SVG Paths) │ • Ditther (gl/canvas)│                               │
│ • Dot Grid (2D Canvas│ • HeroKit (gl/canvas)│                               │
└──────────────────────┴──────────────────────┴───────────────────────────────┘
```

## Directory Structure
- `source-register.md`: Legal, copyright, and licensing classifications.
- `light-stroke-rail/`: Single-page generative light rail & showcase generator.
- `zoxilsi-studio/`: Bicubic Bézier mesh gradient surface mathematics.
- `ladybug/`: 67 Canvas 2D effects, dual-alphabet typography, subject isolation.
- `basement-shader-lab/`: Three.js WebGPU TSL node editor & timeline keyframing.
- `pattern-craft/`: 100+ procedural CSS/SVG patterns.
- `gradlab/`: OKLab color gradient engine, 13 fluids, and ASCII mouse repulsion.
- `herokit/`: Teenage Engineering K.O. II hardware UI & context preview overlays.
- `pryzm/`: 3-tier compositing pipeline (Gradient -> Image -> Pattern) & seamless loops.
- `durves/`: Harmonic sine wave vector dot displacement.
- `dot-grid-background/`: Radial cursor repulsion physics & harmonic oscillators.
- `ditther/`: 75+ pixel art dithering algorithms and duotone color engine.
- `grainrad/`: Pure WebGPU WGSL compute/fragment pipeline & retro print engine.
- `alembic/`: Multi-pass WebGL2 post-processing, glass physics, and cleanroom catalog.
- `fxstudio/`: Social aspect resizer and swatch extractor.
- `synthesis/`: Consolidated master inventory, effect library, generative library, shader library, animation library, export library, 100 ranked opportunities, blueprints, and 50 implementation prompts.
