# HeroKit — Design System & Skeuomorphic Shader Architecture

## CSS & SVG Token Deconstruction
- **Tactile Bevel**: Multi-layered box shadows creating physical injection-molded plastic bevels:
  `box-shadow: inset 1px 1px 0px rgba(255,255,255,0.2), inset -1px -1px 0px rgba(0,0,0,0.4), 0 4px 12px rgba(0,0,0,0.3);`
- **Substrate Noise Texture**:
```xml
<filter id="paper-texture">
  <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="4" result="noise" />
  <feDiffuseLighting in="noise" lighting-color="#fff" surfaceScale="1.2">
    <feDistantLight azimuth="45" elevation="60" />
  </feDiffuseLighting>
  <feBlend mode="multiply" in="SourceGraphic" result="blend" />
</filter>
```
