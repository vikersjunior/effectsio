# HeroKit — Product & Feature Inventory

- **URL**: `https://herokit.app/?app=`
- **Category**: Hardware-Skeuomorphic Background & Hero Banner Studio
- **Target Audience**: Landing page designers, SaaS founders, frontend engineers.
- **Core Value Proposition**: Distinctive industrial hardware aesthetics inspired by Teenage Engineering instruments, coupled with real-time "Preview in Context" overlays that solve visual contrast issues before export.

## Key Feature Highlights
1. **Teenage Engineering K.O. II Aesthetics**:
   - Machined aluminum bezel borders and chamfered shadows.
   - Distinctive tactile orange slab action buttons (`#ff5722`).
   - Recessed plastic button wells with cast drop shadows.
   - Monospaced LCD numerical readouts (`Share Tech Mono`).
   - SVG `feTurbulence` paper texture background plate.
2. **"Preview in Context" Mode**:
   - Live overlay toggle rendering functional mock web headers (Logo, Nav links, Sign in), hero headline typography, and Call-to-Action button groups over the active canvas.
   - Enables designers to verify text legibility and visual hierarchy before downloading assets.
3. **Visual Effect Stack**:
   - Dithering (Bayer, blue noise), halftone dot grids, scanline overlays, CRT warp, and chromatic split glitch.
