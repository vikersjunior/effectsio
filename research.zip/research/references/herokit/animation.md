# HeroKit — Motion & Context Preview System

## Context Preview Architecture
HeroKit implements an overlay pipeline where the canvas sits in a lower compositing plane (`z-index: 1`), while mock DOM UI overlays sit above it (`z-index: 10`):

```tsx
<div className="hero-stage relative overflow-hidden">
  <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
  {showContextPreview && (
    <div className="context-overlay absolute inset-0 pointer-events-none flex flex-col justify-between p-8">
      <MockNavbar logo="Acme Inc." links={["Features", "Pricing", "Docs"]} />
      <MockHeroText headline="Transform your creative workflow." subhead="High-performance background generation." />
      <MockButtonGroup primary="Get Started Free" secondary="Live Demo" />
    </div>
  )}
</div>
```
This guarantees that users never export a background with insufficient contrast for typical web typography.
