# Master Legal, Copyright & Licensing Register

> [!IMPORTANT]
> **Governing Principles:**
> 1. All reference study research is strictly analytical and educational in nature.
> 2. Open source projects are credited under their respective licenses.
> 3. Proprietary closed-source tools are studied via cleanroom functional and behavioral observation; no proprietary source code or intellectual property is copied, redistributed, or incorporated into EffectsIO.
> 4. In particular, Alembic Shader Lab (`lab.alembic.space`) is proprietary under Lauri Paronen with explicit TOS prohibiting reverse engineering or unauthorized reproduction. All analysis is strictly cleanroom documentation of mathematical models, public UI interactions, and algorithmic principles described in our own words.

| # | Product Name | Target URL / Repo | Legal Status | Author / Owner | Permissible Use & Extraction Protocol |
|---|---|---|---|---|---|
| 1 | **Light Stroke Rail** | `https://light-stroke-rail.vercel.app/` | Proprietary Web Experiment | Inspectable Vercel deployment | Cleanroom functional observation, interaction pattern analysis. |
| 2 | **zoxilsi/studio** | `https://github.com/zoxilsi/studio`, `studio.zoxilsi.cc` | Open Source (MIT) | zoxilsi | Permissible under MIT license. Mathematical analysis of bicubic Bézier patches. |
| 3 | **The Ladybug** | `https://app.theladybug.app/` | Commercial SaaS (Proprietary) | The Ladybug App | Cleanroom behavioral audit of 67 Canvas 2D filters and dual-script typography. |
| 4 | **Basement Shader Lab** | `https://eng.basement.studio/tools/shader-lab`, `@basementstudio/shader-lab` | Open Source (MIT) | basement.studio | Permissible under MIT license. Architecture study of Three.js WebGPU TSL node editor. |
| 5 | **Pattern Craft** | `https://github.com/megh-bari/pattern-craft`, `patterncraft.fun` | Open Source (MIT) | Megh Bari | Permissible under MIT license. Procedural CSS/SVG pattern algorithms. |
| 6 | **GradLab** | `https://www.gradlab.app/` | Commercial Web App (Proprietary) | GradLab Team | Cleanroom behavioral study of OKLab gradient interpolation and ASCII mouse physics. |
| 7 | **HeroKit** | `https://herokit.app/?app=` | Commercial SaaS (Proprietary) | HeroKit Team | Cleanroom study of Teenage Engineering K.O. II hardware design & context preview overlays. |
| 8 | **Pryzm Studio** | `https://pryzm.design/studio` | Commercial SaaS (Proprietary) | Pryzm Design | Cleanroom study of 3-tier compositing pipeline (Gradient -> Image -> Pattern) and loop engine. |
| 9 | **Durves** | `https://www.durves.com/`, `filipeedr/durves` | Open Source (MIT) | Filipe Drumond | Permissible under MIT license. Mathematical study of harmonic sine wave dot displacement. |
| 10 | **Dot Grid Background** | `https://playground.willnewton.dev/p/dot-grid-background` | Web Experiment (Inspectable) | Will Newton | Cleanroom behavioral study of radial cursor repulsion fields and harmonic oscillators. |
| 11 | **Ditther** | `https://app.ditther.com/` | Commercial SaaS (Proprietary) | Ditther Team | Cleanroom audit of 75+ pixel art dithering algorithms, duotone grading, and timeline loops. |
| 12 | **Grainrad** | `https://grainrad.com/` | Commercial SaaS (Proprietary) | Grainrad Team | Cleanroom study of pure WebGPU WGSL compute/fragment architecture and retro effects. |
| 13 | **Alembic Shader Lab** | `https://lab.alembic.space/` | Proprietary / Closed Source | Lauri Paronen | **STRICT CLEANROOM ONLY**: Explicit TOS prohibits copying or reverse engineering. Zero proprietary shaders copied; mathematical models, pass graphs, and UI syntax described independently. |
| 14 | **fxstudio.site** | `https://fxstudio.site/` | Commercial Utility (Proprietary) | fxstudio Team | Cleanroom audit of 9-anchor canvas transformation and swatch extraction utilities. |
