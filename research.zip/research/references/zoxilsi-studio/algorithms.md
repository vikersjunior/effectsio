# zoxilsi/studio — Mathematical Algorithms & Noise Distortion

## Simplex Noise Modulation
To prevent gradients from appearing static or synthetic, zoxilsi/studio injects low-frequency simplex noise into the interpolated UV coordinates:

$$u' = u + \delta \cdot \text{snoise}(u \cdot \nu, v \cdot \nu, \text{time} \cdot \omega)$$
$$v' = v + \delta \cdot \text{snoise}(u \cdot \nu + 43.12, v \cdot \nu + 17.89, \text{time} \cdot \omega)$$

Where:
- $\delta$: Distortion amplitude ($0.0$ to $0.25$).
- $\nu$: Noise spatial scale.
- $\omega$: Noise temporal velocity.

This yields gentle, fluid wave dynamics reminiscent of liquid ink blending on wet paper.
