# zoxilsi/studio — Architecture & State Model

## State Representation
The mesh gradient state is modeled as an $M \times N$ matrix of control nodes:

```typescript
interface MeshNode {
  position: [number, number];       // Normalized UV coordinate [0, 1]
  color: [number, number, number];  // RGB normalized [0, 1]
  handleNorth: [number, number];    // Tangent offset vector
  handleSouth: [number, number];
  handleEast: [number, number];
  handleWest: [number, number];
}

interface MeshGradientState {
  gridSize: [number, number];       // e.g. [3, 3] or [4, 4]
  nodes: MeshNode[][];
  distortion: number;               // Procedural noise distortion factor
  speed: number;                    // Animation oscillation speed
}
```

## State Serialization
The entire state can be encoded into a compact Base64 JSON string or URL query parameter (`?mesh=...`), enabling lossless bookmarking and sharing.
