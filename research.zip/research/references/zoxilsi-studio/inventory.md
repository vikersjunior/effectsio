# zoxilsi/studio — Product & Feature Inventory

- **Repository**: `https://github.com/zoxilsi/studio`
- **Demo URL**: `https://studio.zoxilsi.cc`
- **License**: MIT License (Open Source)
- **Category**: Interactive WebGL Mesh Gradient Studio
- **Core Value Proposition**: Creation of fluid, organic, high-end mesh gradients using interactive bicubic Bézier patches on the GPU.

## Key Capabilities
- Multi-point 2D lattice grid ($3\times 3$, $4\times 4$, $5\times 5$).
- Independent color assignment per lattice vertex.
- Interactive tangent handle manipulation for directional color flow.
- Real-time WebGL fragment shader evaluation.
- High-resolution vector SVG mesh gradient and PNG export.
- CSS code generation for backdrop-filter gradients.
