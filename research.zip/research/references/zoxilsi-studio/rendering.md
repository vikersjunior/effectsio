# zoxilsi/studio — WebGL Rendering Pipeline

## Bicubic Surface Evaluation
The fragment shader evaluates bicubic Hermite/Bézier interpolation across each quadrilateral patch defined by four corner nodes $(P_{00}, P_{01}, P_{10}, P_{11})$:

$$C(u, v) = \sum_{i=0}^3 \sum_{j=0}^3 B_i(u) B_j(v) C_{ij}$$

Where $B_k(t)$ are Bernstein polynomials:
- $B_0(t) = (1 - t)^3$
- $B_1(t) = 3t(1 - t)^2$
- $B_2(t) = 3t^2(1 - t)$
- $B_3(t) = t^3$

By evaluating both color vectors $\mathbf{C}_{ij}$ and coordinate positions $\mathbf{P}_{ij}$ simultaneously, the shader renders non-linear color bleed without triangulation seams or Mach banding artifacts.
