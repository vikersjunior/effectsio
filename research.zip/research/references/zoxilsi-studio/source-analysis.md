# zoxilsi/studio — Source Code & AST Analysis

## Inspected Components
- `src/components/MeshCanvas.tsx`: WebGL context manager and event listener dispatcher.
- `src/shaders/meshVertex.glsl`: Passes quad vertex coordinates and normalized texture UVs.
- `src/shaders/meshFragment.glsl`:
  - Receives uniform array `uniform vec2 u_nodes[16]` and `uniform vec3 u_colors[16]`.
  - Performs patch identification via floor division of screen coordinates.
  - Implements smooth bicubic Hermite interpolation.
- `src/utils/exportSvg.ts`: Constructs native SVG `<meshgradient>` tags with `<meshrow>` and `<meshpatch>` children for Adobe Illustrator and vector graphic fidelity.
