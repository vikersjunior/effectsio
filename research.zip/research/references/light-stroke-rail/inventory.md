# Light Stroke Rail — Product & Feature Inventory

- **URL**: `https://light-stroke-rail.vercel.app/`
- **Category**: Generative Light & Stroke Pattern Generator
- **Target Audience**: Digital branding designers, motion graphics artists, presentation deck creators.
- **Core Value Proposition**: Rapid generation of luminous, sweeping neon stroke rails, geometric ribbons, and brand light showreels with zero design friction.

## Visual & Layout Architecture
- **Layout Model**: Dual-rail sidebars with a central framed canvas stage.
  - **Left Rail (Palette & Presets)**: Vertical stack of vibrant circular color swatches (Cyan, Electric Purple, Neon Lime, Solar Orange, Cyber White) and curated style thumbnails.
  - **Center Stage (Viewport)**: High-contrast dark viewport (`#0a0a0c`) hosting the responsive interactive SVG/Canvas stage with smooth pinch-to-zoom and pan.
  - **Right Rail (Parameter Stack)**: Compact slider group controlling geometric parameters, stroke taper, glow spread, and animation frequency.
  - **Bottom Dock**: Timeline playback bar with loop toggle, frame stepper, and export triggers (PNG, SVG, MP4).

## Feature Matrix
| Feature | Semantic Role | Implementation Type | Status in Reference |
|---|---|---|---|
| **Rail Curvature** | Geometry Control | Quadratic/Cubic Bézier | Functional |
| **Stroke Density** | Line Multiplicity | Cloned path offsets | Functional |
| **Glow Diffusion** | Shader/Filter Glow | Multi-pass Gaussian blur | Functional |
| **Color Gradient** | Light Traversal | Interpolated linear/radial | Functional |
| **Speed Oscillator**| Animation | Continuous phase shift $\phi$ | Functional |
