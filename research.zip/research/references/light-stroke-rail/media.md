# Light Stroke Rail — Media Showcase & Presets

## Curated Presets
1. **Cyberpunk Highway**:
   - Twin counter-oscillating rails in Deep Cyan (`#00f0ff`) and Acid Magenta (`#ff0077`).
   - High taper, dense trailing echo ($N = 24$ lines), speed: $1.2\text{Hz}$.
2. **Solar Flare Ribbon**:
   - Single thick ribbon with inner yellow core (`#fff4b8`) and solar amber corona (`#ff6600`).
   - Heavy blur ($r = 48\text{px}$), slow harmonic breathing ($0.3\text{Hz}$).
3. **Monochrome Laser Grid**:
   - 16 parallel stroke rails in Pure White (`#ffffff`), low blur ($r = 4\text{px}$), sharp staccato phase offsets.
4. **Aurora Borealis**:
   - Quad-rail overlapping wave with emerald green (`#00ff88`) fading to violet (`#8800ff`) across curve normal.
