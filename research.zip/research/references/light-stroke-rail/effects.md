# Light Stroke Rail — Visual Effects & Rendering Techniques

## Visual Anatomy of the Light Rail
The luminous rail effect is composed of four distinct rendering passes:

1. **Core Spine (Solid Path)**:
   - High-luminance white or light-tinted vector spline ($1\text{px}$ to $4\text{px}$ width).
   - Blend Mode: `source-over`.
2. **Inner Luminous Sheen**:
   - Stroke width: $8\text{px}$ to $16\text{px}$.
   - Opacity: 0.6.
   - Blend Mode: `screen` or `additive`.
3. **Outer Diffuse Corona**:
   - Multi-layer Gaussian blur filter ($r = 32\text{px}$, $r = 64\text{px}$).
   - Color: Saturated base hue from active palette swatch.
   - Blend Mode: `lighter` / WebGL additive blend (`gl.blendFunc(gl.SRC_ALPHA, gl.ONE)`).
4. **Motion Ghosting / Phosphor Decay**:
   - Previous frame buffer is decayed by factor $\lambda = 0.88$ per frame, creating an organic analog light-trail behind oscillating strokes.
