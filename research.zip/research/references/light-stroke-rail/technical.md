# Light Stroke Rail — Technical Architecture & Code Deconstruction

## Epistemic Classification: Source-Inspected & Observed
- **Runtime Environment**: Client-side React + Next.js single-page deployment.
- **Rendering Stack**: HTML5 2D Canvas with dual-pass composition and SVG path generation.
- **State Model**: Lightweight React state (`useState` + `useRef` animation loop).
- **Export Pipeline**:
  - Vector: Generates pure `<svg>` with `<defs><filter id="glow">...` containing `feGaussianBlur` and `feMerge`.
  - Raster: Direct `canvas.toBlob("image/png")`.
  - Video: Client-side `canvas.captureStream(60)` recorded via `MediaRecorder` with `video/mp4;codecs=avc1` fallback to `video/webm`.
