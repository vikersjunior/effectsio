# Light Stroke Rail — User Interaction Model

## Control Modalities
1. **Interactive Path Handles**:
   - The user directly clicks and drags anchor nodes directly on the canvas stage to alter the primary stroke rail spline.
   - Secondary handles control the tangent vectors ($T_1, T_2$), adjusting curvature tension.
2. **Scrubbable Numeric Inputs**:
   - Sliders support both click-and-drag scrubbing and direct double-click numeric entry.
   - Stepper increments are tuned to natural visual steps (e.g., density: 1 line; curvature: 0.05).
3. **Preset Cycling**:
   - Left-click on preset thumbnail immediately morphs the current control points into the preset's target configuration using a 400ms cubic ease-out tween.

## Responsive Viewport Controls
- Wheel scroll: Zoom in/out centered on mouse pointer ($0.25\times$ to $4.0\times$).
- Space + Drag or Middle Mouse: Pan stage.
- Reset button: Snaps camera back to $(0, 0)$ at $1.0\times$ zoom.
