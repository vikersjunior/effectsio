# Light Stroke Rail — EffectsIO Native Blueprint

> [!NOTE]
> **Status**: `PROPOSED — NOT IMPLEMENTED` / `AWAITING APPROVAL`

## Proposed EffectsIO Architectural Integration
1. **Layer Classification**: Belongs as a **Generative Vector Layer** (`LayerKind: 'generative'`) with subtype `'light-rail'`.
2. **Compositor Pipeline**:
   - Evaluated on CPU or WebGL vertex shader as parametric Bézier points.
   - Rendered into an offscreen framebuffer with additive blending.
   - Fed into EffectsIO's WebGL2 multi-pass post-processing stack (allowing downstream Halftone, Film Grain, or Dithering).
3. **Inspector Controls**:
   - `Points`: 4 anchor handles (X, Y).
   - `Rail Count`: Integer slider (1 to 32).
   - `Glow Radius`: Float slider (0 to 100px) mapped to `var(--radius)` scale.
   - `Color Gradient`: EffectsIO ColorStop picker.
   - `Speed`: Float slider (0 to 5.0x).
