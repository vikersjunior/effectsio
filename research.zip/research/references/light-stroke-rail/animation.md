# Light Stroke Rail — Animation & Motion Engine

## Mathematical Formulation
The stroke animation is governed by a travelling harmonic wave along the parametric spline $P(t)$:

$$P(t, \tau) = P_0 (1-t)^3 + 3 P_1 t(1-t)^2 + 3 P_2 t^2 (1-t) + P_3 t^3 + \mathbf{N}(t) \cdot A \sin(\omega t - 2\pi f \tau + \phi)$$

Where:
- $t \in [0, 1]$: Spline curve parameter.
- $\tau$: Normalized time variable ($0 \le \tau < 1$).
- $\mathbf{N}(t)$: Normal vector to the spline curve at point $t$.
- $A$: Amplitude slider parameter ($0$ to $120\text{px}$).
- $\omega$: Spatial frequency parameter.
- $f$: Temporal cycle frequency (Hz).
- $\phi$: Phase offset.

## Loop Invariant
Because $\tau$ is bounded to $[0, 1)$ and scaled by $2\pi$, the animation achieves an **exact mathematical seamless loop** when $\tau$ wraps from $1.0$ to $0.0$, guaranteeing glitch-free export to animated GIF and MP4.
