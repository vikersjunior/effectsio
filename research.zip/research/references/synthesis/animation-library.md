# Animation & Temporal Modulation Library

## Motion Paradigms
1. **Procedural Autonomous Drift**: Continuous harmonic or noise-based oscillation running infinitely.
2. **Interactive Pointer Physics**: Spring-damper physics responding to user mouse/touch coordinates.
3. **Seamless Mathematical Time Loops**: Circular phase wrapping guaranteeing zero-seam loop playback for animated GIF and MP4 exports.

## Seamless 4D Circular Phase Invariant
To create an infinitely looping animation of duration $T$:

$$t \in [0, T)$$
$$\theta = \frac{2\pi t}{T}$$
$$z = R \cos\theta, \quad w = R \sin\theta$$

Any procedural shader sampling 4D noise $\text{noise}(x, y, z, w)$ will evaluate identically at $t = 0$ and $t = T$, producing seamless looping video clips with zero temporal boundary jumps.
