# Master Cross-Product Inventory & Technical Matrix

## Executive Overview
This document compiles the exhaustive capabilities of all 14 analyzed reference products alongside EffectsIO's baseline architecture, establishing a unified capability census across 8 core architectural dimensions.

## 15-Product Census Table
| # | Product Name | Engine & Pipeline | Total Shaders / Effects | Layer & Compositor Model | Animation & Loops | Export Capabilities | Key Differentiator |
|---|---|---|---|---|---|---|---|
| **0** | **EffectsIO (Current)** | WebGL2 + CPU Fallback | 12 Canvas Effects | Frame/Layer (Stage 1 Approved) | Static / Single Frame | PNG, JPEG, WebP | High-precision design system & non-destructive editing |
| **1** | **Light Stroke Rail** | Canvas 2D + SVG | Luminous Neon Rails | Single Stage | Continuous Harmonic Oscillator | PNG, SVG, MP4 | Brand light showreel generator with dual-rail UI |
| **2** | **zoxilsi/studio** | WebGL1/2 | Bicubic Bézier Surface | Single Mesh Stage | Simplex Temporal Drift | PNG, SVG Mesh, CSS | Interactive tangent handles on 2D lattice |
| **3** | **The Ladybug** | Canvas 2D (Zero WebGL) | 67 Discrete Effects | Flat Layer Stack + Masking | 45+ Animated Effects, Seed Jitter | GIF, MP4, SVG | Dual-script typography (Arabic/Latin) & textile crafts |
| **4** | **Basement Shader Lab** | WebGPU + Three.js TSL | Node Shader Graph | Photoshop-style Layer Stack | Full Timeline Keyframe Editor | JSON Config, GLSL, R3F | Node-based TSL compositing with timeline curves |
| **5** | **Pattern Craft** | CSS3 + SVG | 100+ Patterns | Single Surface Mask | Static CSS Transitions | SVG, PNG, CSS, Tailwind | Zero-runtime procedural background patterns |
| **6** | **GradLab** | WebGL + 2D Text Canvas | OKLab Gradients + ASCII | Multi-Canvas Overlay | Fluid Flow & Mouse Repulsion | PNG, WebP, HTML Iframe | Strict OKLab interpolation & interactive ASCII physics |
| **7** | **HeroKit** | WebGL + 2D Canvas | Retro Shaders & Dither | Layered Stage + UI Mock | Scanline Flicker & Jitter | PNG, JPEG, Scaled WebP | Teenage Engineering hardware UI & Context Preview |
| **8** | **Pryzm Studio** | WebGL2 Post-Processing | 3-Tier Layer Pipeline | Gradient -> Image -> Pattern | Circular Phase Loops (2-10s) | MP4, WebM, URL State | Bento masking & mathematically seamless loops |
| **9** | **Durves** | HTML5 Canvas + SVG | Harmonic Wave Grid | Single Dot Lattice | Sine-wave Time Phase | SVG Vector Paths, PNG | Transverse wave displacement on dot arrays |
| **10** | **Dot Grid Background** | HTML5 Canvas 2D | Interactive Dot Physics | Canvas Substrate | Spring-damper Restitution | Web Embed | Cursor repulsion field with inverse-square falloff |
| **11** | **Ditther** | WebGL + Canvas 2D | 75+ Dither Algorithms | Multi-pass Quantizer | Timeline Frame Stepper | Lossless PNG, GIF, MP4 | Comprehensive error diffusion & duotone grading |
| **12** | **Grainrad** | Pure WebGPU (WGSL) | 209 WGSL Routines | Double-buffered Ping-Pong | Temporal Blue Noise Jitter | PNG, GIF, MP4, 3.js HTML | Compute shader pixel sorting & oscillating halftones |
| **13** | **Alembic Shader Lab** | WebGL2 Multi-Pass | 120+ Fragment Shaders | FBO Ping-Pong Post Stack | Sinusoidal Drift & Mouse Velocity | PNG, JSON, URL Hash | Physical glass materials, chemical toner melt, LCD leak |
| **14** | **fxstudio.site** | HTML5 Canvas 2D | Crop & Swatch Utilities | 9-Point Registration Frame | Static Interaction | JPEG, PNG (Compressed) | Social aspect ratio presets & k-means swatches |
