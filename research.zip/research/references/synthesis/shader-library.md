# Unified Cleanroom Shader Catalog & Mathematical Formulations

> [!NOTE]
> All shader descriptions conform strictly to cleanroom standards. No proprietary shader code is reproduced.

## 1. Cleanroom Uniform Buffer Specification
All EffectsIO WebGL2 shaders consume a standardized uniform block:

```glsl
#version 300 es
precision highp float;

layout(std140) uniform FrameUniforms {
    mat4  u_projection;
    vec2  u_resolution;
    vec2  u_mouse;
    vec2  u_mouse_velocity;
    float u_time;
    float u_intensity;
    float u_param1;
    float u_param2;
    float u_param3;
    float u_param4;
};

uniform sampler2D u_input_texture;
uniform sampler2D u_aux_texture;
in vec2 v_uv;
out vec4 frag_color;
```

## 2. Selected Cleanroom Mathematical Formulations

### A. Mariskooli Pressed Glass Refraction
Normal map calculation using concentric fluting:
$$r = \sqrt{(u - 0.5)^2 + (v - 0.5)^2}$$
$$h(r, \theta) = A \cos(N \theta) \cdot \sin(2\pi f r)$$
$$\mathbf{N} = \text{normalize}\left(-\frac{\partial h}{\partial u}, -\frac{\partial h}{\partial v}, 1.0\right)$$
$$\mathbf{UV}' = \mathbf{UV} + \eta \cdot \mathbf{N}_{xy}$$

### B. Xerox Toner Melt Smear
Horizontal smear modulated by low-frequency noise and luminance threshold:
$$Y = 0.2126R + 0.7152G + 0.0722B$$
$$\text{offset}_x = \text{smoothstep}(0.2, 0.8, Y) \cdot \text{snoise}(uv.y \cdot 12.0) \cdot u_{\text{melt}}$$
$$\mathbf{UV}' = \mathbf{UV} + \begin{bmatrix} \text{offset}_x \\ 0 \end{bmatrix}$$

### C. Thin-Film Oil Iridescence
Color interference based on optical path difference $\delta$:
$$\delta = 2 n d \cos\theta$$
$$\phi_k = \frac{2\pi \delta}{\lambda_k}, \quad \lambda \in \{650\text{nm}, 510\text{nm}, 440\text{nm}\}$$
$$I_k = \frac{1}{2}\left(1 + \cos\phi_k\right)$$
$$\mathbf{C} = \begin{bmatrix} I_R \\ I_G \\ I_B \end{bmatrix}$$
