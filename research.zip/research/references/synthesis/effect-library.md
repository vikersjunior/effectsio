# EffectsIO Master Consolidated Effect Library

This library synthesizes all verified effect algorithms from the reference study into 15 canonical categories for EffectsIO's planned engine.

## 1. Analog & CRT Emulation
- **CRT Curvature**: Barrel distortion mapping UVs radially ($uv' = uv \cdot (1 + d \cdot k)$).
- **Phosphor Scanlines**: Sinusoidal horizontal luminance modulation with variable line density.
- **Interlace Jitter**: Alternating odd/even row vertical pixel offsets on alternating frames.
- **RGB Shadow Mask / Aperture Grille**: Triad subpixel phosphor triads (Red, Green, Blue vertical stripes or delta dots).
- **Magnetic Tape Wobble**: Low-frequency sinusoidal horizontal skewing emulating analog VCR head switching.

## 2. Retro Print & Halftone
- **Oscillating Halftone**: Dot radius dynamically modulated by spatial luminance and harmonic temporal wave.
- **Hexagonal Halftone**: Clustered dot screens arranged on an equilateral triangular lattice.
- **Crosshatch Engraving**: Multi-angle line screens layered at $0^{\circ}$, $45^{\circ}$, $90^{\circ}$, and $135^{\circ}$ based on shadow depth.
- **Stipple Print**: Poisson-disk stochastic dot distribution clustering densely in low-luminance zones.
- **Woodcut / Relief**: Directional line cuts following image luminance gradients (Sobel vector field).

## 3. Digital Glitch & Artifacts
- **Directional Pixel Sort**: Horizontal or vertical sorting of pixel spans bounded by luminance thresholds.
- **JPEG Block Compression**: $8\times 8$ discrete cosine transform (DCT) quantization artifact simulation.
- **Chromatic Aberration / Split**: Independent spatial translation of Red, Green, and Blue channels.
- **Data Mosh / Block Displacement**: Rectangular macroblock shuffling driven by motion vectors.
- **Bitwise Logic Jitter**: XOR and bit-shift corruption on raw 8-bit color channels.

## 4. Optical & Refractive Glass
- **Mariskooli Fluted Glass**: Relief scalloping and vertical fluting with normal-mapped caustic refraction.
- **Waffle Wall / Cast Glass Brick**: Grid-ribbed architectural glass blocks with internal internal reflections.
- **Liquid Drop Condensation**: Procedural spherical droplets scattering light via Snell's law refraction.
- **Chromatic Dispersion**: Wavelength-dependent refraction index ($n_{\text{red}} < n_{\text{green}} < n_{\text{blue}}$).
- **Frosted Glass / Roughness**: Multi-tap jittered sampling simulating microfacet surface roughness.

## 5. Dithering & Quantization
- **Ordered Bayer Dithering**: $2\times 2$, $4\times 4$, $8\times 8$, $16\times 16$ threshold matrices.
- **Error Diffusion**:
  - *Atkinson*: High-contrast classic MacPaint aesthetic (75% error diffused, 25% drop).
  - *Floyd-Steinberg*: Standard 16th error distribution.
  - *Sierra Two-Row / Sierra Lite*: Fast low-memory diffusion kernels.
- **Blue Noise Stochastic**: Uniform high-frequency spatial noise with zero low-frequency clumping.
- **Temporal Blue Noise**: Golden-ratio phase-shifted blue noise for smooth animated video dithering.

## 6. Chemical & Physical Degradation
- **Xerox Toner Melt**: Horizontal smearing and cohesive pooling of black toner particles under heat.
- **Water Damage / Tide Line**: Chromatographic dye migration along evaporating liquid boundaries.
- **Broken LCD / TFT Leak**: Dark isotropic fluid bleeding through cracked glass with electrical polarization.
- **Polarized Light Microscopy (PLM)**: Birefringence interference fringes matching Michel-Lévy color scales.
- **Ink Chromatography**: Separation of black ink into cyan, magenta, and yellow capillary halos.

## 7. Textile & Craft
- **Kilim Carpet**: Diamond/chevron woven wool threads with anti-aliased cross-stitches.
- **Knitted Embroidery**: Interlocking V-shaped yarn loops with simulated surface fuzz and shadow cast.
- **Cross-Stitch**: Uniform $X$-pattern thread grid on woven Aida cloth texture.

## 8. Typography & Code
- **ASCII Particle Matrix**: Dynamic luminance-mapped character glyphs with selectable font ramps.
- **Matrix Digital Rain**: Falling glyph streams with phosphor trails and leading white highlights.
- **Dual-Script Typographic Mask**: Simultaneous support for Latin and Arabic typography.
- **Word Mosaic**: Dynamic text packed tightly into luminance contours.

## 9. Blur & Defocus
- **Separable Gaussian Blur**: Two-pass horizontal and vertical Gaussian convolution.
- **Bokeh Disc / Hexagonal Aperture**: Realistic optical camera lens defocus with blade polygonal bokeh.
- **Directional Motion Blur**: Linear convolution kernel oriented along velocity vector.

## 10. Generative Grids & Waves
- **Bicubic Bézier Mesh**: $4\times 4$ lattice with interactive tangent handles and smooth Hermite interpolation.
- **Harmonic Sine-Wave Dots**: Transverse wave displacement on regular dot grids.
- **Cursor Repulsion Field**: Interactive pointer physics pushing grid elements outward with spring damping.
- **Bento Box Mosaic**: Adaptive rectangular mosaic with adjustable gutters and rounded corners.

## 11. Color Grading & Tone Mapping
- **OKLab Perceptual Interpolation**: Uniform chroma and lightness blending without gray dead zones.
- **Duotone / Tritone Gradient Map**: Remapping grayscale luminance into custom multi-stop color ramps.
- **3D Color LUT**: Real-time color transformation via $32\times 32\times 32$ tetrahedral texture LUTs.
- **CMYK Halftone Separation**: Decomposing RGB into Cyan, Magenta, Yellow, and Key channels.

## 12. Generative Noise & Turbulence
- **Simplex Noise 2D/3D/4D**: Smooth gradient noise with low computational overhead.
- **Fractional Brownian Motion (fBm)**: Multi-octave octave fractal noise ($N = 4$ to $8$).
- **Worley / Voronoi Cellular Noise**: Distance to nearest feature points creating organic cell structures.

## 13. Edge & Contour Detection
- **Sobel Operator**: Discrete 2D spatial gradient convolution for edge intensity and direction.
- **Laplacian of Gaussian (LoG)**: Second-order differential edge detection for fine zero-crossings.
- **Contour Topography**: Isoluminance contour lines creating geographic elevation maps.

## 14. Light & Atmospheric Shaders
- **Xenon Plasma Arc**: High-voltage electrical filaments branching via dielectric breakdown.
- **Volumetric Light Rays / Crepuscular God Rays**: Radial screen-space light scattering.
- **Film Prism Dispersion**: Prismatic rainbow light leaks across canvas edges.

## 15. UI Overlays & Tracking
- **HUD Target Reticle**: Technical crosshairs, telemetry coordinates, and tracking brackets.
- **Context Preview Mock**: Interactive web navbar, hero headline, and CTA button contrast overlay.
- **Pan / Zoom HUD**: Real-time canvas coordinate and scale readout.
