# 15-Product Architectural Comparison Matrix

## Cross-Cutting Feature Comparison
| Product | Engine | Layers | Procedural Patterns | Physical Glass | Typography Engine | Seamless Loops | Context Preview | Standalone Code Export |
|---|---|---|---|---|---|---|---|---|
| **EffectsIO (Current)** | WebGL2 | Yes (Stage 1) | No | No | No | No | No | No |
| **Light Stroke Rail** | Canvas 2D | No | Yes | No | No | Yes | No | SVG |
| **zoxilsi/studio** | WebGL | No | Mesh | No | No | No | No | SVG / CSS |
| **The Ladybug** | Canvas 2D | Flat | Yes | No | Yes (Dual) | Yes | No | SVG |
| **Basement Shader Lab**| WebGPU/TSL | Node Stack | Yes | Refract | No | Keyframes | No | JSON / R3F |
| **Pattern Craft** | CSS/SVG | No | 100+ | No | No | No | No | CSS / Tailwind |
| **GradLab** | WebGL | Overlays | Fluids | No | ASCII | No | Yes | HTML Iframe |
| **HeroKit** | WebGL/2D | No | Dot/Lines | No | Monospace | No | **Yes** | No |
| **Pryzm Studio** | WebGL2 | **3-Tier** | Bento/Plaid| Yes | ASCII | **Yes** | No | No |
| **Durves** | Canvas/SVG | No | Dots | No | No | Yes | No | SVG |
| **Dot Grid Background**| Canvas 2D | No | Grid | No | No | Interactive | No | Web script |
| **Ditther** | WebGL/2D | No | Yes | No | No | Timeline | No | Lossless PNG |
| **Grainrad** | WebGPU | Ping-Pong | Halftone | No | ASCII | Noise Blue | No | **Three.js HTML** |
| **Alembic Shader Lab** | WebGL2 | **Ping-Pong**| No | **Yes (High)**| No | Yes | No | JSON Config |
| **fxstudio.site** | Canvas 2D | Crop Frame | Backdrop | No | No | No | No | Compressed Blob|
