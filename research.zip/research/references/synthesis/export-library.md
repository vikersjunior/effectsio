# Export Engine & Format Architecture

## Supported Export Modalities
| Format | Target Use Case | Reference Benchmark | Client Implementation |
|---|---|---|---|
| **Lossless PNG** | Pixel-perfect static output | Ditther, Grainrad | `canvas.toBlob("image/png")` |
| **Optimized JPEG** | Web & social photography | fxstudio.site | `canvas.toBlob("image/jpeg", quality)` |
| **Animated GIF** | Looping social animations | Ladybug, Ditther | WebWorker `omggif` encoder |
| **MP4 Video** | High-definition motion | Grainrad, Pryzm | WebCodecs `VideoEncoder` / `MediaRecorder` |
| **Vector SVG** | Scalable geometric output | Durves, Pattern Craft | XML serializer constructing `<svg>` paths |
| **Standalone HTML** | Interactive web embeds | Grainrad, GradLab | Inlines canvas, shaders, and runtime script |
| **JSON Preset** | Lossless project sharing | Alembic, Basement | Compressed Base64 / URL hash |
