# 50 Implementation-Ready Prompts for EffectsIO

> [!IMPORTANT]
> These prompts are pre-engineered for future approved implementation phases. Each prompt conforms strictly to EffectsIO's Rulebook, design tokens (`src/styles.css`), Phosphor icons, and non-destructive state model.

## Category 1: Core Mathematical & Color Foundations (Prompts 1-10)
1. **Implement OKLab Color Space Transformation Matrix**: Create `src/core/color/oklab.ts` implementing bidirectional conversion between sRGB, Linear sRGB, and OKLab ($L, a, b$) with unit tests verifying perceptual uniformity.
2. **Implement OKLab Multi-Stop Gradient Interpolator**: Build `interpolateOklabGradient(stops, t)` ensuring zero gray dead zone desaturation between complementary hues.
3. **Implement K-Means Color Swatch Extractor**: Create `src/core/color/swatch-extractor.ts` subsampling active image into $64\times 64$ grid and clustering into 5 dominant hexadecimal swatches.
4. **Implement 3D Color LUT Texture Loader**: Create WebGL2 3D texture allocator (`gl.texImage3D`) for `.cube` and Hald CLUT color grading files.
5. **Implement CMYK Separation Shader**: Build fragment shader decomposing RGB into Cyan, Magenta, Yellow, and Key channels for authentic 4-color print emulation.
6. **Implement 4D Simplex Noise Loop Shader**: Build `src/effects/shaders/simplex-loop.glsl` embedding time parameter into a circle in 4D noise space for seamless time loops.
7. **Implement Directional Sobel Gradient Operator**: Build multi-tap Sobel edge detection kernel calculating gradient magnitude and normal angle.
8. **Implement Discrete Cosine Transform (DCT) Block Quantizer**: Create $8\times 8$ JPEG macroblock artifact simulation shader with adjustable compression quality factor.
9. **Implement Golden-Ratio Temporal Blue Noise Generator**: Create blue noise sampler phase-shifted by $\Phi \approx 0.6180339887$ per frame.
10. **Implement Inverse-Distance Cursor Repulsion Physics**: Create `src/canvas/interaction/repulsion.ts` calculating radial repulsion vectors with spring-damper restitution.

## Category 2: WebGL2 Multi-Pass Compositor & Shaders (Prompts 11-20)
11. **Implement Ping-Pong WebGL2 Framebuffer Object (FBO) Manager**: Upgrade `src/core/gl-renderer.ts` with double-buffered textures to allow sequential chaining of arbitrary shader passes.
12. **Implement Mariskooli Fluted Pressed Glass Shader**: Create WebGL2 fragment shader evaluating polar scalloped heightmaps and normal-mapped caustic refraction.
13. **Implement Cast Glass Brick Lattice Shader**: Create architectural glass block shader with grid ribbing and internal chromatic edge dispersion.
14. **Implement Xerox Toner Melt & Heat Smear Shader**: Create separable horizontal transport smear shader simulating fuser roller failure.
15. **Implement Water Damage & Tide Line Shader**: Build capillary chromatographic dye migration shader accumulating dark solute borders.
16. **Implement Broken LCD / TFT Leak Shader**: Create active-matrix display crack shader showing isotropic liquid crystal fluid bleed and subpixel line dropouts.
17. **Implement Polarized Light Microscopy (PLM) Birefringence Shader**: Build mineral crystal stress shader generating interference colors matching the Michel-Lévy color chart.
18. **Implement Thin-Film Oil Pool Iridescence Shader**: Create optical path difference shader simulating petrol slicks and soap bubbles.
19. **Implement Thermal Topography False-Color Heatmap Shader**: Build false-color ironbow gradient mapping luminance with isoline contours.
20. **Implement Xenon Plasma Arc Electrical Filament Shader**: Create dielectric breakdown branching filament shader.

## Category 3: Retro Print, Dithering & Halftones (Prompts 21-30)
21. **Implement Atkinson 1-Bit Dither Kernel**: Create `src/effects/dither/atkinson.ts` implementing classic MacPaint 6/8 error distribution.
22. **Implement Oscillating Halftone Shader**: Build halftone shader modulating dot screen radius with sinusoidal temporal wave.
23. **Implement Hexagonal Halftone Screen**: Create halftone shader tiling dots on an equilateral triangular lattice.
24. **Implement Multi-Angle Crosshatch Engraving Shader**: Build 4-tier line screen shader at $0^{\circ}, 45^{\circ}, 90^{\circ}, 135^{\circ}$.
25. **Implement Stipple Poisson-Disk Shader**: Build stochastic stipple dot distribution clustering in shadow areas.
26. **Implement Sierra Two-Row & Sierra Lite Error Diffusion**: Create fast low-memory error diffusion kernels for mobile devices.
27. **Implement CRT Phosphor Triad & Scanline Shader**: Build Trinitron vertical subpixel stripe mask with scanline dimming.
28. **Implement VHS Tape Jitter & Magnetic Skew Shader**: Create horizontal head-switching glitch and chroma delay shader.
29. **Implement Duotone / Tritone Gradient Map Filter**: Create custom color grading filter remapping grayscale tones into 2 or 3 color stops.
30. **Implement 75-Palette Retro Quantization Table**: Build lookup table supporting Game Boy, CGA, Apple II, and Commodore 64 color sets.

## Category 4: Generative Layers & Vector Surfaces (Prompts 31-40)
31. **Implement Bicubic Bézier Mesh Gradient Layer**: Create `src/layers/generative/mesh-gradient.ts` evaluating 4x4 control points on GPU.
32. **Implement Interactive Tangent Handles for Mesh Gradient**: Add canvas viewport gizmo handles allowing direct manipulation of Bézier tangents.
33. **Implement Harmonic Sine-Wave Dot Grid Layer**: Create `src/layers/generative/harmonic-dots.ts` rendering transverse wave displacements on dot arrays.
34. **Implement SVG Vector Path Serializer for Dot Grids**: Build export converter translating harmonic dot grids into scalable `<svg>` circles.
35. **Implement 100-Pattern Procedural Tiling Library**: Create `src/layers/generative/patterns.ts` importing Pattern Craft's geometric, weave, and modern textures.
36. **Implement Bento Box Adaptive Mosaic Partition Layer**: Build rectangular mosaic layer with adjustable gutters and corner radii.
37. **Implement Textile Kilim & Knitted Embroidery Engine**: Build Canvas 2D textile simulator replacing pixel clusters with wool stitches and V-loops.
38. **Implement Dual-Script Typography (Arabic/Latin) ASCII Engine**: Create ASCII rasterizer with selectable Arabic and Latin font glyph sets.
39. **Implement Matrix Code Rain Typography Layer**: Build falling glyph rain with phosphor trails and leading highlights.
40. **Implement Subject Isolation Foreground Masking Kernel**: Create edge-gradient subject isolation filter separating figure from ground.

## Category 5: UI System, Context Preview & Hardware UX (Prompts 41-45)
41. **Implement 'Preview in Context' Canvas Overlay**: Create `src/components/canvas/ContextPreview.tsx` rendering mock web header, headline, and CTA buttons.
42. **Implement Viewport Pan/Zoom Readout HUD**: Add real-time screen-space coordinate HUD (`X 0.000 Y 0.000 Zoom 100%`) in canvas header.
43. **Implement 9-Point Social Aspect Ratio Resizer Toolbar**: Add aspect ratio selector with 9-point anchor registration lock.
44. **Implement Command Palette (Cmd+K) Fast Parser**: Build keyboard command overlay supporting natural language execution (`opacity 50`, `add halftone`).
45. **Implement Teenage Engineering Hardware Styling Tokens**: Integrate machined bevel shadows and tactile orange slab buttons into `src/styles.css`.

## Category 6: Animation, Timeline & Professional Export (Prompts 46-50)
46. **Implement Seamless Loop Parameter Controller**: Build timeline duration selector (2s to 10s) binding all procedural shaders to circular phase $\theta(t)$.
47. **Implement Client-Side WebCodecs MP4 Hardware Encoder**: Create `src/export/video-encoder.ts` recording canvas stream directly to H.264 MP4.
48. **Implement WebWorker Animated GIF Optimizer**: Build background worker encoding 60fps canvas animations to quantized GIF files.
49. **Implement Standalone Three.js HTML Single-File Exporter**: Create template generator packaging active shaders, canvas, and base64 assets into one standalone HTML file.
50. **Implement State URL Hash Serialization (`.effectsio`)**: Build `lz-string` compression engine encoding entire project layer stack into shareable URL parameters.
