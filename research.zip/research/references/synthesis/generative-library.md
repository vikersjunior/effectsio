# Generative Layer & Sub-Layer Taxonomy

## Overview
Generative layers generate synthetic imagery, geometry, or procedural patterns directly from mathematical formulas rather than photographic raster bitmaps.

## Generative Sub-Types for EffectsIO
```
GenerativeLayer
├── MeshGradient (Bicubic Bézier 4x4 Lattice)
├── DotGridPhysics (Interactive Cursor Repulsion)
├── HarmonicWaves (Transverse Sine-Wave Dot Arrays)
├── ProceduralPatterns (100+ CSS/SVG Repeaters)
│   ├── Geometric (Grids, Checks, Diamonds)
│   ├── Weaves (Herringbone, Houndstooth, Plaid)
│   └── Modern (Honeycomb, Topography, Circuits)
├── BentoMosaic (Adaptive Bento Box Partitions)
└── FractalNoise (fBm, Simplex, Domain Warping)
```

## Layer Compositing Model
Generative layers can function as:
1. **Base Background**: Underneath image frames.
2. **Procedural Mask**: Defining alpha transparency or clipping boundaries for layers above.
3. **Additive Sheen / Overlay**: Blended over images via `screen`, `overlay`, or `color-dodge`.
