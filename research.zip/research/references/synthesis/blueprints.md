# Master Technical Implementation Blueprints

> [!NOTE]
> **Status**: `PROPOSED — NOT IMPLEMENTED` / `AWAITING APPROVAL`
> Every blueprint below details: *Reference -> Feature -> UX -> Parameters -> Visual Behavior -> Algorithm -> Shader -> Rendering -> Composition -> Animation -> State -> Export -> EffectsIO Native Implementation*.

---

## Blueprint 1: Physical Pressed Glass Simulation (`Mariskooli Glass`)
- **Reference**: Alembic Shader Lab (`lab.alembic.space`)
- **Feature**: Multi-fluted pressed glass refraction with rim scalloping and chromatic caustic dispersion.
- **UX**: Inspector panel with live sliders for Flute Count, Glass Thickness, Refractive Index, and Dispersion.
- **Parameters**:
  - `fluteCount`: Integer (4 to 48, default: 24)
  - `refractionStrength`: Float (0.0 to 1.0, default: 0.35)
  - `causticDispersion`: Float (0.0 to 0.1, default: 0.02)
  - `specularLuminance`: Float (0.0 to 1.0, default: 0.6)
- **Visual Behavior**: Simulates viewing an underlying image or gradient layer through decorative vintage pressed glassware. Light rays bend along fluting ridges, separating into faint rainbow color fringes along steep surface normals.
- **Algorithm**:
  - Convert normalized UVs to polar coordinates $(r, \theta)$.
  - Evaluate scalloped heightmap: $h(r, \theta) = \cos(N \theta) \cdot \sin(2\pi f r)$.
  - Calculate gradient normal via central differences: $\mathbf{N} = \text{normalize}(-\partial h/\partial x, -\partial h/\partial y, 1.0)$.
  - Sample texture at offset UVs using three independent wavelength indices ($n_R, n_G, n_B$).
- **Shader Pipeline**: WebGL2 multi-pass fragment shader writing to ping-pong FBO.
- **Composition**: Blends with base frame via `normal` or `screen`.
- **Animation**: Subtle rotational phase drift $\theta(t) = \theta + \omega t$.
- **State**: Serialized under `Layer.effects.mariskooli`.
- **Export**: Full-resolution PNG, WebP, and WebCodecs MP4 video.
- **EffectsIO Native Integration**: Lives in `src/effects/shaders/mariskooli-glass.glsl`, consumed by `gl-renderer.ts`.

---

## Blueprint 2: Analog Xerox Toner Melt & Heat Smear
- **Reference**: Alembic Shader Lab (`lab.alembic.space`)
- **Feature**: Physical emulation of laser printer fuser roller failure where black toner powder melts, smears, and streaks horizontally.
- **UX**: Slider controls for Roller Heat, Smear Direction, Threshold, and Particle Cohesion.
- **Parameters**:
  - `rollerHeat`: Float (0.0 to 1.0, default: 0.5)
  - `smearAngle`: Angle (0 to 360 deg, default: 0 deg)
  - `tonerThreshold`: Float (0.0 to 1.0, default: 0.35)
  - `streakLength`: Float (0 to 120px, default: 40px)
- **Visual Behavior**: Dark ink/toner clusters streak along the transport axis, pooling into dense organic droplets while leaving feathered drag trails.
- **Algorithm**:
  - Sample luminance $Y$. Compare to `tonerThreshold`.
  - In active dark spans, evaluate directional 1D simplex noise along the transport vector.
  - Convolve horizontal neighbor samples weighted by exponential decay kernel $\exp(-x / \lambda)$.
- **Shader Pipeline**: Two-pass separable GLSL shader.
- **Composition**: Blended via `multiply` or `darken`.
- **EffectsIO Native Integration**: Lives in `src/effects/shaders/toner-melt.glsl`.

---

## Blueprint 3: OKLab Color Interpolation & Gradient Rail
- **Reference**: GradLab (`gradlab.app`)
- **Feature**: Strict perceptual lightness and chroma preservation during gradient blending.
- **UX**: Gradient bar with draggable color stops and OKLab space toggle.
- **Parameters**:
  - `stops`: Array of `{ position: number, color: string }`
  - `interpolationSpace`: Enum (`'srgb' | 'linear-rgb' | 'oklab'`)
- **Algorithm**: Converts sRGB stops to linear sRGB, transforms to OKLab via matrices $M_1, M_2$, linearly interpolates $(L, a, b)$, and transforms back to sRGB.
- **EffectsIO Native Integration**: Core utility in `src/core/color/oklab.ts`.

---

## Blueprint 4: Context Preview Overlays
- **Reference**: HeroKit (`herokit.app`)
- **Feature**: Overlaid functional mock UI components (Navbar, Headline, CTA buttons) over creative canvas.
- **UX**: Top toolbar button "Preview in Context" with dropdown choosing `Landing Page`, `Mobile App`, or `Editorial Banner`.
- **Visual Behavior**: Renders high-contrast crisp vector DOM typography and button components directly on top of the canvas viewport without affecting the underlying export buffer.
- **EffectsIO Native Integration**: React component in `src/components/canvas/ContextPreview.tsx`.

---

## Blueprint 5: WebCodecs Zero-Server MP4 Export
- **Reference**: Grainrad (`grainrad.com`)
- **Feature**: High-speed, client-side hardware-accelerated MP4 video recording.
- **UX**: Export modal option "MP4 Video" with resolution selector (1080p, 4K) and duration slider (2s to 10s).
- **Algorithm**:
  - Initializes `new VideoEncoder({ output: handleChunk, error: handleError })`.
  - Configures codec `avc1.42001f` (H.264 Baseline Level 3.1) or `avc1.640028` (High Profile Level 4.0).
  - Renders canvas frames at $60\text{fps}$ and queues `new VideoFrame(canvas, { timestamp })`.
  - Muxes NAL units into MP4 container using lightweight WebAssembly or pure JS MP4 box writer (`mp4-muxer`).
- **EffectsIO Native Integration**: Export module in `src/export/video-encoder.ts`.
