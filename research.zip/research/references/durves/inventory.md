# Durves — Product & Feature Inventory

- **URL**: `https://www.durves.com/`
- **Repository**: `https://github.com/filipeedr/durves`
- **License**: MIT License (Open Source)
- **Category**: Harmonic Sine-Wave Dot Grid Generator
- **Core Value Proposition**: Elegant, minimal procedural wave displacement applied to dot lattices with instant SVG vector path export.

## Key Controls
- Dot Size: Radius slider ($1.0\text{px}$ to $12.0\text{px}$).
- Grid Density: Columns ($10$ to $120$) and Rows ($5$ to $60$).
- Wave Parameters: Amplitude, wavelength, frequency, wave tilt angle ($0^{\circ}$ to $180^{\circ}$).
- Palette: Background color and dot fill color with gradient fade across amplitude.
