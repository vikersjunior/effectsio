# Durves — Harmonic Wave Displacement Mathematics

## Formulation
Each dot at grid index $(c, r)$ has baseline coordinate $(x_0, y_0) = (c \cdot s_x, r \cdot s_y)$. The wave displacement is computed as:

$$d(c, r, t) = \sum_{k=1}^K A_k \sin\big(k_x x_0 + k_y y_0 - \omega_k t + \phi_k\big)$$

$$\begin{bmatrix} x \\ y \end{bmatrix} = \begin{bmatrix} x_0 \\ y_0 \end{bmatrix} + d(c, r, t) \begin{bmatrix} -\sin\theta \\ \cos\theta \end{bmatrix}$$

Where $\theta$ is the propagation angle and $(-\sin\theta, \cos\theta)$ is the perpendicular transverse displacement vector. Dot radius can optionally be modulated proportional to local amplitude $|d|$.
