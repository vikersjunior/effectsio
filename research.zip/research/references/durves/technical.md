# Durves — Technical Architecture & Vector Export

- **Rendering Engine**: Dual-mode (HTML5 Canvas for 60fps real-time preview; DOM SVG for instant vector export).
- **SVG Generation**: Directly writes `<svg>` containing `<circle cx="..." cy="..." r="..." fill="..." />` nodes.
- **Lightweight Footprint**: Zero heavy 3D frameworks; pure vanilla math calculations under $15\text{KB}$ minified.
