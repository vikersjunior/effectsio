# fxstudio.site — Interaction & Responsive Canvas Scaling

- **Real-Time Drag & Crop**: Canvas supports direct pointer panning inside the crop bounds.
- **Responsive Zoom Preview**: Automatically recalculates canvas CSS display dimensions to fit user screen while preserving native export pixel dimensions.
