# fxstudio.site — Dominant Color Palette Extraction

## K-Means Swatch Extraction Algorithm
fxstudio extracts a 5-swatch palette using fast color clustering:
1. Subsample source image to a $64\times 64$ thumbnail.
2. Initialize 5 random cluster centroids in RGB space.
3. Assign each pixel to the nearest Euclidean centroid.
4. Update centroids to the mean of assigned pixels.
5. Iterate 5 to 10 cycles until centroid convergence.
6. Sort resulting swatches by visual prominence and export as hex codes.
