# fxstudio.site — Product & Feature Inventory

- **URL**: `https://fxstudio.site/`
- **Category**: Fast Client-Side Social Media Canvas Resizer & Utility Suite
- **Core Value Proposition**: Frictionless client-side resizing across 16+ social media aspect ratios with 9-point anchor registration, dominant color swatch extraction, and side-by-side compression inspection.

## Feature Matrix
- **Social Presets**: Instagram Post (1:1), Story (9:16), Landscape (1.91:1), Twitter/X Post (16:9), YouTube Thumbnail (16:9), TikTok (9:16), LinkedIn Banner (4:1).
- **Anchor Alignment**: 9-point registration grid (Top-Left, Top-Center, Top-Right, Middle-Left, Center, Middle-Right, Bottom-Left, Bottom-Center, Bottom-Right).
- **Background Fill Modes**: Solid Color, Blurred Asset Backdrop, Smart Dominant Swatch Fill, Transparent Padding.
- **Utility Tools**: Dominant Color Palette Extractor (k-means clustering), Image Compressor with real-time file size estimator.
