# fxstudio.site — Technical Architecture & Epistemic Audit

- **Execution Model**: Pure client-side HTML5 Canvas 2D operations (`canvas.getContext("2d")`). Zero images uploaded to any server.
- **Export**: Generates optimized JPEG or PNG blobs with configurable quality factor ($0.1$ to $1.0$).
- **Value for EffectsIO**:
  - Provides the canonical blueprint for EffectsIO's planned **Social Aspect Ratio Presets & Anchor Positioning** toolbar controls.
