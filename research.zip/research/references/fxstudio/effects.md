# fxstudio.site — Canvas Transform & Background Filling

## 9-Point Registration Math
Given container dimensions $(W_c, H_c)$ and original image dimensions $(W_i, H_i)$ scaled by factor $s$:
$$\Delta W = W_c - s W_i, \quad \Delta H = H_c - s H_i$$

The translation offset $(x_0, y_0)$ is determined by anchor coordinates $(\alpha_x, \alpha_y) \in \{0, 0.5, 1.0\}^2$:
$$x_0 = \alpha_x \cdot \Delta W, \quad y_0 = \alpha_y \cdot \Delta H$$

## Blurred Backdrop Fill
When fitting a portrait asset into a landscape container, the empty side margins are filled with a $40\times$ scaled, $60\text{px}$ Gaussian-blurred replica of the asset itself, providing a cohesive aesthetic fill.
