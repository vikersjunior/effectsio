# Dot Grid Background — Physics Algorithm & Repulsion Dynamics

## Equations of Motion (Verlet / Spring Integration)
For each dot $i$ with equilibrium anchor $\mathbf{x}_{0, i}$ and current position $\mathbf{x}_i$:

$$\mathbf{F}_{\text{spring}} = -k_s (\mathbf{x}_i - \mathbf{x}_{0, i})$$
$$\mathbf{F}_{\text{damping}} = -c_d \mathbf{v}_i$$

When pointer $\mathbf{p}$ enters interaction radius $R$:
$$\mathbf{r} = \mathbf{x}_i - \mathbf{p}, \quad r = \|\mathbf{r}\|$$
$$\mathbf{F}_{\text{repel}} = \begin{cases} k_r \left(1 - \frac{r}{R}\right)^2 \frac{\mathbf{r}}{r} & \text{if } r < R \\ 0 & \text{otherwise} \end{cases}$$

$$\mathbf{a}_i = \frac{\mathbf{F}_{\text{spring}} + \mathbf{F}_{\text{damping}} + \mathbf{F}_{\text{repel}}}{m}$$
$$\mathbf{v}_i(t + \Delta t) = \mathbf{v}_i(t) + \mathbf{a}_i \Delta t, \quad \mathbf{x}_i(t + \Delta t) = \mathbf{x}_i(t) + \mathbf{v}_i(t + \Delta t) \Delta t$$
