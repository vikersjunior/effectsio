# Dot Grid Background — Product & Feature Inventory

- **URL**: `https://playground.willnewton.dev/p/dot-grid-background`
- **Category**: Interactive Cursor-Reactive Physics Grid
- **Core Value Proposition**: Highly responsive background dot matrix that ripples, repels, and breathes dynamically under user pointer movement.

## Key Capabilities
- Uniform 2D lattice grid of circular dots.
- Dynamic pointer collision sphere with inverse-distance repulsion.
- Spring-damper restitution physics returning dots to equilibrium.
- Ambient harmonic breathing oscillator.
