# Ditther — Export Capabilities & Video Processing

## Export Formats
- **Static**: Lossless PNG (preserving crisp $1\times 1$ pixel grid without bilinear smoothing), SVG vector polygons for low-resolution pixel grids.
- **Motion**: Animated GIF with local palette optimization; MP4 video recording for animated loop sequences; spritesheet PNG for game developers.
