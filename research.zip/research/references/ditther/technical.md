# Ditther — Technical Architecture & Palette Quantization

## Palette Quantization Engine
Ditther supports both fixed retro palettes (Game Boy 4-shade, CGA Mode 1, Apple II, Commodore 64, Teletext, Cyberpunk Neon) and dynamic user duotone ramps.

### Nearest-Color Euclidean Search in OKLab:
$$d(\mathbf{C}_1, \mathbf{C}_2) = \sqrt{\Delta L^2 + \Delta a^2 + \Delta b^2}$$
For real-time performance on $4K$ bitmaps, Ditther pre-computes an octree or 3D lookup table (LUT) mapping RGB space into the active color palette.
