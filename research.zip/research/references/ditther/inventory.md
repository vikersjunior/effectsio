# Ditther — Product & Feature Inventory

- **URL**: `https://app.ditther.com/`
- **Category**: Professional Pixel Art & Dithering Suite
- **Core Value Proposition**: 75+ discrete dithering algorithms spanning ordered, error diffusion, blue noise, and clustered matrices, accompanied by duotone/tritone color grading and video timeline loops.

## Algorithm Taxonomy
1. **Ordered (Bayer)**: $2\times 2$, $3\times 3$, $4\times 4$, $8\times 8$, $16\times 16$.
2. **Error Diffusion**: Floyd-Steinberg, Atkinson (MacPaint classic), Sierra (3-row, 2-row, Lite), Jarvis-Judice-Ninke (JJN), Stucki, Burkes.
3. **Halftone Dots**: Circular dot screen, line screen, diamond cluster, orthogonal dot.
4. **Stochastic & Noise**: Blue noise spatial distribution, interleaved gradient noise, white noise threshold.
5. **Artistic & Geometric**: Crosshatch, serpentine weave, checkerboard, Hilbert space-filling curve.
