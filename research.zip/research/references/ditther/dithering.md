# Ditther — Dithering Mathematics & Error Diffusion Kernels

## Error Diffusion Kernel Formulations
Error diffusion processes pixels sequentially (raster scan or serpentine), distributing quantisation error $e = P(x, y) - Q(P(x, y))$ to neighboring unprocessed pixels.

### Atkinson Kernel (Classic MacPaint 1-bit Aesthetic):
$$\frac{1}{8} \begin{bmatrix} & * & 1 & 1 \\ 1 & 1 & 1 & \\ & 1 & & \end{bmatrix}$$
*Note: Atkinson diffuses only $\frac{6}{8} = 75\%$ of error, leaving $25\%$ to drop out, producing high-contrast crisp shadows without muddy noise.*

### Floyd-Steinberg Kernel:
$$\frac{1}{16} \begin{bmatrix} & * & 7 \\ 3 & 5 & 1 \end{bmatrix}$$

### Sierra Lite Kernel:
$$\frac{1}{4} \begin{bmatrix} & * & 2 \\ 1 & 1 & \end{bmatrix}$$
