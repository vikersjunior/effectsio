# The Ladybug — Motion & Animation Subsystem

## Animation Mechanics
- Over 45 of Ladybug's 67 effects are natively animated (`animated: true`).
- Frame generation is orchestrated via an internal timeline stepper that advances an internal frame index $k \in [0, K-1]$.
- Effects apply pseudo-random deterministic jitter based on seed:

$$\text{seed}(k) = \text{hash}(k \cdot 1664525 + 1013904223)$$

## Export Formats
- **Animated GIF**: Handled client-side via WebWorker-based GIF encoder (`omggif` or `gifshot`).
- **MP4 Video**: Generated via `canvas.captureStream(30)` fed into browser `MediaRecorder` or WebCodecs `VideoEncoder`.
- **SVG Vector**: Certain geometric effects (e.g. `vectorTiling`, `contour`) serialize directly into vector `<svg>` paths.
