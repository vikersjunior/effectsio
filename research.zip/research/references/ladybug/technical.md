# The Ladybug — Technical Architecture & Epistemic Audit

## Epistemic Classification: Source-Inspected Bundle (`effectRegistry-nXoZDYPO.js`)
- **Rendering Context**: Exclusively HTML5 2D Canvas (`canvas.getContext("2d")`).
- **Shader Code**: Zero WebGL shaders (`gl_FragColor: 0`, `precision: 0`, `WGSL: 0`).
- **Performance Profile**:
  - Processing operations run directly on `ImageData.data` Uint8ClampedArray buffers.
  - Utilizes pre-allocated typed arrays to minimize garbage collection pauses.
  - Chunked canvas processing prevents UI thread starvation on large assets ($4000\times 3000\text{px}$).
- **State Structure**:
  - Global `effectRegistry` maps effect IDs to metadata objects containing `id`, `label`, `category`, `animated`, `parameters`, and `render(ctx, image, params, frame)` execute callbacks.
