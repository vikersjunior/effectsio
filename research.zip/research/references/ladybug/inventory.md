# The Ladybug — Product & Feature Inventory

- **URL**: `https://app.theladybug.app/`
- **License**: Commercial SaaS (Proprietary)
- **Category**: Retro & Experimental Pixel Art Processing Studio
- **Architecture**: 100% Client-Side Canvas 2D CPU Pipeline (Zero Server Upload)
- **Core Value Proposition**: Comprehensive analog, glitch, dither, halftone, and typography manipulation with extreme privacy and zero backend dependencies.

## Verified Catalog: 67 Discrete Effects Across 9 Curated Categories
1. **Analog (2)**: `filmPrism` (Film Prism), `wave` (Wave Lines).
2. **Analog & Glitch (7)**: `crystal` (Crystal Glass), `glassDispersion` (Glass Pixel Dispersion), `ribbonScan` (Ribbon Scan), `pixelSort` (Pixel Sort), `glitch` (Glitch), `crtScreen` (CRT Screen), `vhs` (VHS).
3. **Edges & Outlines (5)**: `threshold` (Threshold), `contour` (Contour), `edge` (Edge Detection), `contourType` (Contour Type), `contourMap` (Contour Map).
4. **Experimental (5)**: `holo` (Holo), `stardust` (Stardust), `emberVeil` (Ember Veil), `kineticTrace` (Trace Motion), `rainReveal` (Rain Reveal).
5. **Halftone & Dither (16)**: `pixelDither` (Pixel Dither Glow), `risoGlow` (Riso Glow), `glitchGrid` (Glitch Grid), `crossStitch` (Cross Stitch), `pattern` (Pattern Halftone), `toneGeometry` (Tone Geometry), `paperPrint` (Pixel Press), `pixelPoster` (Pixel Poster), `dither` (Dithering), `halftone` (Halftone), `riso` (Riso), `scatterMosaic` (Scatter Mosaic), `driftLines` (Drift Lines), `retroMatrix` (Retro Matrix), `glyphMatrix` (Glyph Matrix), `symbolMatrix` (Symbol Matrix).
6. **Pixel & 3D (6)**: `blockify` (Blockify), `blockMosaic` (Block Mosaic), `quadtreeZoom` (Quadtree Zoom), `bricks` (3D Toy Bricks), `outline` (Outline), `voronoi` (Voronoi).
7. **Textile & Craft (6)**: `kilim` (Kilim Carpet), `embroidery` (Knitted Embroidery), `uiCollage` (Creative UI Collage), `vectorTiling` (Vector Engraving), `crosshatch` (Crosshatch), `stitchPoster` (Stitch Poster).
8. **Tracking & Interface (3)**: `hudTracker` (HUD Tracker), `brandGenerator` (Brand Generator), `cctv` (CCTV Surveillance).
9. **Type & Code (11)**: `ascii` (ASCII), `ditherText` (Dither Text), `wordMosaic` (Word Mosaic), `matrix` (Matrix Rain), `pixelCode` (Pixel Code), `numberField` (Number Field), `gridGlyph` (Grid Glyph), `capsuleCloud` (Tag Pills), `inscribe` (Inscribe), `dataHatch` (Data Hatching), `asciiGhost` (ASCII Ghost).
