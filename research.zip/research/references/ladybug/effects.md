# The Ladybug — Effect Mechanics & Technical Analysis

## Category Deep Dives

### 1. Textile & Craft Engine
- **`kilim` (Kilim Carpet)**: Subdivides the bitmap into diamond and chevron weave patterns. Samples average luminance per weave cell and renders cross-threaded wool warp/weft stitches using anti-aliased 2D canvas lines.
- **`embroidery` (Knitted Embroidery)**: Replaces pixel clusters with physical V-shaped yarn loops. Simulates thread thickness, directional stitch tilt, and fiber shadow cast.
- **`crossStitch`**: Converts image into an regular grid of crossed embroidery threads ($X$-stitches) with simulated canvas cloth backing.

### 2. Dual-Script Typography Engine (`Type & Code`)
- Supports simultaneous Latin and Arabic (`د ج ح خ ه ع غ ف ق ث ص ض`) glyph fonts.
- **`matrix` (Matrix Rain)**: Streams Katakana, Latin, Arabic, and numerical glyphs down vertical scan columns with luminance-proportional green/amber phosphor dropouts.
- **`wordMosaic`**: Renders custom user words or phrases scaled to fit luminance contours, packing text tighter in shadow areas.

### 3. Subject Isolation & Masking
- Contains a client-side edge-gradient subject isolation kernel (`subjectMaskKernel`).
- Allows effects to apply exclusively to the foreground figure or background ground, enabling selective retro treatment.
