# GradLab — Product & Feature Inventory

- **URL**: `https://www.gradlab.app/`
- **Category**: High-End WebGL Gradient & Generative Typography Studio
- **Target Audience**: Brand designers, web creative developers, digital artists.
- **Core Value Proposition**: Elimination of the "gray dead zone" in gradient blending through strict OKLab color space interpolation, coupled with 13 fluid dynamics modes, interactive ASCII matrices, and standalone HTML iframe exports.

## Core Feature Matrix
| Feature | Implementation | Key Parameters |
|---|---|---|
| **OKLab Color Engine** | WebGL Fragment Shader | Multi-stop color picker with perceptual lightness pinning |
| **Fluid Displacement** | Multi-pass Navier-Stokes / Perlin | Vorticity, viscosity, dissipation, flow speed |
| **ASCII Particle Matrix** | Overlay 2D Text Canvas | Character ramp presets, font size, density, inverted mode |
| **Interactive Mouse Repulsion** | Radial Pointer Physics | Falloff radius ($240\text{px}$), repulsion force, spring damping |
| **Viewport HUD** | Screen-space readout | Real-time pan coordinates (`X 0.000 Y 0.000`), zoom level |
| **Export Engine** | Multi-format | PNG, high-res WebP, SVG, and standalone responsive HTML iframe |
