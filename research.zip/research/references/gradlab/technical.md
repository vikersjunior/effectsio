# GradLab — Technical Architecture & Interaction Physics

## Interactive Pointer Repulsion Physics
GradLab executes an inverse-distance radial repulsion model on pointer hover:

```typescript
const POINTER_RADIUS = 240; // Pixels
function applyMouseRepulsion(particle, mouseX, mouseY) {
  const dx = particle.x - mouseX;
  const dy = particle.y - mouseY;
  const dist = Math.hypot(dx, dy);
  
  if (dist < POINTER_RADIUS && dist > 0.001) {
    const force = Math.pow(1 - dist / POINTER_RADIUS, 2.0); // Quadratic falloff
    const nx = dx / dist;
    const ny = dy / dist;
    particle.vx += nx * force * 12.0;
    particle.vy += ny * force * 12.0;
  }
}
```

## ASCII Density Character Ramps
GradLab uses curated density character sets:
- **Standard**: `@%#*+=-:. `
- **Block Elements**: `██▓▒░ `
- **Minimal Dot**: `•·. `
- **Binary**: `10 `
