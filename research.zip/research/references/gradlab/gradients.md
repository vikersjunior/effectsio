# GradLab — OKLab Gradient Mathematics & Fluid Dynamics

## OKLab Color Space Transformation
Standard RGB linear interpolation often produces dull, desaturated gray tones in intermediate gradient regions. GradLab computes all blends in Björn Ottosson's OKLab space:

### Linear sRGB to OKLab:
$$\begin{bmatrix} l \\ m \\ s \end{bmatrix} = \mathbf{M}_1 \begin{bmatrix} r_{\text{lin}} \\ g_{\text{lin}} \\ b_{\text{lin}} \end{bmatrix}$$

$$\mathbf{M}_1 = \begin{bmatrix} 0.4122214708 & 0.5363325363 & 0.0514459929 \\ 0.2119034982 & 0.6806995451 & 0.1073969566 \\ 0.0883024619 & 0.2817188376 & 0.6299787005 \end{bmatrix}$$

$$l' = l^{1/3}, \quad m' = m^{1/3}, \quad s' = s^{1/3}$$

$$\begin{bmatrix} L \\ a \\ b \end{bmatrix} = \mathbf{M}_2 \begin{bmatrix} l' \\ m' \\ s' \end{bmatrix}$$

$$\mathbf{M}_2 = \begin{bmatrix} 0.2104542553 & 0.7936177850 & -0.0040720468 \\ 1.9779984951 & -2.4285922050 & 0.4505937099 \\ 0.0259040371 & 0.7827717662 & -0.8086757660 \end{bmatrix}$$

### Interpolation Invariant:
Colors are blended linearly along $(L, a, b)$:
$$\mathbf{C}_{\text{oklab}}(t) = (1-t) \mathbf{C}_1 + t \mathbf{C}_2$$
This ensures constant perceptual chroma and uniform lightness gradients across high-contrast complementary color stops.
