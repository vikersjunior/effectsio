# Performance & WebGL2 Resource Architecture Roadmap

> [!NOTE]
> **Status**: `PROPOSED — NOT IMPLEMENTED / AWAITING APPROVAL`

- **Texture Pooling**: Allocate exactly two ping-pong FBOs matching canvas dimensions; reuse across all passes.
- **Downsampling Optimization**: For heavy blur/refraction passes, render to half-resolution FBO ($W/2, H/2$) and upscale with linear filtering.
- **Zero GC Guarantee**: Pre-allocate all TypedArrays (`Float32Array`, `Uint8Array`) outside the render loop.
