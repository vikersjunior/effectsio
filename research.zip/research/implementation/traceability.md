# Complete Traceability & Research Origin Matrix

| Backlog ID | Feature Name | Research Origin | Empirical Finding | Governing ADR |
|---|---|---|---|---|
| `SH-001` | Ping-Pong WebGL2 FBO | Alembic Shader Lab | Multi-pass post stack in chunk 37531 | ADR-001 |
| `SH-002` | OKLab Color Engine | GradLab | OKLab matrix in step 188 bundle | ADR-003 |
| `SH-003` | Mariskooli Glass | Alembic Shader Lab | Fluting normal displacement in chunk 37531 | ADR-005 |
| `SH-005` | Xerox Toner Melt | Alembic Shader Lab | Fuser roller smear simulation in chunk 37531 | ADR-005 |
| `SH-006` | Water Damage Tide Line | Alembic Shader Lab | Capillary solute drying boundary | ADR-005 |
| `SH-007` | Broken LCD / TFT Leak | Alembic Shader Lab | Active-matrix liquid crystal bleed | ADR-005 |
| `SH-011` | Directional Pixel Sort | Grainrad | WebGPU compute sort in index-D5s-AdpN | ADR-006 |
| `SH-012` | Oscillating Halftone | Grainrad | Sinusoidal dot radius modulation | ADR-007 |
| `SH-021` | Temporal Blue Noise | Grainrad | Golden-ratio phase noise distribution | ADR-007 |
| `FX-001` | Atkinson 1-Bit Dither | Ditther / Ladybug | MacPaint 6/8 diffusion kernel | ADR-002 |
| `FX-012` | Textile Kilim Carpet | The Ladybug | Canvas 2D wool thread simulation in step 162 | ADR-002 |
| `FX-015` | Dual-Script ASCII | The Ladybug | Simultaneous Arabic & Latin glyph sets | ADR-008 |
| `GEN-001`| Bicubic Bézier Mesh | zoxilsi/studio | GPU Hermite surface evaluation in MIT repo | ADR-002 |
| `GEN-004`| Cursor Repulsion Field | GradLab / Dot Grid | Radial inverse-distance physics ($r = 240\text{px}$) | ADR-004 |
| `GEN-019`| 9-Point Social Resizer | fxstudio.site | Aspect frame transform and anchor lock | ADR-002 |
| `ANIM-001`| Seamless 4D Loops | Pryzm Studio | Circular 4D noise embedding | ADR-007 |
| `EXP-001`| WebCodecs MP4 Export | Grainrad | Zero-server browser video encoder | ADR-010 |
| `EXP-004`| Standalone 3.js HTML | Grainrad | Self-contained single-file HTML embed | ADR-011 |
