# Cross-Browser Compatibility & Fallback Verification Matrix

## Browser Capability Matrix
| Feature | Chrome / Chromium | Safari (Desktop & iOS) | Firefox | Fallback Strategy |
|---|---|---|---|---|
| **WebGL2 Ping-Pong** | Full Support | Full Support (iOS 15+) | Full Support | Fallback to CPU Canvas 2D |
| **WebCodecs MP4** | Full Support (Hardware) | Partial (Safari 16.4+) | In development | Fallback to `MediaRecorder` / GIF |
| **OKLab Shaders** | Full Support | Full Support | Full Support | sRGB interpolation fallback |
| **Interactive Repulsion** | 60fps | 60fps | 60fps | Graceful static grid |
| **WebGPU Compute** | Chrome 113+ | Safari Tech Preview | Firefox Nightly | Fallback to WebGL2 fragment |
