# Master Implementation Backlog

> [!NOTE]
> All items are marked **`PROPOSED — NOT IMPLEMENTED / AWAITING APPROVAL`**.

## 1. Shader Stack Backlog (`SH-001` to `SH-030`)
- `SH-001`: WebGL2 Ping-Pong FBO Multi-Pass Compositor Core.
- `SH-002`: OKLab Color Space Transformation & Perceptual Blending Shader.
- `SH-003`: Mariskooli Fluted Pressed Glass Refraction Shader.
- `SH-004`: Architectural Glass Brick Lattice & Waffle Wall Shader.
- `SH-005`: Analog Xerox Toner Melt & Heat Smear Shader.
- `SH-006`: Water Damage & Paper Chromatographic Tide Line Shader.
- `SH-007`: Broken LCD / Active-Matrix TFT Liquid Bleed Shader.
- `SH-008`: Polarized Light Microscopy (PLM) Birefringence Shader.
- `SH-009`: Thin-Film Oil Pool Iridescence Shader.
- `SH-010`: Thermal Topography Infrared Heatmap Shader.
- `SH-011`: Directional GPU Pixel Sorting Shader.
- `SH-012`: Oscillating Harmonic Halftone Shader.
- `SH-013`: Hexagonal Triangular Lattice Halftone Shader.
- `SH-014`: Multi-Angle Banknote Crosshatch Engraving Shader.
- `SH-015`: Stochastic Poisson-Disk Stipple Print Shader.
- `SH-016`: Trinitron CRT Phosphor Triad & Curvature Shader.
- `SH-017`: VHS Magnetic Tape Jitter & Head-Switch Skew Shader.
- `SH-018`: 3D Tetrahedral Color LUT Shader.
- `SH-019`: Discrete Cosine Transform (DCT) JPEG Artifact Shader.
- `SH-020`: Xenon High-Voltage Plasma Arc Filament Shader.
- `SH-021`: Golden-Ratio Temporal Blue Noise Dither Shader.
- `SH-022`: CMYK Four-Color Separation & Screen Angle Shader.
- `SH-023`: Birefringence Interference Optical Calcite Shader.
- `SH-024`: Separable Dual-Pass Gaussian Blur Shader.
- `SH-025`: Hexagonal Polygonal Camera Defocus Bokeh Shader.
- `SH-026`: Directional Motion Blur Velocity Shader.
- `SH-027`: Sobel Gradient Normal & Tangent Field Shader.
- `SH-028`: Crepuscular Volumetric God Rays Scattering Shader.
- `SH-029`: Prismatic Spectral Light Leak Dispersion Shader.
- `SH-030`: 4D Simplex Noise Seamless Loop Modulation Shader.

## 2. Pixel & Craft Effect Backlog (`FX-001` to `FX-050`)
- `FX-001`: Atkinson Classic 1-Bit Error Diffusion Kernel.
- `FX-002`: Floyd-Steinberg 16th Error Diffusion Kernel.
- `FX-003`: Sierra Two-Row & Sierra Lite Fast Diffusion Kernels.
- `FX-004`: Jarvis-Judice-Ninke (JJN) 12-Neighbor Diffusion Kernel.
- `FX-005`: Burkes Power-of-Two Fast Bitwise Diffusion Kernel.
- `FX-006`: Hilbert Fractal Space-Filling Curve Halftone.
- `FX-007`: Duotone / Tritone Gradient Map Filter.
- `FX-008`: Game Boy 4-Shade Olive Green Quantization.
- `FX-009`: CGA Mode 1 Cyan/Magenta 4-Color Quantization.
- `FX-010`: Commodore 64 16-Color Luma-Biased Quantization.
- `FX-011`: Apple II NTSC Chroma Subcarrier Fringe Filter.
- `FX-012`: Textile Kilim Carpet Weave Simulator.
- `FX-013`: Knitted Wool Embroidery & V-Loop Yarn Simulator.
- `FX-014`: Aida Cloth Cross-Stitch Embroidery Simulator.
- `FX-015`: Dual-Script Latin/Arabic ASCII Typographic Rasterizer.
- `FX-016`: Falling Matrix Digital Code Rain Filter.
- `FX-017`: Contour Word Mosaic Text-Packing Filter.
- `FX-018`: 3D Interlocking Toy Plastic Brick Pixelator.
- `FX-019`: Adaptive Quadtree Edge-Preserving Subdivision Filter.
- `FX-020`: Riso Spot-Color Screen Glow & Ink Bleed Simulator.
- `FX-021` to `FX-050`: Curated analog, glitch, print, and pixel styling modules.

## 3. Generative Layer Backlog (`GEN-001` to `GEN-020`)
- `GEN-001`: Bicubic Bézier 4x4 Mesh Gradient Surface Layer.
- `GEN-002`: Interactive Viewport Gizmo Tangent Handles.
- `GEN-003`: Harmonic Sine-Wave Dot Grid Layer.
- `GEN-004`: Interactive Cursor Pointer Repulsion Physics Grid.
- `GEN-005`: Spring-Damper Lattice Restitution Physics.
- `GEN-006`: 100-Pattern Procedural SVG/CSS Pattern Library.
- `GEN-007`: Hexagonal Honeycomb Procedural Pattern.
- `GEN-008`: Isometric 3D Cube Illusion Pattern.
- `GEN-009`: Houndstooth Broken Check Textile Pattern.
- `GEN-010`: Herringbone Interlocking Parquet Tile Pattern.
- `GEN-011`: Tartan Multilayer Scottish Plaid Generator.
- `GEN-012`: Archimedean Polar Spiral Ray Pattern.
- `GEN-013`: Multi-Octave Topography Elevation Contour Pattern.
- `GEN-014`: Bento Box Adaptive Rectangular Mosaic Mask Layer.
- `GEN-015`: Voronoi Cellular Tessellation Mask Layer.
- `GEN-016`: Luminous Stroke Rail Generative Ribbon Layer.
- `GEN-017`: K-Means 5-Cluster Dominant Color Swatch Extractor.
- `GEN-018`: Subject Isolation Edge-Gradient Masking Kernel.
- `GEN-019`: 9-Point Social Aspect Ratio Frame Registration.
- `GEN-020`: Blurred Image Backdrop Canvas Margin Filler.

## 4. Animation & Temporal Backlog (`ANIM-001` to `ANIM-015`)
- `ANIM-001`: Seamless 4D Circular Phase Temporal Engine.
- `ANIM-002`: Continuous Harmonic LFO Oscillator.
- `ANIM-003`: Interactive Pointer Hover Repulsion Loop.
- `ANIM-004`: Multi-Track Timeline Keyframe Sequencer.
- `ANIM-005`: Cubic Bézier Curve Easing Evaluator.
- `ANIM-006` to `ANIM-015`: Procedural drifts, flickers, and jitter engines.

## 5. Export Engine Backlog (`EXP-001` to `EXP-015`)
- `EXP-001`: Client-Side WebCodecs Hardware H.264 MP4 Video Encoder.
- `EXP-002`: WebWorker-Accelerated Animated GIF Exporter.
- `EXP-003`: Scalable Vector SVG Path Serializer.
- `EXP-004`: Standalone Three.js Single-File HTML Exporter.
- `EXP-005`: Compressed URL Hash Project Serializer (`.effectsio`).
- `EXP-006` to `EXP-015`: High-resolution PNG, WebP, CSS snippet exporters.

## 6. Performance Backlog (`PERF-001` to `PERF-010`)
- `PERF-001`: Ping-Pong FBO Texture Pool & Swap Cache.
- `PERF-002`: WebGL2 Context Loss & Restoration Lifecycle.
- `PERF-003`: Pre-allocated TypedArray Buffers (Zero Garbage Collection).
- `PERF-004` to `PERF-010`: Texture downsampling, tile streaming, and memory limits.
