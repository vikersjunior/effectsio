# 2D Canvas & Pixel Effect Roadmap

> [!NOTE]
> **Status**: `PROPOSED — NOT IMPLEMENTED / AWAITING APPROVAL`

## Phase 1: Advanced Dithering & Quantization
- Implement Atkinson MacPaint 1-Bit Dither (`FX-001`).
- Implement Floyd-Steinberg and Sierra Lite Kernels (`FX-002`, `FX-003`).
- Implement Retro Palettes (Game Boy, CGA, C64) (`FX-008`, `FX-009`, `FX-010`).

## Phase 2: Typographic & Code Engines
- Implement Dual-Script (Arabic/Latin) ASCII Matrix (`FX-015`).
- Implement Matrix Digital Rain (`FX-016`).
- Implement Word Mosaic Contour Packing (`FX-017`).

## Phase 3: Textile & Craft Emulation
- Implement Kilim Carpet Weaving Simulator (`FX-012`).
- Implement Knitted Wool Embroidery Simulator (`FX-013`).
- Implement Riso Glow Spot Color Bleed (`FX-020`).
