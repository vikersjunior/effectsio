# EffectsIO — Repository & Architecture Baseline Audit

## Current Architecture Baseline
- **Application Core**: React 18, Vite, TypeScript with strict typechecking (`pnpm typecheck` enforced with zero errors).
- **Design System & Tokens**: Centralized in `src/styles.css` using CSS custom variables (`--background`, `--foreground`, `--primary`, `--radius`).
- **Iconography**: Exclusively `@phosphor-icons/react` using canonical sizes (`ICON_SIZES` from `src/components/ui`).
- **State Management**:
  - `activeImageId` is the single source of truth for active canvas asset selection (Rule 8).
  - Non-destructive image editing model preserving original source bitmaps.
- **Rendering Pipeline**:
  - Dual-mode architecture: CPU pixel transformations in `src/effects/modules/` and hardware WebGL2 compositor in `src/core/gl-renderer.ts`.
- **Approval Gate Invariants**:
  - `docs/approvals/stage-1-frame-layer.md` is approved (`APPROVED: 2026-09-05`).
  - `docs/approvals/stage-1-frame-layer-review.md` is currently pending owner implementation review.
  - Per Rule 12, mechanical approval gates must be strictly checked via `pnpm verify:approvals` before any code changes are made.

## Readiness for Reference Architecture Ingestion
1. **Compositor**: Ready for Ping-Pong FBO multi-pass post-processing pipeline.
2. **Layer Hierarchy**: Ready for Generative Layer subtype expansion once Stage 1 Frame/Layer is implemented.
3. **Color Engine**: Current sRGB pipeline requires upgrade to OKLab color space for premium gradient and blending fidelity.
