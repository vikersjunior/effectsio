# Looks & Curated Style Presets Roadmap

> [!NOTE]
> **Status**: `PROPOSED — NOT IMPLEMENTED / AWAITING APPROVAL`

- **Curated Look Packs**:
  - *Heirloom Glass*: Mariskooli fluting + caustic dispersion + chromatic split.
  - *Vintage Ephemera*: Toner melt + water damage tide line + paper grain.
  - *Cyberpunk 1984*: Trinitron CRT + pixel sort + neon chromatic glitch.
  - *Nordic Minimalism*: OKLab pastel flow + subtle dot grid + clean typography.
  - *Tactile Craft*: Kilim carpet weave + cross-stitch + linen cloth.
