# EffectsIO — Master Architecture & Implementation Plan (Parts 1–20)

> [!IMPORTANT]
> **GOVERNANCE STATUS**: `PROPOSED — NOT IMPLEMENTED` / `AWAITING APPROVAL`
> - This master plan represents the strategic architecture roadmap synthesized from the 14-tool reference intelligence investigation.
> - **ZERO APPLICATION CODE HAS BEEN MODIFIED.**
> - Implementation of any phase or task requires an explicit mechanical approval file (`docs/approvals/<phase-slug>.md`) verified by `pnpm verify:approvals` per Rule 12.

---

## Part 1: Executive Summary & Mission Scope
EffectsIO aims to be the premier browser-native creative effects and visual compositing platform. Following an exhaustive technical investigation across 14 state-of-the-art creative web applications (spanning pure WebGPU compute, WebGL2 multi-pass post-processing, Canvas 2D CPU processing, and procedural SVG/CSS engines), this plan defines the architectural roadmap to ingest the most powerful creative capabilities into EffectsIO natively.

The primary objectives are:
1. Evolve EffectsIO's rendering pipeline into a high-performance **Ping-Pong Multi-Pass WebGL2 Compositor**.
2. Establish strict **OKLab Perceptual Color Processing** across all gradients, blends, and color adjustments.
3. Expand layer capabilities beyond raster images into **Generative Vector & Procedural Surfaces** (Bézier mesh gradients, harmonic wave dot lattices, 100+ procedural pattern repeats).
4. Introduce museum-grade physical material simulations (**Mariskooli pressed glass**, **Xerox toner melt**, **water damage tide lines**, **broken LCD leaks**) engineered cleanroom.
5. Provide professional **Seamless 4D Time Loop Animation** and zero-server **WebCodecs Hardware MP4 Video Export**.

---

## Part 2: Governance, Approvals & Architectural Invariants
All implementation activities must comply strictly with the project rulebook:
- **Rule 1 — Literal Empirical Evidence Required**: Build logs, typecheck outputs (`pnpm typecheck`), and unit test runs required for every verification step.
- **Rule 2 — Design System Tokens**: All UI elements must consume tokens in `src/styles.css` (`var(--background)`, `var(--primary)`, `var(--radius)`).
- **Rule 5 — Icons & Sizing**: Exclusively `@phosphor-icons/react` using canonical `ICON_SIZES` from `src/components/ui`.
- **Rule 6 — Zero Type Errors**: 100% strict TypeScript compilation pass.
- **Rule 8 — Non-Destructive Source of Truth**: Original asset bitmaps remain pristine; `activeImageId` remains the single source of truth.
- **Rule 12 — Mechanical Approval Gates**: No phase implementation may begin without a signed approval file in `docs/approvals/<phase-slug>.md` passing `pnpm verify:approvals`.
- **Rule 14 & 15 — Public Provenance & Zero Competitor References**: No competitor names or external product references in any git-tracked repository file.

---

## Part 3: Architecture Overview (EffectsIO Post-Study Evolution)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          EFFECTSIO UNIFIED RUNTIME                          │
├─────────────────────────────────────────────────────────────────────────────┤
│  UI SHELL & INSPECTOR (React 18 + Phosphor Icons + CSS Tokens)             │
│  ├── Canvas Stage Viewport (Pinch-Zoom, Pan, Context Preview Mock, HUD)     │
│  ├── Layer Stack (Reorder, Group, Blend Modes, Opacity, Masks)              │
│  └── Inspector Panels (Scrubbable Number Inputs, Color Pickers, Presets)    │
├─────────────────────────────────────────────────────────────────────────────┤
│  COMPOSITING & RENDER ENGINE                                                │
│  ├── Frame / Layer Compositor (Stage 1 Architecture)                        │
│  │   ├── Image Layers (Raw Bitmaps, Transforms)                             │
│  │   ├── Generative Layers (Bézier Mesh, Dot Grid, Procedural Patterns)     │
│  │   └── Adjustment Layers (Global Post-Processing Stacks)                  │
│  ├── WebGL2 Ping-Pong FBO Multi-Pass Post-Processor                         │
│  │   ├── Double-Buffered Ping-Pong FBOs (fboA <-> fboB)                     │
│  │   ├── Standardized Uniform Blocks (FrameUniforms std140)                 │
│  │   └── Cleanroom Shader Library (Glass, Ephemera, Glitch, Halftone)       │
│  └── CPU Canvas 2D Fallback Subsystem (Pure TypedArray Image Transformations│
├─────────────────────────────────────────────────────────────────────────────┤
│  CORE FOUNDATIONS                                                           │
│  ├── OKLab Color Space Math (Perceptual Lightness, Chroma, Gradient Interpol│
│  ├── Seamless 4D Circular Phase Temporal Engine (Infinitely Looping Cycles) │
│  └── Client-Side Hardware Exporter (WebCodecs MP4, GIF Worker, Vector SVG)  │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Part 4: Frame / Layer Compositor Architecture Integration
EffectsIO's approved Stage 1 Frame/Layer model establishes the layer hierarchy. This reference study enriches the layer types:
1. `RasterLayer`: High-resolution source bitmaps with non-destructive spatial transformations (scale, translate, rotate).
2. `GenerativeLayer`: Procedural surfaces (Bézier mesh gradient, harmonic dot grid, pattern repeaters) evaluated mathematically.
3. `MaskLayer`: Luminance, alpha, or vector paths (such as Bento grids or subject isolation masks) clipping child layers.
4. `AdjustmentLayer`: Chains one or more post-processing shaders over the composite buffer below it.

---

## Part 5: WebGL2 Multi-Pass Post-Processing Pipeline
To execute chained shader effects without readback latency:
- Allocate two Framebuffer Objects (`fboA`, `fboB`) matching canvas display dimensions.
- Pass 0 renders the active layer composite into `fboA`.
- Pass 1 binds `fboA` as `u_input_texture`, renders shader into `fboB`.
- Pass 2 binds `fboB`, renders next shader into `fboA`.
- Final Pass blits the active FBO directly to the screen canvas or export buffer.

---

## Part 6: Mathematical & Algorithmic Foundations
1. **OKLab Color Space**:
   All color arithmetic, multi-stop gradient stops, and color balance controls operate in $(L, a, b)$ to prevent gray desaturation dead zones.
2. **Seamless 4D Noise**:
   Temporal noise evaluates $\text{noise4D}(x, y, R\cos(2\pi t/T), R\sin(2\pi t/T))$ ensuring exact loop closure.
3. **Atkinson Error Diffusion**:
   Distributes 6/8ths of quantization error across 6 neighbors, leaving 2/8ths dropout for crisp high-contrast print lines.

---

## Part 7: Phase 1: Core Mathematical & Shader Primitives Roadmap
- Implement `src/core/color/oklab.ts` (bidirectional conversion & gradient interpolation).
- Implement WebGL2 Ping-Pong FBO pipeline in `src/core/gl-renderer.ts`.
- Implement Separable Gaussian Blur and Directional Sobel shaders.

---

## Part 8: Phase 2: Generative Layers & Vector Surface Systems
- Implement Bicubic Bézier 4x4 Mesh Gradient Layer (`GEN-001`).
- Implement Viewport Interactive Tangent Handles (`GEN-002`).
- Implement Harmonic Sine-Wave Dot Grid (`GEN-003`).
- Implement 100-Pattern Procedural SVG/CSS Library (`GEN-006`).

---

## Part 9: Phase 3: Advanced Pixel Engines (Textile, Type, Halftone)
- Implement Dual-Script (Arabic/Latin) ASCII Typographic Rasterizer (`FX-015`).
- Implement Oscillating Halftone Shader (`SH-012`).
- Implement Textile Kilim Carpet & Knitted Yarn Simulator (`FX-012`, `FX-013`).
- Implement Atkinson 1-Bit Dither Kernel (`FX-001`).

---

## Part 10: Phase 4: WebGPU Compute & High-Performance Pass Graph
- Progressive enhancement check for `navigator.gpu`.
- Implement GPU Directional Pixel Sorting Compute Shader (`SH-011`).
- Implement High-Density Particle Repulsion Physics.

---

## Part 11: Phase 5: Animation Engine, LFOs & Seamless Loops
- Implement 4D Circular Phase Temporal Controller (`ANIM-001`).
- Implement Timeline Duration Selector ($2\text{s}$ to $10\text{s}$) with seamless loop enforcement.
- Implement Interactive Mouse Hover Spring Physics (`ANIM-003`).

---

## Part 12: Phase 6: Design System, Context Preview & Hardware UX
- Implement "Preview in Context" Decoupled DOM Overlays (`src/components/canvas/ContextPreview.tsx`).
- Implement Real-Time Viewport Pan/Zoom Coordinate HUD (`ViewportHud.tsx`).
- Implement 9-Point Social Aspect Ratio Frame Resizer with Anchor Lock.
- Refine Hardware-Inspired Skeuomorphic Accent Tokens in `src/styles.css`.

---

## Part 13: Phase 7: Professional Export Engine & Code Generation
- Implement Client-Side WebCodecs Hardware H.264 MP4 Video Encoder (`EXP-001`).
- Implement WebWorker-Accelerated Animated GIF Exporter (`EXP-002`).
- Implement Scalable Vector SVG Path Serializer (`EXP-003`).
- Implement Standalone Single-File Three.js HTML Exporter (`EXP-004`).
- Implement Compressed Project URL State Sharing (`EXP-005`).

---

## Part 14: Quality Assurance, Automated Testing & Verification
- Unit test suite for color transformations, matrix math, and kernel calculations.
- Headless WebGL2 render tests asserting pixel tolerances against golden test images.
- Memory leak test asserting zero retained textures across 100 layer mutations.
- Strict typecheck verification (`pnpm typecheck`) with zero warnings.

---

## Part 15: Cross-Browser Compatibility & Fallback Architecture
- Full WebGL2 support across Chrome, Firefox, Safari (desktop & iOS).
- Fallback to Canvas 2D CPU processing when WebGL2 context creation fails.
- Fallback from WebCodecs to `MediaRecorder` or GIF on unsupported mobile browsers.

---

## Part 16: Legal, Licensing & Cleanroom Compliance Protocol
- Strict prohibition of copying proprietary code from Alembic Shader Lab or other proprietary targets.
- All shaders and algorithms derived cleanroom from public mathematical literature.
- Automated provenance check (`pnpm check:no-competitor-refs`) required before completing changes.

---

## Part 17: Traceability & Coverage Matrix
Every single backlog item maps 1:1 with its reference research origin, verified empirical bundle finding, and architectural decision record (as detailed in `traceability.md`).

---

## Part 18: Risk Management & Technical Contingencies
- **Risk 1: GPU Context Loss**: Mitigated via `webglcontextlost` event listeners and automatic resource restoration.
- **Risk 2: Heavy Shader Frame Drops**: Mitigated by rendering complex passes at half-resolution FBO and upscaling.
- **Risk 3: Memory Leaks in Video Encoding**: Mitigated by explicitly closing `VideoFrame` and `VideoEncoder` instances.

---

## Part 19: Full Phased Implementation Schedule
- **Phase 0**: Gate Approvals & Foundation Prep (Mechanical check).
- **Phase 1**: Core Math & Ping-Pong Compositor.
- **Phase 2**: Generative Vector Surfaces & Mesh Gradients.
- **Phase 3**: Analog Distress & Physical Glass Shaders.
- **Phase 4**: Pixel Art, Dithering & Typography Engines.
- **Phase 5**: Animation Engine & Seamless Time Loops.
- **Phase 6**: UI Hardware Tokens & Context Preview.
- **Phase 7**: Hardware MP4 & Standalone HTML Export.

---

## Part 20: The Single First Implementation Task (Detailed Specification)

> [!IMPORTANT]
> **EXACTLY ONE FIRST IMPLEMENTATION TASK IDENTIFIED**
> In strict accordance with the Mission Brief, this task is fully specified and implementation-ready, but **BLOCKED FROM IMPLEMENTATION** until formal project owner approval is granted via `docs/approvals/task-001-oklab.md`.

### Task Identification
- **Task ID**: `TASK-001`
- **Canonical Backlog Ref**: `SH-002` / `ADR-003`
- **Task Title**: **Implement Core OKLab Color Space Transformation & Perceptual Blending Engine**

### Exact Objective
Build the standalone, pure mathematical OKLab color engine in `src/core/color/oklab.ts` to provide bidirectional conversion between sRGB, Linear sRGB, and OKLab ($L, a, b$), as well as multi-stop perceptual gradient interpolation that completely eliminates the muddy gray dead zones common in standard sRGB blending.

### Prerequisites & Gate Verification
- Approval gate required: `docs/approvals/task-001-oklab.md` containing literal `APPROVED: <date>`.
- Verification command: `pnpm verify:approvals`.
- Git status must be clean before beginning.

### Target Files
- **[NEW]** `src/core/color/oklab.ts`: Core color space conversion and interpolation logic.
- **[NEW]** `src/core/color/oklab.test.ts`: Vitest unit tests verifying mathematical invariants.
- **[MODIFY]** `src/core/index.ts`: Export color utilities cleanly.

### Exact Mathematical Formulation & Algorithm
1. **sRGB to Linear sRGB**:
   $$C_{\text{lin}} = \begin{cases} \frac{C}{12.92} & \text{if } C \le 0.04045 \\ \left(\frac{C + 0.055}{1.055}\right)^{2.4} & \text{if } C > 0.04045 \end{cases}$$

2. **Linear sRGB to Cone Responses $(l, m, s)$**:
   $$\begin{bmatrix} l \\ m \\ s \end{bmatrix} = \begin{bmatrix} 0.4122214708 & 0.5363325363 & 0.0514459929 \\ 0.2119034982 & 0.6806995451 & 0.1073969566 \\ 0.0883024619 & 0.2817188376 & 0.6299787005 \end{bmatrix} \begin{bmatrix} r_{\text{lin}} \\ g_{\text{lin}} \\ b_{\text{lin}} \end{bmatrix}$$

3. **Nonlinear Compression & OKLab Transformation**:
   $$l' = l^{1/3}, \quad m' = m^{1/3}, \quad s' = s^{1/3}$$
   $$\begin{bmatrix} L \\ a \\ b \end{bmatrix} = \begin{bmatrix} 0.2104542553 & 0.7936177850 & -0.0040720468 \\ 1.9779984951 & -2.4285922050 & 0.4505937099 \\ 0.0259040371 & 0.7827717662 & -0.8086757660 \end{bmatrix} \begin{bmatrix} l' \\ m' \\ s' \end{bmatrix}$$

4. **Bidirectional Inverse Transformation**:
   The inverse operations are computed using exact inverse matrices $\mathbf{M}_2^{-1}$ and $\mathbf{M}_1^{-1}$ followed by gamma expansion.

### Logic Specification & Function Signatures
```typescript
export interface RGB { r: number; g: number; b: number; }
export interface OKLab { L: number; a: number; b: number; }
export interface ColorStop { position: number; color: RGB; }

export function srgbToLinear(c: number): number;
export function linearToSrgb(c: number): number;
export function srgbToOklab(rgb: RGB): OKLab;
export function oklabToSrgb(lab: OKLab): RGB;
export function interpolateOklab(c1: RGB, c2: RGB, t: number): RGB;
export function interpolateMultiStopOklab(stops: ColorStop[], t: number): RGB;
```

### State & Store Updates
- None required for this foundational unit; exports pure side-effect-free math functions consumable by downstream layer stores and shaders.

### Inspector UI Controls
- None in this task (pure mathematical module). Downstream tasks will expose OKLab interpolation toggles in the Gradient and Color Balance panels.

### Test Strategy
1. **Unit Test Suite (`oklab.test.ts`)**:
   - Roundtrip fidelity: `oklabToSrgb(srgbToOklab(c)) == c` within $\epsilon = 10^{-4}$ across 1,000 random RGB colors.
   - Known reference vectors: Verify pure White, Black, Red, Green, Blue match Ottosson's published standard OKLab values.
   - Non-desaturation invariant: Verify that blending complementary colors (e.g. Blue `#0000ff` and Yellow `#ffff00`) maintains perceptual chroma $C = \sqrt{a^2 + b^2} > 0.12$ at $t = 0.5$ (whereas standard sRGB drops to muddy gray $C \approx 0.0$).
2. **Performance Benchmark**:
   - 1,000,000 conversions executed in $< 100\text{ms}$ on CPU.

### Verification Evidence Required (Rule 1)
- Output of `pnpm test src/core/color/oklab.test.ts` showing all test cases passing.
- Output of `pnpm typecheck` showing 0 errors.
- Output of `pnpm check:no-competitor-refs` showing pass.

### Risk & Rollback Strategy
- Zero risk to existing application: `src/core/color/oklab.ts` is an additive pure library file with zero side effects on current render loops.
- Rollback: Simple deletion of `src/core/color/` files restores exact previous state.
