# Export Engine & Format Architecture Roadmap

> [!NOTE]
> **Status**: `PROPOSED — NOT IMPLEMENTED / AWAITING APPROVAL`

- **Milestone 1**: Client-Side WebCodecs H.264 MP4 Hardware Video Encoder (`EXP-001`).
- **Milestone 2**: WebWorker Quantized Animated GIF Exporter (`EXP-002`).
- **Milestone 3**: Clean Vector SVG Path Exporter (`EXP-003`).
- **Milestone 4**: Standalone Single-File Three.js HTML Exporter (`EXP-004`).
- **Milestone 5**: Compressed Project URL State Sharing (`EXP-005`).
