# Architecture Decision Records (ADRs)

> [!NOTE]
> All records are marked **`PROPOSED — NOT IMPLEMENTED / AWAITING APPROVAL`**.

## ADR-001: WebGL2 Multi-Pass Framebuffer Ping-Pong Pipeline
- **Context**: Currently, EffectsIO applies shaders in single-pass executions. Complex reference effects (e.g. Mariskooli glass + Toner Melt + Halftone) require sequential multi-pass execution.
- **Decision**: Introduce a double-buffered ping-pong Framebuffer Object (FBO) system (`fboA`, `fboB`) in `src/core/gl-renderer.ts`. Each active effect reads from the current read-buffer and writes to the write-buffer, swapping pointers per pass.
- **Consequences**: Enables arbitrary chaining of shader passes with zero intermediate CPU readback.

## ADR-002: Frame/Layer Procedural Node Architecture
- **Context**: EffectsIO is currently image-centric. Generative backgrounds, dot grids, and patterns require non-bitmap layer representations.
- **Decision**: Extend Stage 1 Layer models with `LayerKind: 'image' | 'generative' | 'text' | 'adjustment'`.
- **Consequences**: Unlocks procedural mesh gradients, dot lattices, and patterns while preserving non-destructive compositing.

## ADR-003: OKLab / Linear Color Space Processing Invariant
- **Context**: sRGB linear interpolation causes muddy desaturated gray tones in gradient blends.
- **Decision**: Mandate that all color ramps, procedural gradients, and shader color arithmetic execute in OKLab color space.
- **Consequences**: Perceptually uniform lightness and vibrant chroma across all color blending operations.

## ADR-004: Interactive Repulsion Fields & Mouse HUD
- **Context**: Static creative canvases lack visceral tactile responsiveness.
- **Decision**: Add pointer coordinate tracking to canvas stages, feeding normalized mouse coordinates and velocities into shaders and dot grids, accompanied by a real-time coordinate HUD.
- **Consequences**: High-end interactive feedback matching GradLab and Dot Grid Background.

## ADR-005: Cleanroom Shader Synthesis vs Proprietary Re-implementation
- **Context**: Reference tools like Alembic Shader Lab are proprietary with strict TOS prohibiting copying.
- **Decision**: EffectsIO will NEVER copy or ingest proprietary shader code. All shaders are synthesized cleanroom from published optical physics, mathematical papers, and generic graphics principles.
- **Consequences**: Absolute legal compliance and copyright protection.

## ADR-006: WebGPU Compute Shaders (Phase 4+ Progressive Enhancement)
- **Context**: Effects like real-time pixel sorting are highly computationally intensive on WebGL2 fragment shaders.
- **Decision**: Keep WebGL2 as universal baseline; introduce WebGPU compute shaders via progressive enhancement when `navigator.gpu` is present.
- **Consequences**: 60fps performance on high-resolution $4K$ pixel sorting.

## ADR-007: Seamless Time Loop Animation & Keyframing Engine
- **Context**: Users demand animated GIF and MP4 exports for social media and web banners.
- **Decision**: Enforce 4D circular phase parameterization ($R\cos\theta, R\sin\theta$) for all temporal noise and waves.
- **Consequences**: Guarantees mathematically seamless loops with zero jump seams.

## ADR-008: Dual Alphabet (Arabic/Latin) Typography in Canvas
- **Context**: The Ladybug verified immense aesthetic value in dual-alphabet typographic matrices.
- **Decision**: Incorporate simultaneous Arabic and Latin font glyph caches into the canvas text rasterizer.
- **Consequences**: Broadens global accessibility and creates distinctive international typographic aesthetics.

## ADR-009: Context Preview Mock Overlays
- **Context**: Users often export graphics only to find web typography illegible over the generated background.
- **Decision**: Add a decoupled "Preview in Context" DOM overlay mode rendering mock navigation, headlines, and CTAs.
- **Consequences**: Solves contrast and visual hierarchy problems before export.

## ADR-010: Zero-Server Client-Side Video & Stream Export
- **Context**: Server-side video rendering is slow, expensive, and compromises user privacy.
- **Decision**: Utilize browser WebCodecs `VideoEncoder` and WebAssembly MP4 muxers for 100% local client-side video export.
- **Consequences**: Instant zero-latency MP4 export with zero server costs.

## ADR-011: Unified Preset Serialization & State URL Sharing
- **Context**: Users need to save, share, and bookmark complex multi-layer configurations.
- **Decision**: Serialize project state into standard `.effectsio` JSON and compressed `lz-string` URL parameters.
- **Consequences**: Frictionless sharing across community and client workflows.

## ADR-012: Strict Memory Budget & WebGL Context Conservation
- **Context**: Multiple WebGL contexts or unbounded texture allocations lead to browser tab crashes on mobile/low-end devices.
- **Decision**: Enforce single WebGL2 context ownership and strict texture pooling with LRU eviction.
- **Consequences**: 100% rock-solid runtime stability across all target devices.
