# Shader Integration Roadmap

> [!NOTE]
> **Status**: `PROPOSED — NOT IMPLEMENTED / AWAITING APPROVAL`

## Phase 1: Core Mathematical & Ping-Pong Foundations
- Implement Ping-Pong FBO pipeline (`SH-001`).
- Implement OKLab Color Space Transformation (`SH-002`).
- Implement Separable Gaussian Blur (`SH-024`) and Sobel Operator (`SH-027`).

## Phase 2: Physical Materials & Optical Glass
- Implement Mariskooli Pressed Glass (`SH-003`).
- Implement Glass Brick Lattice & Waffle Wall (`SH-004`).
- Implement Thin-Film Oil Pool Iridescence (`SH-009`).

## Phase 3: Analog Distress & Print Ephemera
- Implement Xerox Toner Melt (`SH-005`).
- Implement Water Damage Tide Line (`SH-006`).
- Implement Broken LCD / TFT Leak (`SH-007`).
- Implement Polarized Light Microscopy (`SH-008`).

## Phase 4: Retro CRT & Glitch
- Implement Trinitron CRT Curvature & Triad Scanlines (`SH-016`).
- Implement Directional Pixel Sorting (`SH-011`).
- Implement VHS Tape Jitter & Head Switching (`SH-017`).
