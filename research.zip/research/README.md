# EffectsIO Local Research

This directory contains completed reference intelligence and future implementation planning.

It is intentionally Git-ignored.

It is NOT part of the public EffectsIO repository.

The material is research/planning only.

Nothing in this directory should be treated as implemented functionality.

Actual implementation requires separate project-owner approval and a future implementation task.
