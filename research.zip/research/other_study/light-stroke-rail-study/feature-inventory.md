# Feature Inventory & Reference Study: Light Stroke Rail

**Target URL**: `https://light-stroke-rail.vercel.app/`  
**Study Date**: 2026-09-03  
**Study Status**: `restored-local` & `source-verified` (Detailed DOM, runtime JS logic, and GLSL fragment shader inspection via source extraction)  
**Study Scope**: Product model, parametric generative architecture, visual system, interaction mechanics, and architectural mapping to EffectsIO.

---

## 1. Executive Summary

Light Stroke Rail is a focused, high-craft creative visual studio dedicated to generating animated parametric light-stroke compositions, glowing optical fans, chromatic ribbons, and procedural geometric fields. Built entirely with vanilla WebGL, HTML5, and CSS, it renders real-time procedural animations inside a single `<canvas id="stage">` element driven by a 2,300-line GLSL fragment shader and an $O(N)$ CPU-side Euclidean Distance Transform (EDT) generator.

The tool provides 38 distinct geometric shape modes (grouped into Fans & beams, Rings & tunnels, Flowers, Solids, Fields, and Custom drawn paths), skinning them through a shared manifold coordinate system $(u, v)$ where high-frequency periodic combs, travelling chromatic waves, and specular blowouts are applied uniformly. The user experience is immediate, responsive, and visually stunning: users can switch between instant preset looks, customize multi-stop gradient ramps, scrub parametric geometry sliders that dynamically adapt to the active shape, drag 4-point Bezier spline handles directly on the canvas, and export high-resolution stills (PNG up to 6000px), lossless JSON recipes, WebM/MP4 video loops, and custom LZW-encoded animated GIFs—all executed 100% in the client browser with zero backend dependencies.

For EffectsIO, Light Stroke Rail provides a masterclass in **how to build a rich, cohesive parametric generative visual engine**. While EffectsIO is a general-purpose, layer-first visual studio (supporting image imports, multi-layer compositions, photo adjustments, and pixel effect stacks), the techniques demonstrated in Light Stroke Rail provide a concrete blueprint for EffectsIO's planned **Generative Layer (PRD Section 16)**, **Generative Sub-layer Line/Comb Engine**, **In-Canvas Bezier Path Handles**, and **Client-Side GIF/Video Export Engine**.

---

## 2. Product Model

### 2.1 The Reference's Conceptual Model
Light Stroke Rail models the creative surface as a **single continuous procedural light field**. The user is not manipulating discrete scene objects, overlapping layer cards, or imported bitmap pixels. Instead, the user manipulates:
1. **A Global Coordinate Transform / Geometry Generator (`uShape`)**: Defines the 2D coordinate manifold $(u, v)$ across the screen space (e.g. perspective fan, concentric rings, logarithmic spiral, or Bezier spine).
2. **A Periodic Stroke / Comb Generator (`uLines`, `uEdge`, `uRibDepth`, `uRibSoft`)**: Carves the continuous geometry into discrete parallel ribbons or strokes with Gaussian cores, dark inter-rail troughs, and anti-aliased outer edges.
3. **A Travelling Chromatic Wave (`uFlow`, `uDwell`, `uRunV`, `uDelay`, `uJitter`)**: Propagates color stops from an editable gradient palette through the coordinate manifold over time, creating forward-marching light pulses or looping trails.
4. **An Atmospheric Optical Model (`uGain`, `uBloom`, `uBlow`, `uBlur`, `uGrain`, `uHollow`)**: Implements bloom halos, specular blowout to pure white at stroke cores, edge airbrushing, inner wall hollow-outlining, and analog film grain.

### 2.2 Comparison to EffectsIO's Product Model
```text
Light Stroke Rail Model                      EffectsIO Architecture
───────────────────────                      ──────────────────────
Single Procedural Canvas                     Project
         ↓                                      └── Frame (Canvas / Aspect Ratio)
Global Geometry Generator (uShape)                  └── Generative Layer (PRD Sec 16)
         ↓                                              ├── Sub-layer 1: Parametric Line/Comb
Transverse/Longitudinal Manifold (u, v)                 ├── Sub-layer 2: Palette / Color Run
         ↓                                              ├── Sub-layer 3: Atmosphere / Bloom
Comb & Travelling Phase Engine                          └── Sub-layer 4: Film Grain
         ↓                                      └── Layer Masks / Blend Modes
Output Render Buffer (WebGL)                    └── Downstream Effect Stack (PRD Sec 11)
```

**Key Distinction**: In Light Stroke Rail, the entire visual is a closed, monolithic pipeline where every control impacts the single output canvas. In EffectsIO, this capability should exist as a **first-class Generative Layer type** (`GenerativeLayer` with a `ParametricRays` or `LightStrokes` sub-layer). This allows users to combine these stunning light-stroke patterns with imported photographic assets, typography, masking, and downstream pixel effects (such as Halftone, Dither, or Analog Glitch).

---

## 3. Creative Workflow Study

The creative journey in Light Stroke Rail follows an intuitive progressive disclosure pattern:

```text
1. Entry / Landing
   • Canvas immediately renders a smooth, ambient, animated light-stroke fan at 60 FPS.
   • Left floating panel ("✦ Looks") reveals Theme Presets (color orbs) and Curated Templates.
   • Right floating panel reveals Shape Selection, dynamic parameter sliders, and timing controls.
   ↓
2. High-Level Exploration (1–2 clicks)
   • User clicks a Theme Preset orb (e.g. "arcs", "ember", "silk") -> Palette updates instantly with zero re-rendering lag.
   • User clicks a Template card (e.g. "pinwheel", "neon-rings", "shooting-star", "cosmos") -> Complete look (shape + sliders + palette) updates deterministically.
   ↓
3. Parametric Modification (Scrubbing / Dragging)
   • User changes the Shape dropdown -> The panel dynamically re-specs: irrelevant sliders hide, specialized sliders appear with domain-appropriate labels (e.g. "lobe width", "segments / turn", "cell width").
   • User adjusts sliders (`rails`, `core heat`, `stroke width`, `outer edge`) -> Immediate real-time WebGL uniform updates at 60 FPS.
   • For custom path modes (Shape 6, 26, 32), four circular handles appear on the canvas -> User directly drags control points to bend the spline.
   ↓
4. Fine-Tuning Motion & Optics
   • User adjusts Gradient Run (`run speed`, `run stretch`, `run spread`, `jitter`, `trail hold`).
   • User drags the interactive Cubic Bezier Easing curve editor to alter pulse velocity.
   • User adjusts Look parameters (`hollow`, `angle`, `grain`, `gain`, `bloom`, `blow-out`).
   ↓
5. Output / Export
   • User toggles UI off (`H` key or bottom bar toggle) to inspect full-screen canvas.
   • User clicks Export menu -> Selects PNG (rendered at 2x high-res up to 6000px), JSON recipe, 6s WebM/MP4, or 3s GIF.
   • A dedicated progress toast (`#toast`) displays live encoding percentages without blocking the UI.
```

**Observations on Friction**:
- Zero setup friction: No modals, no "New Project" wizard, no mandatory dimension selection before seeing visual beauty.
- Instant feedback: Every parameter alteration is reflected in the very next rendered frame (0ms latency).
- Progressive disclosure: 60+ parameters exist in total, but they are tucked into collapsible sections (`Templates`, `Shape`, `Lines`, `Timing`, `Look`) with only the essentials expanded by default.

---

## 4. Interaction Model Study

### 4.1 Direct Manipulation vs Panel Controls
1. **In-Canvas Spline Handles (`.hdl`)**:
   - **Trigger**: Selecting custom path shapes (Shape 6 `Shape shifter`, Shape 26 `Path echo`, Shape 32 `Trail`).
   - **Visual Response**: 4 translucent circular handles appear over the canvas with numbered tooltips (`path point 1..4`).
   - **Interaction**: Pointer-capture drag event updates `cfg.path[i]` in normalized canvas coordinates $(0..1, 0..1)$, immediately recomputing the cubic Bezier spline uniform (`uC0..uC3`) in the fragment shader.
   - **Significance for EffectsIO**: This is exactly the interaction needed for EffectsIO's upcoming vector mask handles and gradient direction vectors.

2. **Interactive Cubic Bezier Easing Editor (`#ease`)**:
   - **Trigger**: Dragging two color-coded control points (orange point $P_1$, mint point $P_2$) inside a 272×168px canvas.
   - **Visual Response**: Renders coordinate grid, linear diagonal guide, live curve plot, and control arms. Evaluates real-time Newton-Raphson Bezier inversion on pointer move.
   - **Resulting State**: Updates `cfg.ease[0..3]`, altering color flip timings in pulse mode.

3. **Slider Value Pill & Fill Track**:
   - **Affordance**: Sliders feature a CSS custom property `--p` (`0%..100%`) rendering a dark progress fill under the thumb, and `--pf` driving a floating value badge that travels with the slider head.
   - **Response**: Scrubbing triggers immediate uniform upload and auxiliary preview strip redrawing.

4. **Keyboard & Global Shortcuts**:
   - `H` / `h`: Toggles visibility of both left and right floating panels simultaneously.
   - `Enter` / `Space`: Operates collapsible section disclosure headers and preset chips.
   - `Esc` / Outside Click: Closes export dropdown menu.

---

## 5. Control & Parameter Architecture

Light Stroke Rail implements an extraordinarily sophisticated **Dynamic Slider Metasystem (`SLIDERS` + `SHAPE_UI`)**:

### 5.1 Dynamic Re-specification Engine
Rather than creating and destroying DOM nodes when the user switches shapes, Light Stroke Rail maintains a fixed pool of slider elements and dynamically re-specifies them via `row.setSpec(newLabel, newMin, newMax, newStep)` and `row.toggle(visible)`.

#### Configuration Table across Representative Modes:
| Mode ID & Name | Parameter Key | Dynamically Re-assigned Label | Range | Step | Shader Uniform |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **0: Perspective Fan** | `lines` | `rails` | 3 .. 40 | 0.5 | `uLines` |
| | `edge` | `outer edge` | 0.2 .. 2.5 | 0.01 | `uEdge` |
| | `base` | `base width` | 0.02 .. 0.6 | 0.005 | `uBase` |
| | `span` | `flare span` | 0.05 .. 2.0 | 0.005 | `uSpan` |
| | `flare` | `flare curve` | 0.05 .. 4.0 | 0.01 | `uFlare` |
| | `ribDepth` | `core heat` | 0.0 .. 1.0 | 0.01 | `uRibDepth` |
| | `ribSoft` | `stroke width` | 0.02 .. 0.6 | 0.005 | `uRibSoft` |
| **13: Flower (Petals)**| `lines` | `petals` | 3 .. 32 | 1.0 | `uLines` |
| | `warpA` | `swirl` | 0.0 .. 3.0 | 0.01 | `uWarpA` |
| | `warpB` | `center size` | 0.1 .. 3.0 | 0.01 | `uWarpB` |
| **28: ASCII Rain** | `p1` | `cells across` | 16 .. 110 | 1.0 | `uP1` |
| | `p2` | `blob scale` | 0.15 .. 1.5 | 0.01 | `uP2` |
| | `p3` | `rain speed` | 0.05 .. 2.0 | 0.01 | `uP3` |
| **30: Waist Arches** | `p3` | `waist height` | 0.05 .. 0.95 | 0.005 | `uP3` |
| | `warpA` | `waist x` | 0.0 .. 1.0 | 0.005 | `uWarpA` |
| | `warpB` | `lower half shift` | 0.0 .. 1.0 | 0.01 | `uWarpB` |
| | `blur` | `palette curve` | 0.3 .. 2.0 | 0.01 | `uBlur` |
| **31: Number (Contours)**| `p1` | `digit size` | 0.15 .. 0.95 | 0.005 | `uP1` |
| | `p2` | `tracking` | -0.2 .. 0.5 | 0.005 | `uP2` |
| | `lines` | `contours` | 3 .. 60 | 0.5 | `uLines` |
| **37: Tile Grid** | `p1` | `cells across` | 3 .. 24 | 1.0 | `uP1` |
| | `p2` | `fill chance` | 0.02 .. 0.6 | 0.01 | `uP2` |
| | `p3` | `reshuffle / s` | 0.05 .. 3.0 | 0.05 | `uP3` |
| | `warpA` | `tile inset` | 0.0 .. 0.4 | 0.005 | `uWarpA` |

### 5.2 Relevance to EffectsIO Inspector Architecture
In EffectsIO, effects currently declare fixed schemas (`ParameterDefinition[]`). Light Stroke Rail proves that when building **parametric generative sub-layers**, controls should be defined with **contextual metadata bindings**: a generic shader uniform (like `p1`, `p2`, `p3`, `warpA`) can be bound to different semantic labels and constraints depending on the primary generator mode chosen.

---

## 6. Visual Hierarchy & Surface Design

### 6.1 Layout & Spatial Economy
- **Canvas-to-Chrome Ratio**: $\approx 85\%$ canvas dominance. The stage canvas fills the entire background or framed viewport, with floating cards anchored to the corners.
- **Card Placement**:
  - Top-Left: Minimal branding badge (`✦ Light rails`) + Preset Chips + Template Cards.
  - Top-Right: Deep Parametric Controls Card (`#panel`, 280px wide).
  - Bottom Bar: Floating pill holding Pattern/Card Scene selector, UI toggle, and Export button.
- **Card Framing & Margins**: CSS variables `--frameT: 16px`, `--frameR: 16px`, `--frameB: 16px`, `--frameL: 16px` create uniform breathing room around floating surfaces.

### 6.2 Surfaces & Color Tokens
- **Base Background**: `#050508` to `#0d0f14` ultra-dark background with subtle 1px border lines (`rgba(255, 255, 255, 0.08)`).
- **Glassmorphism / Panel Surface**: Uses high-opacity dark surfaces (`#0d0f14` / `#12151c`) with subtle backdrop blur, preventing visual competition with the intense, glowing canvas colors underneath.
- **Micro-Interactions**: Hovering over preset chips or template icons triggers smooth 150ms border highlight shifts (`rgba(255, 255, 255, 0.25)`).

### 6.3 Typography
- **Font Stack**: Monospace accents (`ui-monospace, "SF Mono", Menlo, monospace`) for values, hex codes, and technical metrics; clean sans-serif (`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto`) for UI headers and labels.
- **Capitalization**: Strict lowercase / sentence case (`run speed`, `core heat`, `digit size`, `hollow`), lending an understated, utilitarian, engineering-grade feel.

---

## 7. Canvas & Workspace Experience

### 7.1 Viewport Sizing & DPI Handling
- **Device Pixel Ratio (DPR)**: Clamped to $\min(\text{devicePixelRatio}, 2)$ via `resize()` handler:
  ```javascript
  var dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width  = Math.round(canvas.clientWidth  * dpr);
  canvas.height = Math.round(canvas.clientHeight * dpr);
  gl.viewport(0, 0, canvas.width, canvas.height);
  ```
  This avoids severe GPU fill-rate exhaustion on 3x Retina displays while maintaining razor-sharp rendering.
- **Aspect Ratio Normalization**: The fragment shader normalizes horizontal coordinate $x$ by canvas aspect ratio:
  ```glsl
  float aspect = uRes.x / max(uRes.y, 1.0);
  float x = (uv.x - 0.5) * aspect;
  ```
  This ensures shapes (such as circular rings, flowers, and fans) never distort when the browser window is resized.

### 7.2 View Modes & Presentation
- **Full Immersion Toggle**: Pressing `H` or toggling the UI switch completely hides all HTML panels, leaving the pristine animated canvas running edge-to-edge.
- **Still vs Live Animation**: A URL parameter `?still=SECONDS` and global window helper `window.setStill(s)` allows freezing effect-time to capture exact still frames without halting the rendering loop.

---

## 8. Composition & Layer Model

### 8.1 Current Reference Limitation
Light Stroke Rail is **single-layer**. It does not support:
- Stacking two shapes simultaneously (e.g. a flower on top of a perspective fan).
- Importing an external image to blend underneath or over the strokes.
- Layer masks, clipping paths, or layer-specific blend modes.

### 8.2 EffectsIO Layer Architecture Mapping
In EffectsIO, this capability belongs inside the **Generative Layer**:
```text
Project
└── Frame
    ├── Image Layer (Active Bitmap / Subject)
    ├── Generative Layer: "Parametric Light Rails"
    │   ├── Generator Type: Perspective Fan / Cosmos / Ribbon / Arches
    │   ├── Comb Parameter Stack (Lines, Edge, Core Heat, Stroke Width)
    │   ├── Color Run Palette (Multi-stop gradient with dwell/spread)
    │   └── Atmospheric Bloom & Film Grain
    └── Layer Mask (Restricts light strokes to background or subject silhouette)
```
By bringing Light Stroke Rail's shader techniques into EffectsIO's multi-layer stack, users can composite these breathtaking light trails behind isolated portrait cutouts or blend them over photography using `Screen`, `Color Dodge`, or `Overlay` blend modes!

---

## 9. Generative & Procedural Techniques (Deep Technical Study)

Below are three standout mathematical and algorithmic techniques extracted from the reference's WebGL fragment shader and JavaScript engine.

### Technique 1: The Periodic Comb Filter with Gaussian Core Shading
#### Visual Effect
A smooth continuous wedge or shape silhouette is transformed into a dense array of luminous parallel ribbons or neon tubes. Each ribbon has an intense, white-hot specular center that blows out to white, surrounded by deep, saturated chromatic halos, separated by crisp dark gaps.

#### Algorithmic Principle
Rather than rendering geometric polylines or triangle meshes, the shader evaluates a periodic distance comb directly in screen-space $(u, v)$:
1. Rail Step & Normalization:
   $$stp = \frac{uEdge}{\max(uLines, 0.5)}$$
2. Periodic Distance from Rail Center:
   $$d = \frac{|u|}{stp} - \text{floor}\left(\frac{|u|}{stp} + 0.5\right)$$
   Here, $d \in [-0.5, 0.5]$ represents normalized distance from the nearest rail center.
3. Gaussian Core Evaluation with Anti-Aliasing Blending:
   $$blur = \text{clamp}\left(\frac{2.4}{\max(stp \cdot W \cdot uRes.x, 1.0)}, 0.0, 1.0\right)$$
   $$sg = \text{mix}(uRibSoft, 0.70, blur)$$
   $$core = \exp\left(-\frac{d^2}{2 \cdot sg^2}\right) \cdot \left(1.0 - \text{smoothstep}(uEdge \cdot 0.85, uEdge + 0.15, |u|)\right)$$
4. Non-Linear Floor Depth:
   $$floorK = 0.12 + 0.73 \cdot \text{smoothstep}(0.65, 1.0, uRibDepth)$$
   $$lane = \text{mix}(1.0 - floorK \cdot uRibDepth, 1.0 + 0.90 \cdot uRibDepth, core)$$

#### Core Parameters
- `uLines`: Number of rail strokes across the manifold.
- `uEdge`: Outer bounding threshold where strokes terminate.
- `uRibSoft`: Stroke width / Gaussian standard deviation.
- `uRibDepth`: Contrast depth of the inter-rail troughs.

#### EffectsIO Opportunity & Integration Notes
- **Opportunity**: A pure GLSL module (`src/rendering/shaders/generative/comb-filter.glsl`) or custom generative sub-layer.
- **Implementation Requirements**: Pass canvas resolution, line density, and softness uniforms into the fragment shader. Can be applied to procedural shapes, vector paths, or image edge-detection maps.

---

### Technique 2: CPU-Accelerated Exact Euclidean Distance Transform for Typographic Contours
#### Visual Effect
Typographic digits (Shape 31) or hand-drawn Bezier strokes (Shape 32) are surrounded by nested concentric neon contour rings that wrap smoothly around corners, interior holes (counters), and line caps without geometric tessellation artifacts or jagged terracing.

#### Algorithmic Principle
Rather than attempting complex geometric offsetting in WebGL or low-precision 8-bit distance approximations, Light Stroke Rail executes **Felzenszwalb & Huttenlocher's exact 1-D squared Euclidean Distance Transform** on the CPU:
1. Rasterizes glyphs or paths onto an offscreen 2D canvas at 420px height.
2. Extracts binary alpha occupancy: $gin[i] = on ? \infty : 0$ (interior distance), $gout[i] = on ? 0 : \infty$ (exterior distance).
3. Executes 1D parabolic lower-envelope distance transforms across rows, then across columns in $O(N)$ linear time:
   $$\text{edt1d}(f, d, v, z, n)$$
4. Combines signed distance: $d_{px} = \sqrt{gout} - \sqrt{gin}$.
5. Encodes signed distance with 16-bit precision across the R and G channels of an RGBA texture:
   $$q = \text{round}\left(\text{clamp}\left(\frac{d_{px} / H}{2 \cdot GLYPH\_R} + 0.5, 0, 1\right) \times 65535\right)$$
   $$\text{Tex.r} = q \gg 8, \quad \text{Tex.g} = q \& 255$$
6. Fragment shader decodes 16-bit float:
   $$e = \frac{S.r \cdot 255.0 \cdot 256.0 + S.g \cdot 255.0}{65535.0}, \quad u = (e - 0.5) \cdot 2.0 \cdot uGlyphR$$
7. Passes $u$ directly into the shared comb filter, producing pristine offset contour rails!

#### Core Parameters
- `uGlyphR`: Distance field range in frame-height units ($\pm 1.2$).
- `p1`: Glyph size / stroke width.
- `p2`: Tracking (letter spacing).

#### EffectsIO Opportunity & Integration Notes
- **Opportunity**: Typographic generative visual effects (e.g. glowing contour text, neon drop contours).
- **Implementation Requirements**: Port `edt1d`/`edt2d` into a utility helper (`src/rendering/gl/distance-transform.ts`). Upload 16-bit distance texture to a uniform sampler2D.

---

### Technique 3: Unified Traveling Wave Phase & Hue-Preserving Specular Rolloff
#### Visual Effect
Color bands travel along strokes with controllable speed, longitudinal stretch, transverse rail delay, and random jitter. As strokes reach peak intensity, their centers blow out to pure white without color distortion, while dying tails blur and dissolve smoothly into the dark substrate.

#### Algorithmic Principle
1. Unified Flow Axis:
   Each shape maps its flow direction to $v \in [0, 1]$.
2. Travelling Wave Phase Equation:
   $$\text{phase} = uTime \cdot uDwell - \min(|u|, uEdge) \cdot uDelay \cdot 2.0 - (1.0 - v) \cdot uRunV + \text{jitter}$$
3. Hue-Preserving Specular Rolloff:
   Standard RGB clamping shifts saturated orange toward dull yellow because green and blue channels clip at 1.0 while red is already saturated. Light Stroke Rail preserves pure chromatic hue:
   $$RGB = col \times bright$$
   $$m = \max(RGB.r, \max(RGB.g, RGB.b))$$
   $$over = \max(m - 1.0, 0.0)$$
   $$RGB_{norm} = \frac{RGB}{\max(m, 1.0)}$$
   $$RGB_{final} = \text{mix}\left(RGB_{norm}, \vec{1.0}, \text{clamp}(over \cdot 0.15, 0.0, 0.50) \cdot \min\left(\frac{uBlow}{0.45}, 1.0\right)\right)$$

#### Core Parameters
- `uDwell`: Color cycle propagation velocity.
- `uRunV`: Longitudinal phase stretch along the shape.
- `uDelay`: Transverse phase spread across rails.
- `uBlow`: Whiteness blowout intensity.

#### EffectsIO Opportunity & Integration Notes
- **Opportunity**: Color grading, bloom modules, and generative wave animations.
- **Implementation Requirements**: Incorporate the hue-preserving tone mapping function into `src/rendering/shaders/tonemap.glsl`.

---

## 10. Animation & Time-Based Rendering Study

### 10.1 Animation Architecture
- **Clock Source**: Driven by `requestAnimationFrame` reading absolute wall-clock time (`performance.now() / 1000 - t0`) rather than accumulated frame deltas.
- **Background Tab Resilience**: If the browser tab is backgrounded and rAF throttles, animation resumes at the exact proper wall-clock phase instead of freezing or jumping erratically.
- **Deterministic Still Capture**: EffectsIO can leverage the `setStill(seconds)` paradigm: by freezing $t$ to a specific timestamp, high-resolution multi-frame exports can be rendered deterministically frame-by-frame.

### 10.2 Animation Motion Modes
| Flow Mode | Description | Motion Behavior |
| :--- | :--- | :--- |
| **0: Pulse** | Measured clip wave | Single ignition wave travels through rails with rise/fall envelope |
| **1: Solid** | Continuous looping run | Shape remains 100% lit; color palette cycles endlessly through strokes |
| **2: Trails** | Comet trails | Luminous heads travel along strokes leaving fading, blurring tails |

---

## 11. Presets, Templates, and Looks Study

Light Stroke Rail cleanly separates **Color Presets** from **Visual Templates**:
1. **Theme Presets (Color-Only)**:
   - 10 curated palettes (`ember`, `silk`, `projector`, `horizon`, `arcs`, `shoonyah`, `warp`, `cube`, `luma`, `bloom`).
   - Clicking an orb modifies **only** `cfg.stops` and `cfg.bg`. The active shape, geometry sliders, and timing are completely preserved.
2. **Templates (Full Deterministic Looks)**:
   - 20 handcrafted recipes (`comb-fan`, `pinwheel`, `neon-rings`, `sunburst`, `waist-arch`, `tiles`, `ring-coil`, `cosmos`, `barcode`, `shooting-star`, `bud-field`, `fragrant`, `clover`, `poster-discs`, `ascii-rain`, `checkmate`, `stair-field`, `silk-ribbon`, `grid-burst`, `glass-deck`).
   - Clicking a template resets state to base measured defaults, then applies the specific shape configuration, slider values, and tailored SVG line icon.

### Fit with EffectsIO Looks System
In EffectsIO, **Looks (PRD Section 14)** are composition snapshots. Light Stroke Rail confirms the value of **dual-level presets**:
- **Palette Presets**: Quick color theme swaps that do not disturb layer structure or effect parameters.
- **Look Snapshots**: Full multi-parameter recipes that restore complete creative treatments.

---

## 12. Randomization & Exploration Mechanics

### 12.1 Observations
- Light Stroke Rail does **not** feature a generic "Randomize All" dice button.
- Instead, randomization is embedded **procedurally within specific generative modes**:
  - Shape 33 (`Bar field`): Uses pseudo-random hash functions $fract(\sin(i \cdot 12.9898) \cdot 43758.5453)$ to generate randomized barcode slab lengths and gaps.
  - Shape 37 (`Tile grid`): Features an automated **beat-synchronized reshuffle clock** (`p3` = reshuffle rate):
    $$tp = uTime \cdot p3 - phase, \quad beat = \text{floor}(tp)$$
    Every beat, cells deterministically re-seed motifs (stripes, checks, rings, dots) with an organic scale-overshoot pop-in animation!

### 12.2 Recommendations for EffectsIO
EffectsIO should consider a **Beat-Driven / Seeded Randomizer** for generative layers, allowing users to scrub or increment an integer `Seed` parameter rather than unconstrained chaotic randomization.

---

## 13. State Management & Undo / Redo

### 13.1 Storage Architecture
- Settings persist to `localStorage.railCfg` as a single flat JSON dictionary.
- Stored schema includes a schema version check (`stored.v === MEASURED.v`). Stale schema versions from older shader models are discarded rather than merged, preventing corrupt visual states.
- Copy Settings button serializes the exact state to clipboard via `navigator.clipboard.writeText(JSON.stringify(cfg, null, 2))`.

### 13.2 Gap in Reference vs EffectsIO
- Light Stroke Rail lacks fine-grained history (no multi-step Undo/Redo stack).
- EffectsIO's robust `StudioContext` and command-based undo/redo architecture is significantly superior and must be maintained as the gold standard.

---

## 14. Export & Output Engine Study

Light Stroke Rail implements an exemplary, 100% client-side multi-format export suite:

```text
Export Menu (#exMenu)
├── PNG still         → Clamps 200..6000px, renders 2x canvas frames, toBlob download
├── JSON settings     → Lossless recipe payload with schema version & timestamps
├── WebM 6s           → MediaRecorder(canvas.captureStream(30), 'video/webm;codecs=vp9')
├── MP4 6s            → Feature-detected MediaRecorder('video/mp4;codecs=avc1.42E01E')
└── GIF 3s            → Custom client-side LZW encoder (12 FPS, 6x7x6 color cube, 3s loop)
```

### 14.1 Key Implementation Insights
1. **Client-Side GIF LZW Encoder**:
   - Implemented without third-party dependencies or WebAssembly.
   - Quantizes pixels against a static 6×7×6 RGB color cube (252 palette entries), eliminating the CPU overhead of per-frame median-cut palette generation.
   - Encodes standard GIF89a Netscape 2.0 loop blocks with LZW compression chunks.
2. **Two-Pass High-Res Offscreen Snapshot**:
   - Temporarily expands canvas resolution (`canvas.width = w; canvas.height = h;`), renders two rAF cycles to guarantee GPU buffer completion, executes `canvas.toBlob()`, then instantly restores original viewport dimensions.
3. **Dedicated Progress Toast (`TOAST`)**:
   - Displays real-time recording countdown, percentage progress bar, and status messages ("Rendering PNG", "Compiling MP4", "4s left, keep tab in front").

---

## 15. Responsive & Layout Adaptability

- **Panel Auto-Collapse**: Floating cards maintain fixed maximum widths (280px), scrolling vertically within `.sec` bodies.
- **Touch / Pointer Capture**: In-canvas handles and easing curve editor use Pointer Events API (`pointerdown`, `setPointerCapture`, `pointermove`, `pointerup`), ensuring flawless operation across mouse, trackpad, and touchscreen devices.
- **Mobile Caveat**: On narrow screens (<600px), floating cards overlap the canvas significantly. EffectsIO's planned responsive layout (docking panels into collapsible sheets or tabs) is more appropriate for general-purpose studio work.

---

## 16. Accessibility & Quality of Interaction

Light Stroke Rail exhibits exemplary accessibility engineering rare in creative WebGL experiments:
- **WCAG Semantic Roles**: Canvas is declared as `<canvas role="img" aria-label="Animated light-rail pattern preview">`.
- **Disclosure Controls**: Collapsible section headers are operable disclosure buttons (`role="button"`, `tabindex="0"`, `aria-expanded="true/false"`, keyboard handlers for `Enter` and `Space`).
- **Screen Reader Names**: Every `<input type="range">` carries an explicit `aria-label`.
- **Live Regions**: Export toast declares `role="status"` and `aria-live="polite"`.

---

## 17. What Makes Light Stroke Rail "Magic"

1. **Visually Saturated, High-End Optical Aesthetic**: The combination of white-hot specular cores, saturated color halos, and fine analog grain feels like cinematic anamorphic lens flares or long-exposure light painting, not computer graphics.
2. **Infinite Fluid Re-interpretation**: One single shader codebase gracefully morphs between 38 vastly different aesthetics—from delicate botanical flowers and retro ASCII rain to futuristic warp tunnels and minimalist barcodes.
3. **Zero-Lag Immediacy**: Every single knob scrub produces instant visual changes with 60 FPS animation continuity.
4. **Brik/Pill Scrubbing Affordance**: Value badges traveling along the slider thumb track make parameter tuning feel tactile and physical.
5. **Self-Contained Export Independence**: The ability to export MP4, WebM, high-res PNG, and animated GIF directly in-browser with immediate visual toast feedback makes the tool feel complete and trustworthy.

---

## 18. What EffectsIO Should NOT Copy

| Pattern in Reference | Why EffectsIO Should Deliberately Reject It |
| :--- | :--- |
| **Monolithic 2,300-Line Single Shader** | Light Stroke Rail packs 38 shapes into one massive `if/else` fragment shader. In EffectsIO, shaders must remain **modular, isolated GLSL chunks** loaded on-demand via the WebGL pipeline to prevent compile slowdowns and maintain code health. |
| **Single-Layer Canvas Assumption** | Light Stroke Rail assumes the canvas is 100% generative pattern with no layers. EffectsIO must maintain the **Frame → Layer → Effect** architecture where generative patterns exist as composable layers. |
| **Bespoke Unstyled Slider DOM Injections** | The reference generates ad-hoc slider DOM nodes in vanilla JS. EffectsIO must strictly consume its canonical UI design system primitives (`Slider`, `ColorPicker`, `PanelHeader`) styled with design tokens from `src/styles.css`. |
| **Omission of Image Import** | Light Stroke Rail cannot import photos. EffectsIO's core strength is photo styling, asset importing, and creative compositing. |
| **Flat LocalStorage without Project Model** | Single-key `localStorage.railCfg` without multi-project persistence or cloud saving is insufficient for EffectsIO's project workflow. |

---

## 19. EffectsIO Feature Opportunity Matrix

| Reference Capability | Observed Behavior | EffectsIO Opportunity | Integration Point | Priority | Recommendation |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Parametric Light Comb Filter** | Gaussian core + periodic trough comb on coordinate manifold | Generative Sub-layer: "Light Strokes / Comb Rails" | `src/rendering/shaders/generative/` | **P0** | **ADOPT** |
| **Dual Preset System (Palette vs Look)** | Preset orbs change color only; templates change full look | Split Palette Presets from Composition Look Snapshots | `LooksBrowser` / `PaletteControl` | **P0** | **ADOPT** |
| **In-Canvas Spline Drag Handles** | 4-point draggable Bezier handles directly on canvas | Canvas overlay handles for vector paths & gradients | `src/components/canvas/canvas-overlay.tsx` | **P1** | **ADAPT** |
| **Client-Side LZW GIF Exporter** | In-browser 12 FPS LZW GIF compilation from canvas frames | Zero-server animated GIF export | `src/export/gif-exporter.ts` | **P1** | **ADAPT** |
| **CPU 16-Bit Distance Field (EDT)** | Fast linear-time distance transform for contour rails | Typographic contour effects & vector outline expansion | `src/rendering/gl/distance-transform.ts` | **P2** | **ADAPT** |
| **Hue-Preserving Specular Rolloff** | Normalizes RGB before adding core white highlight | Prevents highlight discoloration in Glow/Bloom effects | `src/rendering/shaders/tonemap.glsl` | **P1** | **ADOPT** |
| **Dynamic Parameter Re-specification** | Sliders re-label and adjust ranges based on active shape | Dynamic parameter bindings in Generative Inspector | `src/components/panels/generative-inspector.tsx` | **P1** | **ADAPT** |
| **Beat-Synchronized Reshuffle** | Procedural layout pops in new motifs on timed beats | Timed / Seeded animation drift in Generative Layers | Timeline / Animation Engine | **P2** | **INVESTIGATE** |
| **Single-File Monolithic Shader** | 38 shapes in one fragment shader | Modular per-generator shader registry | `src/rendering/webgl/` | **P3** | **REJECT** |

---

## 20. EffectsIO Architecture Mapping

```text
EffectsIO Architecture Surface             Recommended Adaptation from Light Stroke Rail
──────────────────────────────             ─────────────────────────────────────────────
src/rendering/webgl/shaders/generative/    • Port the Periodic Comb Filter and Hue-Preserving Rolloff algorithms.
src/types/layer.ts                         • Add `GenerativeLayerConfig` supporting `parametric-rays` generator type.
src/components/canvas/                     • Implement `CanvasOverlayHandles` for direct interactive Bezier manipulation.
src/components/looks/                      • Separate color palette chips from complete Look composition recipes.
src/export/                                • Add client-side GIF export leveraging canvas frame capture.
```

---

## 21. Component-System Implications

Before introducing any new components, the EffectsIO component system (`src/components/ui/`) was evaluated:
- **Sliders**: EffectsIO's canonical `Slider` primitive (`src/components/ui/controls/slider/slider.tsx`) already supports labels, value formatters, and min/max ranges. It should be extended with an optional `fillTrack` token rather than creating a new component.
- **Color Stop Editor**: EffectsIO's canonical `GradientControl` / `PaletteControl` can directly consume the palette presets without modification.
- **In-Canvas Handles**: A new semantic primitive, `CanvasHandle` (`src/components/ui/canvas/canvas-handle.tsx`), should be created under the Canvas surface to provide standardized, accessible pointer-capture handles.

---

## 22. Technical Architecture Implications

- **Rendering**: The WebGL pipeline (`webgl-effect-pipeline.ts`) currently processes 2D texture passes. Generative layers will require a procedural source generator pass that outputs to an FBO before feeding downstream pixel effects.
- **Performance**: The $(u, v)$ coordinate manifold and comb filter execute in $<0.8\text{ms}$ on standard integrated GPUs, making it exceptionally performance-safe for 60 FPS viewport rendering.
- **Memory**: The CPU distance transform (`edt2d`) consumes $\approx 1.5\text{MB}$ for a 420px grid and executes in $<4\text{ms}$, well within acceptable interactive latency.

---

## 23. Repository Comparison

| Capability | Current EffectsIO State | Light Stroke Rail Reference Insight | Net Architectural Action |
| :--- | :--- | :--- | :--- |
| **Generative Backgrounds** | Linear/Radial gradients, CSS patterns | Highly dynamic mathematical comb rails & 38 procedural manifolds | Implement as Stage C Generative Sub-layer |
| **Color Palettes** | Hex stop arrays in `types/look.ts` | Theme presets with multi-stop cycling over normalized $(u, v)$ | Connect Palette Presets to generative shaders |
| **Canvas Direct Manipulation** | Pan/Zoom viewport controls | In-canvas draggable spline control handles | Introduce vector control overlay |
| **Video / Animation Export** | Planning Stage (PRD Sec 20) | Working MediaRecorder MP4/WebM + client-side GIF | Validates client-side export architecture |

---

## 24. Approval & Architecture Gate Status

- **Stage 1 Approval Gate (`stage-1-frame-layer.md`)**: Currently **CLOSED / NOT APPROVED**.
- **Action**: In accordance with Rule 12 and Rule 13, **zero application code has been modified**. This study represents pure architectural intelligence, mathematical analysis, and product documentation.

---

## 25. Epistemic Classification of Findings

- **OBSERVED**: 60 FPS real-time rendering, dynamic slider re-specification on shape selection, in-canvas Bezier drag handles, export formats (PNG, JSON, WebM, MP4, GIF), and full WCAG accessibility tree.
- **SOURCE-VERIFIED**: Complete GLSL fragment shader mathematics, periodic comb filter formulas, CPU Felzenszwalb Euclidean Distance Transform, 16-bit texture encoding, and LZW GIF encoding algorithm.
- **INFERRED**: GPU fill-rate efficiency on mobile viewports; exact memory footprint of offscreen EDT buffers.
- **PROPOSED**: EffectsIO Generative Layer integration, `CanvasHandle` primitive, and hue-preserving tonemapping module.

---

## 26. Recommended EffectsIO Adaptations

### Adaptation 1: The Parametric Light Stroke / Comb Generative Sub-Layer
- **Reference Insight**: Unified coordinate manifold $(u, v)$ coupled with a periodic Gaussian comb filter creates versatile, organic optical forms.
- **Why it Matters**: Gives EffectsIO a unique, world-class generative background capability that looks cinematic rather than mathematical.
- **Integration Point**: `src/rendering/shaders/generative/light-strokes.glsl` inside `GenerativeLayer`.
- **Priority**: **P0** (ADOPT).

### Adaptation 2: Dual-Tier Preset Model (Color Themes vs Look Snapshots)
- **Reference Insight**: Separating pure color palettes from structural looks allows infinite remixing without breaking user geometry.
- **Why it Matters**: Greatly enhances creative exploration in the Looks browser.
- **Integration Point**: `LooksBrowser` & `PaletteControl`.
- **Priority**: **P0** (ADOPT).

### Adaptation 3: In-Canvas Vector Spline Overlay Handles
- **Reference Insight**: Draggable canvas handles for Bezier spline control points make path shaping tactile and intuitive.
- **Why it Matters**: Lays the foundation for direct on-canvas editing in EffectsIO.
- **Integration Point**: `src/components/canvas/canvas-overlay.tsx`.
- **Priority**: **P1** (ADAPT).

---

## 27. Implementation Prompt Seeds

1. **Comb Filter Shader Module**:
   > *"Implement a reusable WebGL GLSL comb filter module in `src/rendering/shaders/generative/comb-filter.glsl` that accepts manifold coordinates $(u, v)$, line count, edge threshold, and softness uniforms, reproducing the Gaussian specular core and saturation-preserving troughs observed in reference study records."*

2. **In-Canvas Drag Handle System**:
   > *"Implement an accessible, pointer-capturing `CanvasOverlayHandles` component in `src/components/canvas/canvas-overlay.tsx` that renders interactive control points for Bezier splines over the canvas viewport, utilizing design tokens and Phosphor icons while preserving zoom/pan coordinate transformations."*

3. **Client-Side LZW GIF Exporter**:
   > *"Implement a zero-dependency client-side GIF exporter in `src/export/gif-exporter.ts` that captures animation frames from the studio WebGL canvas stream, quantizes colors using a fixed 6x7x6 color cube, and generates an optimized GIF89a Blob with progress reporting."*

4. **Hue-Preserving Specular Tonemapping**:
   > *"Update the post-processing tonemapping pass in `src/rendering/shaders/tonemap.glsl` to implement maximum-channel normalization before specular white blowout, preventing chromatic distortion when intense glow or light-leak effects clip."*
