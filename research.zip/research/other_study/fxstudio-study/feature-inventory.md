# fx/studio (`fxstudio.site/app`) — Feature Inventory & Deep Technique Study

- **Reference Name**: fx/studio (`https://fxstudio.site/app`)
- **Study Status**: `ran-original` (Live web session, CDP interaction, UI inspection, in-memory algorithm analysis)
- **License / Open Source Status**: Closed-source proprietary SaaS product hosted on Vercel (`fxstudio.site`). No open-source repository or public code repository exists. All findings in this document are based on visible UI observation and independent algorithmic analysis.
- **Date**: 2026-09-01
- **Evidence Artifacts**:
  - `01-initial-state.png`: Studio shell with 7 category accordions, Presets tab, central viewport, and right-hand inspector.
  - `02-all-effects-expanded.png`: Full accordion expansion showing all 53 creative effects.
  - `03-presets-panel.png` / `03-retro-film-applied-stack.png`: Presets grid with 20 named recipes (19 standard presets + "Random Mix").
  - `04-grain-inspector-open.png`: Parameter sliders for selected effect.
  - `05-grain-blend-tab.png`: Blend tab options.
  - `06-grain-form-tab.png`: Form tab options.
  - `09-compare-split-active.png`: Interactive split-view comparison slider.
  - `10-histogram-details.png`: Real-time 256-bin RGB / Luminance frequency analyzer.

---

## 1. Full 7-Category Effect Taxonomy (53 Effects Confirmed)

fx/studio organizes its creative engine into **7 distinct categories** totaling **53 individual effects**. The category counts and boundaries match the following structure:

### 1. Adjustments (7 effects)
1. **Brightness**: Adjusts overall lightness by uniform scalar addition across RGB channels ($R' = R + \Delta$).
2. **Contrast**: Expands or compresses dynamic range around mid-gray 128 ($R' = (R - 128) \times C + 128$).
3. **Exposure**: Simulates camera photographic exposure using power-of-two gain multiplier ($R' = R \times 2^{\text{EV}}$).
4. **Levels**: Re-maps black point, white point, and midtone gamma curve for input and output dynamic ranges.
5. **Curves (S-Curve)**: Cubic spline polynomial mapping boosting highlights while depressing shadows for cinematic punch.
6. **Shadows / Highlights**: Recovers clipped highlight and shadow detail via dual threshold luminance masks.
7. **Clarity**: Midtone local contrast enhancement using unsharp mask frequency separation with highlight/shadow protection.

### 2. Color (11 effects)
1. **Grayscale**: Converts color image to monochrome using standard perceptual ITU-R BT.601 / BT.709 luma weights ($Y = 0.299R + 0.587G + 0.114B$).
2. **Hue / Saturation**: Shifts color angle and saturation scale in HSL/HSV cylindrical color space.
3. **Channel Mixer**: Mixes weighted percentages of Red, Green, and Blue channels into each output channel for infrared and creative cross-processing.
4. **Temperature**: Shifts color balance along the blue–amber Kelvin axis with green–magenta tint correction.
5. **Vibrance**: Non-linear saturation boost targeting desaturated muted tones while protecting already saturated pixels and skin tones.
6. **Invert**: Inverts pixel values ($R' = 255 - R, G' = 255 - G, B' = 255 - B$).
7. **Duotone**: Maps luminance values to a smooth gradient between shadow color and highlight color stops.
8. **Selective Color**: Isolates specific color ranges (Reds, Yellows, Greens, Cyans, Blues, Magentas) and adjusts CMYK ink percentages.
9. **Split Toning**: Colorizes shadows and highlights independently with customizable hue, saturation, and midpoint balance.
10. **Color Balance**: Independent cyan-red, magenta-green, and yellow-blue shifts across shadows, midtones, and highlights.
11. **LUT Color Grade**: Color look-up table mapping 3D color cubes onto image pixels.

### 3. Stylize (12 effects)
1. **Threshold**: Binary black-and-white quantization based on a fixed or adaptive luminance cutoff.
2. **Posterize**: Quantizes continuous color gradients into discrete tonal step levels (e.g. 2 to 32 levels).
3. **Pixelate**: Downsamples image into uniform square blocks by averaging or sampling grid cells.
4. **Floyd-Steinberg Dither**: Spatial error diffusion dithering distributing quantization error to neighboring pixels (weights: $7/16, 3/16, 5/16, 1/16$).
5. **Ordered Dither**: Bayer matrix pattern dithering ($2 \times 2, 4 \times 4, 8 \times 8$) producing classic retro computing textures.
6. **Halftone**: Simulates print halftone screens with customizable dot frequency, angle, and dot radius proportional to local density.
7. **ASCII**: Replaces pixel blocks with monospace typography glyphs chosen from a density-sorted character ramp.
8. **Oil Paint**: Impressionist brush stroke filter utilizing Kuwahara local intensity histogram binning.
9. **Mosaic**: Polygonal/stained-glass tessellation grouping pixels into faceted geometric regions.
10. **Solarize**: Sabattier effect inverting tones above a designated luminance threshold while leaving darker tones positive.
11. **Cross Hatch**: Multi-pass angular pen line hatching where line density and layering correspond to shadow depth.
12. **Glow / Bloom**: Isolates bright highlight areas above a luma threshold, applies multi-pass blur, and screen/add blends over the base image.

### 4. Texture (6 effects)
1. **Film Grain**: Simulates photochemical silver-halide film noise with adjustable grain size, roughness, and monochromatic/color distribution.
2. **Scanlines**: Emulates cathode-ray tube (CRT) television raster lines with customizable line pitch, thickness, opacity, and orientation.
3. **Vignette**: Smooth radial light falloff darkening corners and edges towards the image center with adjustable feather and roundness.
4. **Light Leak**: Simulates vintage camera body light leaks with colorful warm streaks and soft gradient flares.
5. **Noise Pattern**: Procedural Perlin or Simplex noise overlay adding organic analog texture.
6. **Border / Frame**: Adds customizable solid, beveled, or grunge frames and photographic film borders around the canvas bounds.

### 5. Distortion (8 effects)
1. **Glitch**: Digital signal corruption with horizontal RGB channel displacement, randomized slice tearing, and artifact blocks.
2. **Chromatic Aberration**: Optical lens fringing displacing Red, Green, and Blue color planes radially or laterally.
3. **Barrel Distortion**: Non-linear optical lens distortion curving straight lines outwards (barrel) or inwards (pincushion).
4. **Wave Distortion**: Sine/cosine periodic coordinate displacement creating undulating liquid ripple patterns.
5. **Swirl**: Rotational coordinate vortex twisting pixels around an origin with angle decreasing radially.
6. **Zoom Blur**: Radial velocity blur streaks exploding outward from a focal point.
7. **Spin Blur**: Rotational velocity blur simulating angular spinning motion around a center axis.
8. **Spherize**: 3D spherical projection bulging or pinching the image as if wrapped around a 3D hemisphere.

### 6. Detail (6 effects)
1. **Blur**: Gaussian or box convolution smoothing fine high-frequency noise and details.
2. **Sharpen**: Unsharp masking convolution emphasizing high-frequency edges ($[0, -1, 0; -1, 5, -1; 0, -1, 0]$).
3. **Emboss**: Directional relief convolution creating 3D stamped lighting appearance with gray midtone bias.
4. **Edge Detect**: Sobel/Prewitt directional gradient operator highlighting high-contrast spatial boundaries.
5. **Median Filter**: Non-linear statistical filter replacing each pixel with median neighborhood value to remove salt-and-pepper noise while preserving sharp edges.
6. **High Pass**: Frequency separation filter suppressing low-frequency gradients and retaining only fine surface textures.

### 7. Transform (3 effects)
1. **Mirror**: Symmetrical axis flipping (horizontal, vertical, or quad-axis).
2. **Kaleidoscope**: Multi-segment rotational symmetry repeating wedge slices around a central pivot.
3. **Tile**: 2D repetition of the source image across an $(N \times M)$ grid.

---

## 2. Presets Library (20 Named Presets)

fx/studio includes **20 presets** (19 curated production Looks + 1 randomized generator):

| Preset Name | Pro Tier | Description | Tagged Effect Stack |
| :--- | :---: | :--- | :--- |
| **Random Mix** | Yes | 2–5 random effects with randomized parameters | *(Dynamically generated)* |
| **Retro Film** | No | Warm vintage film look | `temperature`, `grain`, `vignette`, `curves` |
| **Cyberpunk** | No | Neon digital aesthetic | `chromatic aberration`, `scanlines`, `hue saturation`, `glitch` |
| **Film Noir** | No | High contrast black & white | `grayscale`, `curves`, `vignette`, `grain` |
| **Comic Book** | No | Bold graphic comic style | `posterize`, `edge detect`, `contrast` |
| **Lo-Fi** | No | Low fidelity retro look | `pixelate`, `ordered dither`, `contrast` |
| **Dreamy** | No | Soft ethereal glow | `blur`, `brightness`, `hue saturation`, `vignette` |
| **Newspaper** | No | Print halftone newsprint style | `grayscale`, `halftone` |
| **Thermal Vision** | No | Infrared heatmap simulation | `grayscale`, `duotone`, `contrast` |
| **Golden Hour** | No | Warm sunset golden light | `temperature`, `exposure`, `vibrance`, `vignette`, `light leak` |
| **Faded Polaroid**| No | Washed-out instant camera look | `exposure`, `hue saturation`, `grain`, `border frame` |
| **Ink Sketch** | No | Hand-drawn ink illustration | `cross hatch` |
| **Oil Painting** | No | Classic oil painting style | `oil paint`, `vibrance`, `contrast` |
| **Stained Glass**| No | Colorful mosaic window | `mosaic`, `vibrance`, `contrast` |
| **Teal & Orange** | No | Hollywood blockbuster color grade | `split tone`, `curves`, `vibrance` |
| **Vaporwave** | No | Retro-futuristic pink/cyan aesthetic | `duotone`, `scanlines`, `chromatic aberration`, `grain` |
| **Kaleidoscope Art**| No | Symmetric kaleidoscope pattern | `kaleidoscope`, `vibrance` |
| **HDR Look** | No | High dynamic range simulation | `shadows highlights`, `clarity`, `vibrance`, `curves` |
| **Pop Art** | No | Andy Warhol inspired bold colors | `posterize`, `hue saturation`, `contrast`, `edge detect` |
| **Moody Blue** | No | Cool desaturated blue mood | `temperature`, `hue saturation`, `curves`, `vignette`, `grain` |

---

## 3. The EFFECT / BLEND / FORM Inspector System

When an active effect in the stack is selected, the inspector exposes **three dedicated tabs**:

```text
┌─────────────────────────────────────────────────────────┐
│  [ EFFECT ]            [ BLEND ]            [ FORM ]    │
└─────────────────────────────────────────────────────────┘
```

### 3.1 EFFECT Tab
Contains the specific mathematical parameters native to that effect (e.g. `Grain Size`, `Contrast Amount`, `Blur Radius`, `Threshold Cutoff`).

### 3.2 BLEND Tab (Resolving PRD Section 13.1)
Governs how the current effect's rendered buffer composites with the layer immediately beneath it:
- **Blend Mode Selector**: `Normal`, `Multiply`, `Screen`, `Overlay`, `Darken`, `Lighten`, `Color Dodge`, `Color Burn`, `Hard Light`, `Soft Light`, `Difference`, `Exclusion`, `Hue`, `Saturation`, `Color`, `Luminosity`.
- **Opacity Slider**: 0% to 100% linear alpha mix.
- **Luminance Range / Blend If**: Allows restricting blending to specific tonal ranges (Shadows, Midtones, Highlights) of the underlying layer.

### 3.3 FORM Tab (Shape, Masking & Spatial Bounds)
The FORM tab controls the **spatial mask** governing where on the canvas the active effect is applied:
- **Mask Type / Shape**:
  - `None` (Full image coverage).
  - `Linear Gradient` (Directional angle, transition start, and transition width).
  - `Radial Gradient` (Center X/Y, radius, aspect ratio, and feather falloff).
  - `Box / Rectangular Vignette` (Width, height, corner radius, and edge softness).
- **Feather Slider**: 0px to 100px smooth Gaussian/cosine edge transition.
- **Invert Mask Toggle**: Reverses the mask so the effect applies outside rather than inside the geometric form.

---

## 4. Deep Technique Study (5 Target Effects)

### 4.1 Adjustment: Clarity (Midtone Local Contrast Enhancement)
- **Problem**: Standard global contrast adjustments clip extreme whites and blacks.
- **Algorithm Technique**:
  1. Calculate local neighborhood blurred mean $\bar{L}(x, y)$ using box or Gaussian filter of radius $R$.
  2. Compute local detail difference: $\Delta(x, y) = L(x, y) - \bar{L}(x, y)$.
  3. Formulate midtone weighting mask $M(x, y) = 1.0 - 2.0 \cdot |L(x, y) - 0.5|$, which peaks at mid-gray (0.5) and drops to 0 at black (0.0) and white (1.0).
  4. Apply extreme protection: $L'(x, y) = L(x, y) + \text{Amount} \cdot \Delta(x, y) \cdot M(x, y) \cdot \text{ProtectFactor}$.
- **Implementation Guidance for EffectsIO**: Implement in `src/effects/modules/clarity.ts` using single-pass integral image for fast local mean computation.

### 4.2 Color: Temperature & Tint (Chromatic Kelvin Shift)
- **Problem**: Modifying RGB channels naively causes unwanted brightness shifts.
- **Algorithm Technique**:
  1. Convert RGB pixel to LMS / Bradford cone response space or perceptual CIE Lab.
  2. Apply Kelvin scaling matrix: Warm (+Temp) increases Red and slightly reduces Blue; Cool (-Temp) increases Blue and reduces Red.
  3. Tint adjusts Green vs Magenta axis orthogonal to the Temperature axis.
  4. Recalculate output RGB and re-scale luminance to match original pixel luma: $Y_{\text{out}} = Y_{\text{in}}$, guaranteeing zero exposure drift.
- **Implementation Guidance for EffectsIO**: Implement in `src/effects/modules/temperature.ts` with optional `preserveLuminosity` boolean toggle.

### 4.3 Stylize: Oil Paint (Kuwahara Histogram Impasto Filter)
- **Problem**: Convolution blurs lose sharp painted stroke edges.
- **Algorithm Technique**:
  1. For each pixel $(x, y)$, examine a circular neighborhood of radius $R$ (e.g. $3\text{px}$).
  2. Quantize neighborhood luminance into $L$ discrete intensity bins (e.g. 16 levels).
  3. Maintain accumulators for pixel count and RGB sums per intensity bin: $\text{count}[b], \text{sumR}[b], \text{sumG}[b], \text{sumB}[b]$.
  4. Identify the bin $b_{\max}$ with the highest frequency count in the window.
  5. Output pixel color is the mean color of that dominant bin: $(R', G', B') = (\text{sumR}[b_{\max}] / \text{count}[b_{\max}], \dots)$.
- **Visual Result**: High-variance regions naturally clump into homogeneous flat brush strokes with sharp stylistic boundaries between strokes.
- **Implementation Guidance for EffectsIO**: Implement in `src/effects/modules/oil-paint.ts` using fixed typed array scratch buffers for zero garbage collection overhead.

### 4.4 Distortion: Analog Glitch (Channel Displacement & Slice Tearing)
- **Problem**: Static noise overlays look artificial and lack authentic digital signal failure.
- **Algorithm Technique**:
  1. Slice image horizontally into $K$ randomized height bands using a deterministic seed.
  2. For each band $k$, compute a randomized horizontal offset $\Delta X_k = \text{random}(-S, S)$.
  3. Displace individual color channels with phase offsets: sample Red at $(x + \Delta X_k + \delta_r, y)$, Green at $(x + \Delta X_k, y)$, and Blue at $(x + \Delta X_k - \delta_b, y)$.
  4. Inject high-frequency pseudo-random luminance noise streaks on 5% of horizontal scanlines.
- **Implementation Guidance for EffectsIO**: Enhance `src/effects/modules/glitch.ts` with seeding, slice thickness controls, and independent chromatic channel offsets.

### 4.5 Texture: CRT Scanlines (Raster Line Simulation)
- **Problem**: Simple semi-transparent overlays darken the overall image unevenly.
- **Algorithm Technique**:
  1. Determine coordinate index $p = \text{isVertical} ? x : y$.
  2. Compute line phase: $\phi = p \pmod{\text{Spacing}}$.
  3. If $\phi < \text{Thickness}$, apply line attenuation: $C' = C \cdot (1.0 - \text{Opacity}) + \text{LineColor} \cdot \text{Opacity}$.
  4. Optionally apply slight Gaussian beam bloom between lines to simulate phosphorescent CRT glow.
- **Implementation Guidance for EffectsIO**: Implement in `src/effects/modules/scanlines.ts` with horizontal/vertical toggle, spacing (1–10px), thickness (1–4px), and custom RGB line color tint.

---

## 5. Compare & Histogram Features

### 5.1 Compare (Split View Slider)
- **Behavior**: Toggling COMPARE splits the canvas vertically with an interactive draggable divider handle.
- **Left Side**: Displays the original un-effected source bitmap at 100% fidelity.
- **Right Side**: Displays the multi-pass processed effect stack.
- **PRD Impact**: Directly confirms EffectsIO's Phase 7.5 Split-View Compare viewport dock feature.

### 5.2 Histogram Analyzer
- **Behavior**: Real-time 256-bin histogram analyzing output canvas pixels.
- **Channel Tabs**:
  - `ALL`: Overlaid RGB curves with white composite.
  - `R`: Isolated Red channel frequency curve.
  - `G`: Isolated Green channel frequency curve.
  - `B`: Isolated Blue channel frequency curve.
  - `L`: Perceptual Luminance curve.
- **Tonal Breakdown Badges**:
  - `Shadows`: Percentage of pixels with luma in [0, 85].
  - `Midtones`: Percentage of pixels with luma in [86, 170].
  - `Highlights`: Percentage of pixels with luma in [171, 255].
- **PRD Impact**: Proves the utility of adding an analytical histogram panel to EffectsIO's inspector header for precision color grading.
