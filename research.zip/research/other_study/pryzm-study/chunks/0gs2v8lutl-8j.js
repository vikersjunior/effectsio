(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,57559,e=>{"use strict";var t=e.i(18050),r=e.i(71645),n=e.i(30030),a=e.i(20783),i=e.i(26999),o=e.i(81140),s="AlertDialog",[l,u]=(0,n.createContextScope)(s,[i.createDialogScope]),d=(0,i.createDialogScope)(),c=e=>{let{__scopeAlertDialog:r,...n}=e,a=d(r);return(0,t.jsx)(i.Root,{...a,...n,modal:!0})};c.displayName=s;var f=r.forwardRef((e,r)=>{let{__scopeAlertDialog:n,...a}=e,o=d(n);return(0,t.jsx)(i.Trigger,{...o,...a,ref:r})});f.displayName="AlertDialogTrigger";var p=e=>{let{__scopeAlertDialog:r,...n}=e,a=d(r);return(0,t.jsx)(i.Portal,{...a,...n})};p.displayName="AlertDialogPortal";var m=r.forwardRef((e,r)=>{let{__scopeAlertDialog:n,...a}=e,o=d(n);return(0,t.jsx)(i.Overlay,{...o,...a,ref:r})});m.displayName="AlertDialogOverlay";var g="AlertDialogContent",[h,v]=l(g),b=r.forwardRef((e,n)=>{let{__scopeAlertDialog:s,children:l,...u}=e,c=d(s),f=r.useRef(null),p=(0,a.useComposedRefs)(n,f),m=r.useRef(null);return(0,t.jsx)(h,{scope:s,cancelRef:m,children:(0,t.jsx)(i.Content,{role:"alertdialog",...c,...u,ref:p,onOpenAutoFocus:(0,o.composeEventHandlers)(u.onOpenAutoFocus,e=>{e.preventDefault(),m.current?.focus({preventScroll:!0})}),onPointerDownOutside:e=>e.preventDefault(),onInteractOutside:e=>e.preventDefault(),children:l})})});b.displayName=g;var y=r.forwardRef((e,r)=>{let{__scopeAlertDialog:n,...a}=e,o=d(n);return(0,t.jsx)(i.Title,{...o,...a,ref:r})});y.displayName="AlertDialogTitle";var x=r.forwardRef((e,r)=>{let{__scopeAlertDialog:n,...a}=e,o=d(n);return(0,t.jsx)(i.Description,{...o,...a,ref:r})});x.displayName="AlertDialogDescription";var w=r.forwardRef((e,r)=>{let{__scopeAlertDialog:n,...a}=e,o=d(n);return(0,t.jsx)(i.Close,{...o,...a,ref:r})});w.displayName="AlertDialogAction";var E="AlertDialogCancel",R=r.forwardRef((e,r)=>{let{__scopeAlertDialog:n,...o}=e,{cancelRef:s}=v(E,n),l=d(n),u=(0,a.useComposedRefs)(r,s);return(0,t.jsx)(i.Close,{...l,...o,ref:u})});R.displayName=E,e.s(["Action",0,w,"AlertDialog",0,c,"AlertDialogAction",0,w,"AlertDialogCancel",0,R,"AlertDialogContent",0,b,"AlertDialogDescription",0,x,"AlertDialogOverlay",0,m,"AlertDialogPortal",0,p,"AlertDialogTitle",0,y,"AlertDialogTrigger",0,f,"Cancel",0,R,"Content",0,b,"Description",0,x,"Overlay",0,m,"Portal",0,p,"Root",0,c,"Title",0,y,"Trigger",0,f,"createAlertDialogScope",0,u],91162);var S=e.i(91162),S=S,P=e.i(47163);function A({...e}){return(0,t.jsx)(S.Root,{"data-slot":"alert-dialog",...e})}function k({...e}){return(0,t.jsx)(S.Portal,{"data-slot":"alert-dialog-portal",...e})}function T({className:e,...r}){return(0,t.jsx)(S.Overlay,{"data-slot":"alert-dialog-overlay",className:(0,P.cn)("fixed inset-0 z-50 bg-black/50 duration-150 data-open:animate-in data-open:fade-in-0 data-closed:animate-out data-closed:fade-out-0",e),...r})}function _({className:e,...r}){return(0,t.jsxs)(k,{children:[(0,t.jsx)(T,{}),(0,t.jsx)(S.Content,{"data-slot":"alert-dialog-content",className:(0,P.cn)("fixed top-1/2 left-1/2 z-50 grid w-full max-w-sm -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl border bg-popover p-6 text-popover-foreground shadow-lg duration-150 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95",e),...r})]})}function D({className:e,...r}){return(0,t.jsx)("div",{"data-slot":"alert-dialog-header",className:(0,P.cn)("flex flex-col gap-1.5",e),...r})}function L({className:e,...r}){return(0,t.jsx)("div",{"data-slot":"alert-dialog-footer",className:(0,P.cn)("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",e),...r})}function C({className:e,...r}){return(0,t.jsx)(S.Title,{"data-slot":"alert-dialog-title",className:(0,P.cn)("text-base font-semibold text-foreground",e),...r})}function j({className:e,...r}){return(0,t.jsx)(S.Description,{"data-slot":"alert-dialog-description",className:(0,P.cn)("text-sm text-muted-foreground",e),...r})}function O({...e}){return(0,t.jsx)(S.Action,{"data-slot":"alert-dialog-action",...e})}function N({...e}){return(0,t.jsx)(S.Cancel,{"data-slot":"alert-dialog-cancel",...e})}var M=e.i(67881);e.s(["useConfirm",0,function(){let[e,n]=r.useState(null),a=r.useCallback(e=>new Promise(t=>n({...e,resolve:t})),[]),i=t=>{e?.resolve(t),n(null)};return{confirm:a,confirmDialog:(0,t.jsx)(A,{open:null!==e,onOpenChange:e=>{e||i(!1)},children:e?(0,t.jsxs)(_,{children:[(0,t.jsxs)(D,{children:[(0,t.jsx)(C,{children:e.title}),e.description?(0,t.jsx)(j,{children:e.description}):null]}),(0,t.jsxs)(L,{children:[(0,t.jsx)(N,{asChild:!0,children:(0,t.jsx)(M.Button,{variant:"outline",size:"sm",onClick:()=>i(!1),children:e.cancelLabel??"Cancel"})}),(0,t.jsx)(O,{asChild:!0,children:(0,t.jsx)(M.Button,{variant:e.destructive?"destructive":"default",size:"sm",onClick:()=>i(!0),children:e.confirmLabel??"Confirm"})})]})]}):null})}}],57559)},10708,e=>{"use strict";var t=e.i(18050),r=e.i(71645),n=e.i(48425),a=r.forwardRef((e,r)=>(0,t.jsx)(n.Primitive.label,{...e,ref:r,onMouseDown:t=>{t.target.closest("button, input, select, textarea")||(e.onMouseDown?.(t),!t.defaultPrevented&&t.detail>1&&t.preventDefault())}}));a.displayName="Label",e.s(["Label",0,a,"Root",0,a],73741);var i=e.i(73741),i=i,o=e.i(47163);e.s(["Label",0,function({className:e,...r}){return(0,t.jsx)(i.Root,{"data-slot":"label",className:(0,o.cn)("flex items-center gap-2 text-xs/relaxed leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50",e),...r})}],10708)},99682,e=>{"use strict";var t=e.i(71645);e.s(["usePrevious",0,function(e){let r=t.useRef({value:e,previous:e});return t.useMemo(()=>(r.current.value!==e&&(r.current.previous=r.current.value,r.current.value=e),r.current.previous),[e])}])},19036,e=>{"use strict";var t=e.i(18050),r=e.i(71645),n=e.i(81140),a=e.i(20783),i=e.i(30030),o=e.i(69340),s=e.i(99682),l=e.i(35804),u=e.i(48425),d="Switch",[c,f]=(0,i.createContextScope)(d),[p,m]=c(d);function g(e){let{__scopeSwitch:n,checked:a,children:i,defaultChecked:s,disabled:l,form:u,name:c,onCheckedChange:f,required:m,value:g="on",internal_do_not_use_render:h}=e,[v,b]=(0,o.useControllableState)({prop:a,defaultProp:s??!1,onChange:f,caller:d}),[y,x]=r.useState(null),[w,E]=r.useState(null),R=r.useRef(!1),S=!y||!!u||!!y.closest("form"),P={checked:v,setChecked:b,disabled:l,control:y,setControl:x,name:c,form:u,value:g,hasConsumerStoppedPropagationRef:R,required:m,defaultChecked:s,isFormControl:S,bubbleInput:w,setBubbleInput:E};return(0,t.jsx)(p,{scope:n,...P,children:"function"==typeof h?h(P):i})}var h="SwitchTrigger",v=r.forwardRef(({__scopeSwitch:e,onClick:i,...o},s)=>{let{control:l,form:d,value:c,disabled:f,checked:p,required:g,setControl:v,setChecked:b,hasConsumerStoppedPropagationRef:y,isFormControl:x,bubbleInput:w}=m(h,e),E=(0,a.useComposedRefs)(s,v),S=r.useRef(p);return r.useEffect(()=>{let e=d?l?.ownerDocument.getElementById(d):l?.form;if(e instanceof HTMLFormElement){let t=()=>b(S.current);return e.addEventListener("reset",t),()=>e.removeEventListener("reset",t)}},[l,d,b]),(0,t.jsx)(u.Primitive.button,{type:"button",role:"switch","aria-checked":p,"aria-required":g,"data-state":R(p),"data-disabled":f?"":void 0,disabled:f,value:c,...o,ref:E,onClick:(0,n.composeEventHandlers)(i,e=>{b(e=>!e),w&&x&&(y.current=e.isPropagationStopped(),y.current||e.stopPropagation())})})});v.displayName=h;var b=r.forwardRef((e,r)=>{let{__scopeSwitch:n,name:a,checked:i,defaultChecked:o,required:s,disabled:l,value:u,onCheckedChange:d,form:c,...f}=e;return(0,t.jsx)(g,{__scopeSwitch:n,checked:i,defaultChecked:o,disabled:l,required:s,onCheckedChange:d,name:a,form:c,value:u,internal_do_not_use_render:({isFormControl:e})=>(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(v,{...f,ref:r,__scopeSwitch:n}),e&&(0,t.jsx)(E,{__scopeSwitch:n})]})})});b.displayName=d;var y="SwitchThumb",x=r.forwardRef((e,r)=>{let{__scopeSwitch:n,...a}=e,i=m(y,n);return(0,t.jsx)(u.Primitive.span,{"data-state":R(i.checked),"data-disabled":i.disabled?"":void 0,...a,ref:r})});x.displayName=y;var w="SwitchBubbleInput",E=r.forwardRef(({__scopeSwitch:e,...n},i)=>{let{control:o,hasConsumerStoppedPropagationRef:d,checked:c,defaultChecked:f,required:p,disabled:g,name:h,value:v,form:b,bubbleInput:y,setBubbleInput:x}=m(w,e),E=(0,a.useComposedRefs)(i,x),R=(0,s.usePrevious)(c),S=(0,l.useSize)(o);r.useEffect(()=>{if(!y)return;let e=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"checked").set,t=!d.current;if(R!==c&&e){let r=new Event("click",{bubbles:t});e.call(y,c),y.dispatchEvent(r)}},[y,R,c,d]);let P=r.useRef(c);return(0,t.jsx)(u.Primitive.input,{type:"checkbox","aria-hidden":!0,defaultChecked:f??P.current,required:p,disabled:g,name:h,value:v,form:b,...n,tabIndex:-1,ref:E,style:{...n.style,...S,position:"absolute",pointerEvents:"none",opacity:0,margin:0,transform:"translateX(-100%)"}})});function R(e){return e?"checked":"unchecked"}E.displayName=w,e.s(["Root",0,b,"Switch",0,b,"SwitchThumb",0,x,"Thumb",0,x,"createSwitchScope",0,f,"unstable_BubbleInput",0,E,"unstable_Provider",0,g,"unstable_SwitchBubbleInput",0,E,"unstable_SwitchProvider",0,g,"unstable_SwitchTrigger",0,v,"unstable_Trigger",0,v],57287);var S=e.i(57287),S=S,P=e.i(47163);e.s(["Switch",0,function({className:e,size:r="default",...n}){return(0,t.jsx)(S.Root,{"data-slot":"switch","data-size":r,className:(0,P.cn)("peer group/switch relative inline-flex shrink-0 items-center rounded-full border border-transparent transition-all outline-none after:absolute after:-inset-x-3 after:-inset-y-2 focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/30 aria-invalid:border-destructive aria-invalid:ring-2 aria-invalid:ring-destructive/20 data-[size=default]:h-[16.6px] data-[size=default]:w-[28px] data-[size=sm]:h-[14px] data-[size=sm]:w-[24px] dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 data-checked:bg-primary data-unchecked:bg-input dark:data-unchecked:bg-input/80 data-disabled:cursor-not-allowed data-disabled:opacity-50",e),...n,children:(0,t.jsx)(S.Thumb,{"data-slot":"switch-thumb",className:"pointer-events-none block rounded-full bg-background ring-0 transition-transform group-data-[size=default]/switch:size-3.5 group-data-[size=sm]/switch:size-3 group-data-[size=default]/switch:data-checked:translate-x-[calc(100%-2px)] group-data-[size=sm]/switch:data-checked:translate-x-[calc(100%-2px)] dark:data-checked:bg-primary-foreground group-data-[size=default]/switch:data-unchecked:translate-x-0 group-data-[size=sm]/switch:data-unchecked:translate-x-0 dark:data-unchecked:bg-foreground"})})}],19036)},62161,25992,e=>{"use strict";let t=2*Math.PI;function r(e,t){for(;t;)[e,t]=[t,e%t];return e}e.s(["DEFAULT_SPEED",0,.5,"MASTER_PERIOD",0,t,"SPEED_MAX",0,3,"SPEED_MIN",0,0,"SPEED_STEP",0,.1,"seamlessPeriodCount",0,function(e){let t=1;for(let n of e){let e=Math.round(10*Math.abs(n));if(0===e)continue;let a=10/r(e,10);t=t*a/r(t,a)}return t}],62161),e.s(["downloadCanvasPng",0,function(e,t){e.toBlob(e=>{if(!e)return;let r=URL.createObjectURL(e),n=document.createElement("a");n.href=r,n.download=t,n.click(),URL.revokeObjectURL(r)},"image/png")},"exportFilename",0,function(e,t,r){return`${e?"image":"gradient"}-${t}x${r}-${Date.now()}.png`}],25992)},98237,e=>{"use strict";let t="/api/looks/source/",r="look";e.s(["LOOKS_SOURCES_BUCKET",0,"looks-sources","LOOKS_THUMBS_BUCKET",0,"looks-thumbs","LOOK_ID_PARAM",0,r,"LOOK_SOURCE_PREFIX",0,t,"isLookSourcePath",0,function(e){return!!e?.startsWith(t)},"lookHref",0,function(e){let[n,a=""]=e.href.split("#"),[i,o=""]=n.split("?"),s=new URLSearchParams(o);return s.set(r,e.id),e.source_path&&s.set("img",`${t}${e.id}`),`${i}?${s.toString()}${a?`#${a}`:""}`},"looksThumbSrc",0,function(e){if(!e.thumb_path)return null;let t=e.thumb_path.split("/").pop()?.split(".")[0],r=`/api/looks/thumb/${e.id}`;return t?`${r}?v=${t}`:r}])},91350,e=>{"use strict";e.s(["imageToWebpBlob",0,function(e){return e?new Promise(t=>{e.canvas.toBlob(e=>t(e),"image/webp",.9)}):Promise.resolve(null)},"processImageFile",0,function(e){return new Promise((t,r)=>{let n=new Image,a=URL.createObjectURL(e);n.onload=()=>{URL.revokeObjectURL(a);try{t(function(e){let t=e.naturalWidth,r=e.naturalHeight,n=Math.max(t,r);if(n>4096){let e=4096/n;t=Math.round(t*e),r=Math.round(r*e)}let a=document.createElement("canvas");a.width=t,a.height=r;let i=a.getContext("2d");if(!i)throw Error("Could not create canvas context");return i.drawImage(e,0,0,t,r),{canvas:a,width:t,height:r,aspect:t/r}}(n))}catch(e){r(e)}},n.onerror=()=>{URL.revokeObjectURL(a),r(Error("Failed to load image"))},n.src=a})}])},94179,e=>{"use strict";var t=e.i(18050),r=e.i(25913),n=e.i(86011),a=e.i(47163);let i=(0,r.cva)("group/badge inline-flex h-5 w-fit shrink-0 items-center justify-center gap-1 overflow-hidden rounded-full border border-transparent px-2 py-0.5 text-[0.625rem] font-medium whitespace-nowrap transition-all focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 aria-invalid:border-destructive aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 [&>svg]:pointer-events-none [&>svg]:size-2.5!",{variants:{variant:{default:"bg-primary text-primary-foreground [a]:hover:bg-primary/80",secondary:"bg-secondary text-secondary-foreground [a]:hover:bg-secondary/80",destructive:"bg-destructive/10 text-destructive focus-visible:ring-destructive/20 dark:bg-destructive/20 dark:focus-visible:ring-destructive/40 [a]:hover:bg-destructive/20",outline:"border-border bg-input/20 text-foreground dark:bg-input/30 [a]:hover:bg-muted [a]:hover:text-muted-foreground",ghost:"hover:bg-muted hover:text-muted-foreground dark:hover:bg-muted/50",link:"text-primary underline-offset-4 hover:underline"}},defaultVariants:{variant:"default"}});e.s(["Badge",0,function({className:e,variant:r="default",asChild:o=!1,...s}){let l=o?n.Slot.Root:"span";return(0,t.jsx)(l,{"data-slot":"badge","data-variant":r,className:(0,a.cn)(i({variant:r}),e),...s})}])},13526,e=>{"use strict";var t=e.i(18050),r=e.i(94179),n=e.i(47163);e.s(["ProBadge",0,function({className:e}){return(0,t.jsx)(r.Badge,{variant:"secondary",className:(0,n.cn)("h-4 shrink-0 px-1.5 text-[0.625rem] font-semibold tracking-wide uppercase",e),children:"Pro"})}])},32781,e=>{"use strict";let t=(0,e.i(56420).default)("loader-circle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);e.s(["Loader2",0,t],32781)},63842,e=>{"use strict";let t=`/*
 * Background by Pryzm — https://pryzm.design
 *
 * Yours to use on your own and your clients' sites, and in templates or products
 * you sell. Don't sell this file on its own as a product, or use it to build a
 * competing background generator. Full terms: https://pryzm.design/terms
 */`,r=`import { PryzmBackground } from "./PryzmBackground"

<PryzmBackground style={{ width: 500, height: 400 }} />`,n=`/*
 * Usage
 *
${r.split("\n").map(e=>e?` *   ${e}`:" *").join("\n")}
 *
 * Size it like an image, with style or className. With no size it is full
 * width at the aspect it was designed at, so it is never invisible.
 *
 * To use it as a background behind content, position it yourself — for example
 * className="absolute inset-0" inside a relative parent. Nothing here sets
 * position, so that class is free to.
 *
 * Props are live: change them at runtime and the background follows.
 *
 *   speed    Animation rate. 1 is the speed you designed at.
 *   paused   Stops the animation without unmounting anything.
 *   fps      Frame cap. 0 is uncapped; 30 roughly halves the GPU cost.
 */`;function a(e){return`${e}
const createEmbedBackground = PryzmEmbedRuntime.createEmbedBackground;`}function i(e){return e.palette.length>1?`linear-gradient(135deg, ${e.palette.join(", ")})`:e.palette[0]??"#000"}function o(e){return JSON.stringify(e).replace(/</g,"\\u003c").replace(/\u2028/g,"\\u2028").replace(/\u2029/g,"\\u2029")}function s(e,r){return`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Background by Pryzm</title>
<style>
  html, body { margin: 0; height: 100%; }
  #pryzm-background {
    position: fixed;
    inset: 0;
    overflow: hidden;
    background: ${i(e)};
  }
</style>
</head>
<body>
<div id="pryzm-background"></div>
<script>
${t}
(function () {
  var PAYLOAD = ${o(e)};

${a(r)}

  createEmbedBackground(document.getElementById("pryzm-background"), PAYLOAD);
})();
</script>
</body>
</html>
`}e.s(["EMBED_DEFAULT_DELIVERY",0,{react:"download",html:"download",framer:"copy"},"EMBED_FILENAMES",0,{react:"PryzmBackground.tsx",html:"background.html",framer:"pryzm-look.txt"},"EMBED_TARGETS",0,["framer","react","html"],"REACT_USAGE_SNIPPET",0,r,"assembleHtmlTarget",0,s,"embedFileSize",0,function(e,r,l=""){return"framer"===e?l.length:function(e,r,l=""){return"framer"===e?l:"react"===e?`${t}
${n}
// @ts-nocheck — the runtime inlined below is generated JavaScript. Under a
// strict tsconfig its untyped parameters raise dozens of implicit-any errors in
// a file you did not write. Your usage is still checked: the component's own
// props are typed, and this suppression does not reach your code.
"use client"

import { useEffect, useRef, type CSSProperties } from "react"

const PAYLOAD = ${o(r)}

${a("")}

export function PryzmBackground({
  className,
  style,
  speed = ${r.anim.speed},
  paused = ${!r.anim.playing},
  fps = ${r.anim.fps},
}: {
  /** Optional. Sizing, positioning — anything. */
  className?: string
  /** Optional. Merged last, so it beats the defaults below. */
  style?: CSSProperties
  /** Animation rate. 1 is the speed the look was designed at. */
  speed?: number
  /** Stops the animation without unmounting anything. */
  paused?: boolean
  /** Frame cap. 0 is uncapped; 30 roughly halves the GPU cost. */
  fps?: number
} = {}) {
  const hostRef = useRef<HTMLDivElement | null>(null)
  const handleRef = useRef<{
    destroy: () => void
    setSpeed: (value: number) => void
    setPaused: (value: boolean) => void
    setFps: (value: number) => void
  } | null>(null)

  useEffect(() => {
    if (!hostRef.current) return
    const handle = createEmbedBackground(hostRef.current, PAYLOAD, {
      speed,
      paused,
      fps,
    })
    handleRef.current = handle
    // Full teardown: a SPA navigating between pages must not leak GL contexts,
    // which browsers cap and then silently kill oldest-first.
    return () => {
      handleRef.current = null
      handle.destroy()
    }
  }, [])

  // Live props, not just initial values.
  useEffect(() => {
    handleRef.current?.setSpeed(speed)
  }, [speed])
  useEffect(() => {
    handleRef.current?.setPaused(paused)
  }, [paused])
  useEffect(() => {
    handleRef.current?.setFps(fps)
  }, [fps])

  return (
    <div
      ref={hostRef}
      className={className}
      style={{
        // Only \`aspectRatio\` — no width, no height, no position.
        //
        // Inline styles beat classes, so every property set here is one the
        // caller cannot override with className. A default \`width: 100%\` was
        // exactly that trap: it silently won against \`w-[500px]\`, and against
        // the \`inset-0\` of a fill-the-parent background.
        //
        // This one is safe because \`aspect-ratio\` is ignored the moment both
        // dimensions are known. Size it any way you like and this does nothing;
        // size it not at all and a block-level div is already full width, so
        // this gives it a height and it is never invisible.
        //
        // A **string**, not a number: React appends "px" to numeric style
        // values unless the property is on its unitless list, and
        // \`aspect-ratio\` only joined that list in React 18. On anything older
        // a number becomes \`aspect-ratio: ${r.aspect}px\` — invalid, so
        // dropped, so no height, so an invisible background with a 1px-tall
        // canvas and no clue why.
        aspectRatio: ${JSON.stringify(String(r.aspect))},
        overflow: "hidden",
        background: ${JSON.stringify(i(r))},
        // Last, so anything you pass wins.
        ...style,
      }}
    />
  )
}

export default PryzmBackground
`:s(r,"")}(e,r,l).length+14761},"runtimeSource",0,a],63842)},57590,25427,e=>{"use strict";let t=new Set(["u_res","u_time"]);function r(e){return"number"==typeof e||"boolean"==typeof e?e:e instanceof Float32Array||e instanceof Int32Array||e instanceof Uint32Array||Array.isArray(e)&&e.every(e=>"number"==typeof e)?Array.from(e):null}e.s(["buildEmbedPayload",0,function(e){let{calls:r,fragmentSource:n}=e.recording;if(0===r.length||!n)return null;let a=function(e){for(let t=e.length-1;t>=0;t--){let r=e[t];if("u_res"!==r[1])continue;let[,,n,a]=r;if("number"==typeof n&&"number"==typeof a&&a>0)return n/a}return null}(r);return null===a?null:{v:1,frag:n.replace(/\/\*[\s\S]*?\*\//g,"").replace(/\/\/[^\n]*/g,"").replace(/[ \t]+$/gm,"").replace(/\n{3,}/g,"\n\n").trim(),uniforms:r.filter(e=>!t.has(e[1])),anim:e.anim,palette:[...e.colorStops].sort((e,t)=>e.position-t.position).map(e=>e.color),aspect:a}},"embedBlocker",0,function(e){return e.hasImage?"photo":e.patternEnabled?"pattern":null}],57590),e.s(["createRecordingContext",0,function(e){let t=[],n=new Map,a=new Set,i=new Map,o=new Map,s=new Map,l=null;return{context:new Proxy(e,{get(u,d,c){let f=Reflect.get(u,d,c);return"function"!=typeof f||"string"!=typeof d?f:"createShader"===d?t=>{let r=e.createShader(t);return r&&i.set(r,t),r}:"shaderSource"===d?(t,r)=>(o.set(t,r),e.shaderSource(t,r)):"attachShader"===d?(t,r)=>{let n=s.get(t)??[];return n.push(r),s.set(t,n),e.attachShader(t,r)}:"useProgram"===d?t=>(t&&(l=t),e.useProgram(t)):"getUniformLocation"===d?(t,r)=>{let a=e.getUniformLocation(t,r);return a&&n.set(a,r),a}:d.startsWith("uniform")?(...i)=>{let o=f.apply(e,i),s=i[0],l=s?n.get(s):void 0;if(l){let e=i.slice(1).map(r);e.includes(null)||(t.push([d,l,...e]),a.add(l))}return o}:f.bind(e)}}),recording:{calls:t,get fragmentSource(){if(!l)return null;for(let t of s.get(l)??[])if(i.get(t)===e.FRAGMENT_SHADER)return o.get(t)??null;return null},get unwritten(){return[...n.values()].filter(e=>!a.has(e))}}}}],25427)},66777,e=>{"use strict";var t=e.i(33758);function r(e){return"web"!==(0,t.normalizeExportTier)(e)}e.s(["FREE_MAX_EXPORT_TIER",0,"web","FREE_MAX_FPS",0,30,"FREE_MAX_LOOKS",0,9,"FREE_MAX_VIDEO_DURATION",0,6,"clampExportTierForFree",0,function(e){let n=(0,t.normalizeExportTier)(e);return r(n)?"web":n},"clampFpsForFree",0,function(e){return Math.min(e,30)},"clampVideoDurationForFree",0,function(e){return Math.min(e,6)},"isProExportTier",0,r,"isProFps",0,function(e){return e>30},"isProVideoDuration",0,function(e){return e>6}])},43523,e=>{"use strict";var t=e.i(73667),r=e.i(57590),n=e.i(25427);e.s(["buildEmbedPayloadFromLook",0,function(e){let a=e.width??1200,i=e.height??800,o=document.createElement("canvas");o.width=a,o.height=i;let s=o.getContext("webgl2",{alpha:!1,antialias:!1,depth:!1,stencil:!1});if(!s)return null;let{context:l,recording:u}=(0,n.createRecordingContext)(s);try{if(!new t.GradientEngine(l).paint(e.state,0,a,i,null,"block"))return null;return(0,r.buildEmbedPayload)({recording:u,anim:e.anim,colorStops:e.state.gradientParams.colorStops})}catch{return null}finally{s.getExtension("WEBGL_lose_context")?.loseContext()}}])},30133,e=>{"use strict";let t=0;e.s(["createEmbedBackground",0,function(e,r,n={}){let a=2*Math.PI,i=" .'`^\",:;Il!i><~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$",o=n.speed??r.anim.speed,s=n.paused??!r.anim.playing,l=n.fps??r.anim.fps;e.style.background=r.palette.length>1?"linear-gradient(135deg, "+r.palette.join(", ")+")":r.palette[0]??"#000";let u=document.createElement("canvas");u.style.display="block",u.style.width="100%",u.style.height="100%",e.appendChild(u);let d=u.getContext("webgl2",{alpha:!1,antialias:!1,depth:!1,stencil:!1,powerPreference:"low-power",preserveDrawingBuffer:!1});function c(e){try{console.warn("[pryzm-embed] "+e)}catch{}}if(!d)return u.remove(),{destroy(){},setSpeed(){},setPaused(){},setFps(){},rendering:!1};let f=null,p=null,m=null,g=-1,h=null,v=null,b=0,y=0,x=!1,w=0,E=0,R=0,S=0,P=!0,A=!0,k=!1,T=!1,_=!1,D="function"==typeof matchMedia?matchMedia("(prefers-reduced-motion: reduce)"):null,L=!!D&&D.matches;function C(e,t){let r=d.createShader(e);return r?(d.shaderSource(r,t),d.compileShader(r),d.getShaderParameter(r,d.COMPILE_STATUS))?r:(c("shader compile failed: "+d.getShaderInfoLog(r)),d.deleteShader(r),null):null}function j(){let e=C(d.VERTEX_SHADER,"#version 300 es\nin vec2 p;\nvoid main(){ gl_Position = vec4(p, 0.0, 1.0); }\n"),t=C(d.FRAGMENT_SHADER,r.frag);if(!e||!t)return!1;let n=d.createProgram();if(!n)return!1;if(d.attachShader(n,e),d.attachShader(n,t),d.linkProgram(n),d.deleteShader(e),d.deleteShader(t),!d.getProgramParameter(n,d.LINK_STATUS))return c("program link failed: "+d.getProgramInfoLog(n)),d.deleteProgram(n),!1;if(f=n,d.useProgram(f),p=d.createBuffer(),d.bindBuffer(d.ARRAY_BUFFER,p),d.bufferData(d.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),d.STATIC_DRAW),(g=d.getAttribLocation(f,"p"))<0)return!1;d.enableVertexAttribArray(g),d.vertexAttribPointer(g,2,d.FLOAT,!1,0,0),d.enable(d.BLEND),d.blendFunc(d.SRC_ALPHA,d.ONE_MINUS_SRC_ALPHA);let a=!1;for(let e=0;e<r.uniforms.length;e++)"u_asciiAtlas"===r.uniforms[e][1]&&(a=!0);return a&&(m=function(){let e=document.createElement("canvas");e.width=32*i.length,e.height=32;let t=e.getContext("2d");if(!t)return null;t.fillStyle="#000000",t.fillRect(0,0,e.width,e.height),t.fillStyle="#ffffff",t.font="500 "+Math.round(26.24)+'px "Courier New", Courier, monospace',t.textAlign="center",t.textBaseline="middle";for(let e=0;e<i.length;e++)t.fillText(i.charAt(e),(e+.5)*32,16.64);let r=d.createTexture();return r?(d.activeTexture(d.TEXTURE1),d.bindTexture(d.TEXTURE_2D,r),d.pixelStorei(d.UNPACK_FLIP_Y_WEBGL,!0),d.texImage2D(d.TEXTURE_2D,0,d.RGBA,d.RGBA,d.UNSIGNED_BYTE,e),d.pixelStorei(d.UNPACK_FLIP_Y_WEBGL,!1),d.texParameteri(d.TEXTURE_2D,d.TEXTURE_WRAP_S,d.CLAMP_TO_EDGE),d.texParameteri(d.TEXTURE_2D,d.TEXTURE_WRAP_T,d.CLAMP_TO_EDGE),d.texParameteri(d.TEXTURE_2D,d.TEXTURE_MIN_FILTER,d.NEAREST),d.texParameteri(d.TEXTURE_2D,d.TEXTURE_MAG_FILTER,d.NEAREST),r):null}()),h=d.getUniformLocation(f,"u_time"),v=d.getUniformLocation(f,"u_res"),!function(){if(f)for(let e=0;e<r.uniforms.length;e++){let t=r.uniforms[e],n=d[t[0]];if("function"!=typeof n)continue;let a=d.getUniformLocation(f,t[1]);a&&n.call(d,a,...t.slice(2))}}(),!0}function O(){f&&!k&&(h&&d.uniform1f(h,E),d.drawArrays(d.TRIANGLES,0,3))}function N(){if(y=0,T)return;let t=Math.min(window.devicePixelRatio||1,2),n=e.getBoundingClientRect(),a=n.width||e.clientWidth,i=n.height||e.clientHeight;if(a&&i)w=0;else{if(w<10){w++,M();return}let e=r.aspect>0?r.aspect:1;a&&!i?i=a/e:i&&!a?a=i*e:(a=640,i=640/e),x||(x=!0,console.warn("[Pryzm] The background's container measured "+Math.round(n.width)+"×"+Math.round(n.height)+"px when it mounted, so the canvas size was derived from the look's aspect instead. Give the container an explicit size — e.g. style={{ width: 500, height: 400 }} — for a pixel-exact render."))}let o=Math.max(1,Math.round(a*t)),s=Math.max(1,Math.round(i*t));(u.width!==o||u.height!==s)&&(u.width=o,u.height=s),d.viewport(0,0,o,s),f&&(d.useProgram(f),v&&d.uniform2f(v,o,s)),O()}function M(){y||T||(y=requestAnimationFrame(N))}function z(){return r.anim.playing&&!s&&!L&&P&&A&&!k&&!T}function F(e){if(!z()){b=0;return}b=requestAnimationFrame(F);let t=Math.min((e-S)/1e3,.1);S=e,R+=t,l>0&&R<1/l||(E=(E+R*o)%a,R=0,O())}function B(){if(!b&&z()){if(!_){if(t>=3)return;t++,_=!0}S=performance.now(),R=0,b=requestAnimationFrame(F)}}function U(){_&&(t--,_=!1),b&&(cancelAnimationFrame(b),b=0)}let I=j();N();let $="function"==typeof IntersectionObserver?new IntersectionObserver(e=>{(P=e.some(e=>e.isIntersecting))?B():U()}):null;$?.observe(e);let X="function"==typeof ResizeObserver?new ResizeObserver(M):null;function G(){(A="hidden"!==document.visibilityState)?B():U()}function H(){(L=!!D&&D.matches)?(U(),O()):B()}function W(e){e.preventDefault(),k=!0,U()}function Y(){k=!1,f=null,j()?(N(),B()):c("context restore failed; leaving the CSS fallback in place")}return X?.observe(e),document.addEventListener("visibilitychange",G),D?.addEventListener("change",H),u.addEventListener("webglcontextlost",W),u.addEventListener("webglcontextrestored",Y),I&&B(),{destroy(){T=!0,U(),y&&cancelAnimationFrame(y),$?.disconnect(),X?.disconnect(),document.removeEventListener("visibilitychange",G),D?.removeEventListener("change",H),u.removeEventListener("webglcontextlost",W),u.removeEventListener("webglcontextrestored",Y),f&&d.deleteProgram(f),p&&d.deleteBuffer(p),m&&d.deleteTexture(m),d.getExtension("WEBGL_lose_context")?.loseContext(),u.remove()},setSpeed(e){o=e},setPaused(e){(s=e)?U():B()},setFps(e){l=e},rendering:I}}])}]);