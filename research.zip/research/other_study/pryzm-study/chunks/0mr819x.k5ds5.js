(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,73667,e=>{"use strict";let t=" .'`^\",:;Il!i><~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$",a=t.length;var o=e.i(23225);function r(e){let t=("string"==typeof e?e:"").replace("#","");return[parseInt(t.slice(0,2),16)/255||0,parseInt(t.slice(2,4),16)/255||0,parseInt(t.slice(4,6),16)/255||0]}let l=`#version 300 es
in vec2 p;
void main(){ gl_Position = vec4(p, 0.0, 1.0); }
`,i=`#version 300 es
precision highp float;
out vec4 fragColor;
uniform vec2  u_res;
uniform float u_time;
uniform float u_warp;
uniform float u_flow;
uniform float u_scale;
uniform int   u_octaves;
uniform float u_contrast;
uniform float u_grain;
uniform float u_grainsize;
uniform int   u_grainBlendMode;
uniform float u_seed;
uniform int   u_shape;
uniform float u_angle;
uniform vec2  u_center;
uniform float u_softness;
uniform float u_blur;
uniform float u_aberration;
uniform int   u_distortion;
uniform float u_distAmount;
uniform float u_distCount;
uniform float u_distShadows;
uniform float u_distHighlights;
uniform float u_distBump;
uniform float u_pixelate;
uniform int   u_ditherMode;
uniform int   u_ditherMatrix;
uniform float u_ditherPattern;
uniform float u_ditherLevels;
uniform float u_ditherStrength;
uniform int   u_ditherColor;
uniform float u_asciiSize;
uniform float u_asciiCellRatio;
uniform int   u_asciiStyle;
uniform int   u_asciiColor;
uniform float u_asciiBackground;
uniform float u_asciiExposure;
uniform float u_asciiFill;
uniform float u_asciiDensity;
uniform float u_asciiScatter;
uniform float u_asciiOpacity;
uniform int   u_asciiBlend;
uniform float u_asciiCharCount;
uniform float u_halftoneSize;
uniform int   u_halftoneStyle;
uniform int   u_halftoneStagger;
uniform float u_halftoneDotScale;
uniform int   u_halftoneColor;
uniform float u_halftoneBackground;
uniform vec3  u_halftonePaperColor;
uniform float u_halftoneEmboss;
uniform float u_plaidColumnSize;
uniform float u_plaidRowSize;
uniform float u_plaidColumnStrength;
uniform float u_plaidRowStrength;
uniform float u_plaidBandWidth;
uniform float u_plaidBackground;
uniform float u_plaidAngle;
uniform int   u_plaidColorMode;
uniform vec3  u_plaidInkColor;
uniform int   u_plaidBlendMode;
uniform int   u_light;
uniform float u_lightAmount;
uniform float u_lightSize;
uniform vec2  u_lightCenter;
uniform int   u_waves;
uniform float u_wavesFrequency;
uniform float u_wavesAmplitude;
uniform float u_wavesPhase;
uniform float u_wavesFalloff;
uniform float u_wavesDisplace;
uniform vec2  u_wavesCenter;
uniform float u_gradientOverlay;
uniform int   u_blendMode;
uniform float u_grainSeed;
uniform vec2  u_imageRes;
uniform float u_imageScale;
uniform vec2  u_imageOffset;
uniform float u_imgBrightness;
uniform float u_imgContrast;
uniform float u_imgSaturation;
uniform float u_imgExposure;
uniform int   u_imgFilter;
uniform int   u_blobCount;
uniform float u_blobSize;
uniform float u_blobSpread;
uniform float u_blobSoftness;
uniform float u_blobMerge;
uniform float u_blobSeed;
uniform float u_blobDrift;
uniform float u_blobAmount;
uniform int   u_blobLayout;
uniform float u_blobDensity;
uniform int   u_blobShape;
uniform float u_blobShapeAmount;
uniform int   u_stopCount;
uniform float u_stopPos[8];
uniform vec3  u_stopCol[8];

// Pixel-size params (halftone, ASCII, plaid) are defined at a 1080p-equivalent
// reference: scaling by the canvas's shorter side keeps the composition
// identical across preview sizes, thumbnails, and 2K/4K exports. Grain and
// dither intentionally stay per-physical-pixel.
float refPxScale(){
  return max(min(u_res.x, u_res.y) / 1080.0, 0.05);
}
`,s=`
vec3 mod289(vec3 x){ return x - floor(x * (1.0/289.0)) * 289.0; }
vec2 mod289(vec2 x){ return x - floor(x * (1.0/289.0)) * 289.0; }
vec3 permute(vec3 x){ return mod289(((x*34.0)+1.0)*x); }
float snoise(vec2 v){
  const vec4 C = vec4(0.211324865405187, 0.366025403784439,
                     -0.577350269189626, 0.024390243902439);
  vec2 i  = floor(v + dot(v, C.yy));
  vec2 x0 = v - i + dot(i, C.xx);
  vec2 i1 = (x0.x > x0.y) ? vec2(1.0,0.0) : vec2(0.0,1.0);
  vec4 x12 = x0.xyxy + C.xxzz;
  x12.xy -= i1;
  i = mod289(i);
  vec3 p = permute(permute(i.y + vec3(0.0, i1.y, 1.0))
         + i.x + vec3(0.0, i1.x, 1.0));
  vec3 m = max(0.5 - vec3(dot(x0,x0), dot(x12.xy,x12.xy), dot(x12.zw,x12.zw)), 0.0);
  m = m*m; m = m*m;
  vec3 x  = 2.0 * fract(p * C.www) - 1.0;
  vec3 h  = abs(x) - 0.5;
  vec3 ox = floor(x + 0.5);
  vec3 a0 = x - ox;
  m *= 1.79284291400159 - 0.85373472095314 * (a0*a0 + h*h);
  vec3 g;
  g.x  = a0.x  * x0.x  + h.x  * x0.y;
  g.yz = a0.yz * x12.xz + h.yz * x12.yw;
  return 130.0 * dot(m, g);
}
float noise(vec2 p){ return snoise(p) * 0.5 + 0.5; }

float fbm(vec2 p){
  float v = 0.0, amp = 0.5;
  for(int i=0;i<6;i++){
    if(i >= u_octaves) break;
    v += amp * noise(p);
    p *= 2.0; amp *= 0.5;
  }
  return v;
}
float hash12(vec2 p){
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

const float PI = 3.14159265359;
const float TWO_PI = 6.28318530718;

// Seamless looping: u_time runs 0 → TWO_PI per loop. Time-based *translations*
// orbit a circle (position AND velocity match at the seam, so no jump); *phase*
// oscillators advance a whole number of cycles per loop.
vec2 loopOffset(float amp){
  return amp * vec2(sin(u_time), 1.0 - cos(u_time));
}
float loopPhaseAdd(float rate){
  return u_time * max(1.0, floor(rate + 0.5));
}

vec3 sampleGradientStops(float t){
  t = clamp(t, 0.0, 1.0);
  if(u_stopCount <= 0) return vec3(0.0);
  if(u_stopCount == 1) return u_stopCol[0];

  float soften = u_softness * 0.25;

  if(u_stopCount >= 2){
    float p0 = u_stopPos[0];
    float p1 = u_stopPos[1];
    if(t <= p1 || u_stopCount == 2){
      float denom = max(p1 - p0, 0.0001);
      float u = clamp((t - p0) / denom, 0.0, 1.0);
      u = smoothstep(0.0 - soften, 1.0 + soften, u);
      return mix(u_stopCol[0], u_stopCol[1], u);
    }
  }
  if(u_stopCount >= 3){
    float p0 = u_stopPos[1];
    float p1 = u_stopPos[2];
    if(t <= p1 || u_stopCount == 3){
      float denom = max(p1 - p0, 0.0001);
      float u = clamp((t - p0) / denom, 0.0, 1.0);
      u = smoothstep(0.0 - soften, 1.0 + soften, u);
      return mix(u_stopCol[1], u_stopCol[2], u);
    }
  }
  if(u_stopCount >= 4){
    float p0 = u_stopPos[2];
    float p1 = u_stopPos[3];
    if(t <= p1 || u_stopCount == 4){
      float denom = max(p1 - p0, 0.0001);
      float u = clamp((t - p0) / denom, 0.0, 1.0);
      u = smoothstep(0.0 - soften, 1.0 + soften, u);
      return mix(u_stopCol[2], u_stopCol[3], u);
    }
  }
  if(u_stopCount >= 5){
    float p0 = u_stopPos[3];
    float p1 = u_stopPos[4];
    if(t <= p1 || u_stopCount == 5){
      float denom = max(p1 - p0, 0.0001);
      float u = clamp((t - p0) / denom, 0.0, 1.0);
      u = smoothstep(0.0 - soften, 1.0 + soften, u);
      return mix(u_stopCol[3], u_stopCol[4], u);
    }
  }
  if(u_stopCount >= 6){
    float p0 = u_stopPos[4];
    float p1 = u_stopPos[5];
    if(t <= p1 || u_stopCount == 6){
      float denom = max(p1 - p0, 0.0001);
      float u = clamp((t - p0) / denom, 0.0, 1.0);
      u = smoothstep(0.0 - soften, 1.0 + soften, u);
      return mix(u_stopCol[4], u_stopCol[5], u);
    }
  }
  if(u_stopCount >= 7){
    float p0 = u_stopPos[5];
    float p1 = u_stopPos[6];
    if(t <= p1 || u_stopCount == 7){
      float denom = max(p1 - p0, 0.0001);
      float u = clamp((t - p0) / denom, 0.0, 1.0);
      u = smoothstep(0.0 - soften, 1.0 + soften, u);
      return mix(u_stopCol[5], u_stopCol[6], u);
    }
  }
  {
    float p0 = u_stopPos[6];
    float p1 = u_stopPos[7];
    float denom = max(p1 - p0, 0.0001);
    float u = clamp((t - p0) / denom, 0.0, 1.0);
    u = smoothstep(0.0 - soften, 1.0 + soften, u);
    return mix(u_stopCol[6], u_stopCol[7], u);
  }
}

`,u=`
const int MAX_BLOBS = 8;

/**
 * Distance from a blob's centre — and therefore its outline, since the falloff
 * below is a plain Gaussian on this value. Every mode returns 1.0 on the edge of
 * a unit blob, so shape never changes a blob's size.
 *
 * u_blobShapeAmount is "how far from a circle": 0 is a circle in *every* mode,
 * which keeps the control predictable when switching between them.
 */
float blobDistance(vec2 q, float phase){
  // Circle — the Euclidean norm, whose level sets are circles.
  if(u_blobShape == 0) return length(q);

  if(u_blobShape == 3){
    // Organic: a wobbled radius. Deliberately polar harmonics rather than fbm —
    // fbm is up to 6 octaves of simplex, and at 8 blobs per pixel that's ~48
    // noise evals per fragment. Three incommensurate harmonics cost a handful of
    // trig ops and read as an amoeba rather than a flower.
    float a = atan(q.y, q.x);
    float wob = sin(a * 3.0 + phase)
              + 0.5 * sin(a * 5.0 - phase * 1.7)
              + 0.3 * sin(a * 7.0 + phase * 0.6);
    return length(q) / max(1.0 + u_blobShapeAmount * 0.22 * wob, 0.15);
  }

  // Superellipse: |x|^e + |y|^e = 1. e = 2 is a circle, e → ∞ squares off, and
  // e < 1 pinches the sides into a star. Squircle walks up from 2, Diamond down.
  float e = u_blobShape == 1
    ? mix(2.0, 8.0, u_blobShapeAmount)
    : mix(2.0, 0.7, u_blobShapeAmount);
  vec2 a2 = abs(q);
  // The 1e-4 floor keeps pow() away from 0^negative when e < 1.
  return pow(pow(max(a2.x, 1e-4), e) + pow(max(a2.y, 1e-4), e), 1.0 / e);
}

/**
 * The particle field: one blob per grid cell, hashed from the cell's coordinate.
 *
 * The trick is that a pixel only has to look at its own cell and the eight
 * neighbours — a particle further away can't reach it. So cost is a fixed nine
 * evaluations no matter how many particles are on screen, where the scatter
 * layout costs one per blob.
 *
 * Stateless like everything else: a particle's position is a closed-form
 * function of (cell, seed, u_time), never integrated from the previous frame.
 * That's what keeps it exportable — video renders frame 47 without ever having
 * rendered frames 0-46 (see video-export.ts).
 */
float blobFieldGrid(vec2 p){
  float cells = mix(3.0, 40.0, u_blobDensity);
  vec2 gp = p * cells;
  vec2 base = floor(gp);
  // Radius in cell units; 0.5 keeps a full-size particle inside its own cell.
  float rad = max(u_blobSize * 0.5, 1e-3);

  float sum = 0.0;
  float peak = 0.0;
  for(int oy = -1; oy <= 1; oy++){
    for(int ox = -1; ox <= 1; ox++){
      vec2 cell = base + vec2(float(ox), float(oy));
      vec2 h = vec2(hash12(cell + u_blobSeed),
                    hash12(cell + u_blobSeed + 31.7));
      // Inset from the cell edge so neighbours don't line up into rows.
      vec2 centre = cell + 0.15 + 0.7 * h;
      float ph = hash12(cell + u_blobSeed + 7.3) * TWO_PI;
      // Same circular orbit as the scatter layout, so the loop stays seamless.
      centre += u_blobDrift * 0.3 *
                vec2(sin(u_time + ph), 1.0 - cos(u_time + ph));
      float r = rad * mix(0.35, 1.0, h.x);
      float d = blobDistance((gp - centre) / max(r, 1e-3), ph);
      float g = exp(-d * d * mix(6.0, 1.0, u_blobSoftness));
      sum += g;
      peak = max(peak, g);
    }
  }
  return mix(peak, sum, u_blobMerge);
}

float blobField(vec2 p, float aspect){
  if(u_blobLayout == 1) return blobFieldGrid(p);
  float sum = 0.0;
  float peak = 0.0;
  for(int i = 0; i < MAX_BLOBS; i++){
    if(i >= u_blobCount) break;
    float fi = float(i);
    vec2 h = vec2(hash12(vec2(fi, u_blobSeed)),
                  hash12(vec2(fi + 37.0, u_blobSeed)));
    vec2 c = vec2(0.5 * aspect, 0.5)
           + (h - 0.5) * u_blobSpread * vec2(aspect, 1.0);
    // A constant per-blob phase still traces the same circle, so position and
    // velocity match at the seam (see loopOffset) and the loop stays seamless —
    // each blob just starts somewhere else on its orbit.
    float ph = hash12(vec2(fi + 11.0, u_blobSeed)) * TWO_PI;
    c += u_blobDrift * 0.12 * vec2(sin(u_time + ph), 1.0 - cos(u_time + ph));
    float r = max(u_blobSize * mix(0.6, 1.0, h.y), 1e-3);
    vec2 q = (p - c) / r;
    float d = blobDistance(q, ph);
    // Gaussian falloff: it's what makes overlaps *add* rather than clip.
    float g = exp(-d * d * mix(6.0, 1.0, u_blobSoftness));
    sum += g;
    peak = max(peak, g);
  }
  // max keeps discs distinct; sum fuses them and pushes the overlap further
  // along the palette ramp — that's the extra colour where two blobs meet.
  return mix(peak, sum, u_blobMerge);
}
`,n=`
float blobField(vec2 p, float aspect){ return 0.0; }
`,f=`
vec3 fieldColorGenerate(vec2 uv){
  float aspect = u_res.x / u_res.y;
  float freqScale = mix(1.0, 0.45, u_softness);
  float effectiveContrast = mix(u_contrast, 1.0, u_softness);

  vec2 p = uv;
  p.x *= aspect;
  vec2 c = u_center;
  c.x *= aspect;

  vec2 nst = uv;
  nst.x *= aspect;
  nst *= u_scale;
  nst += u_seed;
  vec2 nstF = nst * freqScale;
  // Flow: gentle always-on drift, independent of Warp. Nudges the noise
  // sampling domain (texture flows) and the position reference (center/field
  // gently orbits) so shapes still feel alive with Warp at 0.
  nstF += loopOffset(u_flow * 0.55);
  vec2 flowOff = loopOffset(u_flow * 0.18);

  vec2 q = vec2(fbm(nstF + vec2(0.0,0.0) + loopOffset(0.1)),
                fbm(nstF + vec2(5.2,1.3) - loopOffset(0.1)));
  // Warp must displace around zero, or it stops being noise and becomes a plain
  // translation. fbm sums octaves of amplitude 0.5, 0.25, 0.125..., so it
  // averages 0.5 * (1 - 2^-octaves), NOT 0.5: that is 0 at Detail 0, 0.25 at
  // Detail 1, and only ~0.49 by Detail 6. Subtracting a flat 0.5 left a constant
  // negative bias that shoved the whole field right and up in proportion to
  // Warp, worst at low Detail (Detail 0 + Warp 0.8 moved it ~23% of the width).
  // Radial shapes could hide it by moving Center X. Twin Radial cannot, since
  // Orb X mirrors and so only sets the spread, which is how this surfaced.
  float fbmMean = 0.5 * (1.0 - pow(0.5, float(u_octaves)));
  vec2 warpOff = (q - fbmMean) * u_warp;

  float f;
  float g;
  bool meshMode = false;
  vec3 meshCol;

  if(u_waves == 1){
    vec2 wc = u_wavesCenter;
    wc.x *= aspect;
    vec2 pp = p + warpOff;
    float dist = length(pp - wc);
    float freq = mix(12.0, 88.0, u_wavesFrequency);
    float falloffK = mix(0.0, 5.0, u_wavesFalloff);
    float phase = dist * freq / (1.0 + falloffK * dist) + u_wavesPhase * 6.28318 + loopPhaseAdd(1.5);
    float wave01 = sin(phase) * 0.5 + 0.5;
    float sharpness = mix(1.0, 6.0, u_wavesAmplitude);
    f = pow(wave01, sharpness);
    g = clamp(dist * mix(0.65, 1.8, u_wavesFalloff * 0.5 + u_wavesFrequency * 0.5), 0.0, 1.0);
  } else if(u_shape == 0){
    vec2 dir = vec2(cos(u_angle), sin(u_angle));
    vec2 pp = p + warpOff + flowOff;
    f = dot(pp - vec2(0.5*aspect, 0.5), dir) + 0.5;
    g = clamp(f + (fbm(nstF*0.7) - 0.5)*0.3, 0.0, 1.0);
  } else if(u_shape == 1){
    vec2 pp = p + warpOff + flowOff;
    f = length(pp - c) * 1.4;
    g = clamp(f + (fbm(nstF*0.7) - 0.5)*0.3, 0.0, 1.0);
  } else if(u_shape == 5){
    vec2 pp = p + warpOff + flowOff;
    vec2 c1 = vec2(u_center.x * aspect, u_center.y);
    vec2 c2 = vec2((1.0 - u_center.x) * aspect, u_center.y);
    f = min(length(pp - c1), length(pp - c2)) * 1.4;
    g = clamp(f + (fbm(nstF*0.7) - 0.5)*0.3, 0.0, 1.0);
  } else if(u_shape == 2){
    vec2 pp = p + warpOff + flowOff - c;
    f = (atan(pp.y, pp.x) + PI) / (2.0*PI);
    g = clamp(fbm(nstF*0.7 + 3.0), 0.0, 1.0);
  } else if(u_shape == 3){
    vec2 m = clamp(uv + warpOff*0.5 + flowOff*0.5, 0.0, 1.0);
    vec3 top = mix(u_stopCol[0], u_stopCol[1], m.x);
    vec3 bot = mix(u_stopCol[2], u_stopCol[3], m.x);
    meshCol = mix(top, bot, m.y);
    float centerMix = 1.0 - length((m - 0.5) * 2.0);
    meshCol = mix(meshCol, u_stopCol[4], smoothstep(0.0, 1.0, centerMix) * 0.65);
    meshMode = true;
    f = 0.0; g = 0.0;
  } else {
    vec2 r = vec2(fbm(nstF + u_warp*q + vec2(1.7,9.2) + loopOffset(0.15)),
                  fbm(nstF + u_warp*q + vec2(8.3,2.8) - loopOffset(0.12)));
    f = fbm(nstF + u_warp*r);
    g = clamp(fbm(nstF*0.7 + r*u_warp + 3.0), 0.0, 1.0);
  }

  // Blobs blend over whatever field the shape produced, so they compose with
  // warped-field / conic instead of replacing them. Mesh is the exception: it
  // short-circuits with its own colour and has no scalar field to mix into, so
  // blobs take it over outright rather than silently doing nothing.
  if(u_blobAmount > 0.0){
    float bf = clamp(blobField(p + warpOff + flowOff, aspect), 0.0, 1.0);
    // Centre of a blob maps to the ramp's first stop, matching Radial (shape 1).
    if(meshMode){
      meshMode = false;
      f = 1.0 - bf;
      g = bf;
    } else {
      f = mix(f, 1.0 - bf, u_blobAmount);
    }
  }

  if(meshMode){
    return meshCol;
  }

  f = clamp((f - 0.5) * effectiveContrast + 0.5, 0.0, 1.0);
  vec3 col = sampleGradientStops(f);
  return col;
}
`,c=`
vec2 applyPixelate(vec2 uv){
  if(u_pixelate < 2.0) return uv;
  float aspect = u_res.x / u_res.y;
  vec2 cells = vec2(u_pixelate * aspect, u_pixelate);
  return (floor(uv * cells) + 0.5) / cells;
}
`,p=`
/**
 * Pushes the sampled coordinate along the wave field.
 *
 * Same concentric sine as the Waves shape, used as a displacement instead of as
 * a colour ramp input. Because this runs before the photo and the gradient are
 * sampled (see fieldColorAt), it warps both, which is the entire point: the
 * shape mode cannot touch the photo, since it only decides how the gradient is
 * generated.
 *
 * Deliberately reuses u_wavesFrequency and the origin/falloff/phase controls so
 * one set of sliders drives both the visible rings and the warp; a second,
 * independent frequency would let them disagree and look wrong. The phase
 * carries loopPhaseAdd so the ripple travels when the look is animated, and
 * still closes its loop.
 *
 * (No backticks in this comment: the whole chunk is a JS template literal.)
 */
vec2 wavesDisplaceUv(vec2 uv){
  float aspect = u_res.x / u_res.y;
  vec2 wc = u_wavesCenter;
  wc.x *= aspect;
  vec2 p = uv;
  p.x *= aspect;
  vec2 delta = p - wc;
  float dist = length(delta);
  // At the exact origin the direction is undefined; any fixed vector does, and
  // the amplitude there is ~0 anyway.
  vec2 dir = dist > 1e-4 ? delta / dist : vec2(0.0, 1.0);
  float freq = mix(12.0, 88.0, u_wavesFrequency);
  float falloffK = mix(0.0, 5.0, u_wavesFalloff);
  float phase = dist * freq / (1.0 + falloffK * dist)
    + u_wavesPhase * 6.28318 + loopPhaseAdd(1.5);
  // 0.06 keeps the strongest setting a firm ripple rather than a smear that
  // tears the photo apart; Ripple Glass uses 0.034 over a wider Amount range.
  vec2 offset = dir * sin(phase) * u_wavesDisplace * 0.06;
  offset.x /= aspect;
  return uv + offset;
}
`,d=`
float flutePosition(float gx){
  float x = fract(gx);
  float w = 0.02;
  float edge = abs(x - 0.5) - 0.5;
  float band = smoothstep(-w, w, edge);
  return mix(x, 1.0 - x, band);
}

float prismOffset(float gx, float fractCoord){
  float xSmooth = flutePosition(gx);
  float xNS = fractCoord + 0.0001;
  float distort = -pow(1.5 * xSmooth, 3.0) + 0.5;
  float aa = 0.08;
  float fade = smoothstep(0.0, aa, xNS) * smoothstep(1.0, 1.0 - aa, xNS);
  distort = mix(0.5, distort, fade);
  return distort * 3.0 * u_distAmount;
}

vec2 flutedGlassUv(vec2 uv){
  float strips = max(u_distCount, 1.0);
  vec2 gridUV = uv * vec2(strips, 1.0);
  vec2 gridFloor = floor(gridUV);
  vec2 gridFract = fract(gridUV);
  gridFract.x += prismOffset(gridUV.x, gridFract.x);
  return (gridFloor + gridFract) / vec2(strips, 1.0);
}

vec2 mosaicGlassUv(vec2 uv){
  float cells = max(u_distCount, 1.0);
  float aspect = u_res.x / u_res.y;
  vec2 g = vec2(cells * aspect, cells);
  vec2 gridUV = uv * g;
  vec2 gridFloor = floor(gridUV);
  vec2 gridFract = fract(gridUV);
  gridFract.x += prismOffset(gridUV.x, gridFract.x);
  gridFract.y += prismOffset(gridUV.y, gridFract.y);
  vec2 refracted = (gridFloor + gridFract) / g;
  vec2 quant = (floor(uv * g) + 0.5) / g;
  return mix(refracted, quant, u_distAmount * 0.25);
}

float rippleGlassFreq(){
  return mix(12.0, 88.0, clamp((u_distCount - 4.0) / 56.0, 0.0, 1.0));
}

float rippleGlassPhase(vec2 uv){
  float aspect = u_res.x / u_res.y;
  vec2 wc = u_wavesCenter;
  wc.x *= aspect;
  vec2 p = uv;
  p.x *= aspect;
  float dist = length(p - wc);
  float freq = rippleGlassFreq();
  float falloffK = mix(0.0, 5.0, u_wavesFalloff);
  return dist * freq / (1.0 + falloffK * dist) + u_wavesPhase * 6.28318 + loopPhaseAdd(1.5);
}

vec2 rippleGlassUv(vec2 uv){
  float aspect = u_res.x / u_res.y;
  vec2 wc = u_wavesCenter;
  wc.x *= aspect;
  vec2 p = uv;
  p.x *= aspect;
  vec2 delta = p - wc;
  float dist = length(delta);
  vec2 dir = dist > 1e-4 ? delta / dist : vec2(0.0, 1.0);
  float wave = sin(rippleGlassPhase(uv));
  float amp = u_distAmount * 0.034;
  vec2 offset = dir * wave * amp;
  offset.x /= aspect;
  return uv + offset;
}

float glassEdgeHighlight(float coordNS){
  float hw = 0.04;
  return 1.0 - smoothstep(0.0, hw, coordNS) * smoothstep(1.0, 1.0 - hw, coordNS);
}

vec3 applyFlutedGlassShading(vec3 col, vec2 uv){
  float strips = max(u_distCount, 1.0);
  float gx = uv.x * strips;
  float x = flutePosition(gx);
  float xNS = fract(gx) + 0.0001;
  float shadows = pow(x, 1.3) * pow(u_distShadows, 2.0);
  float highlights = glassEdgeHighlight(xNS) * u_distHighlights;
  col = mix(col, vec3(1.0), highlights);
  col *= (1.0 - shadows);
  return col;
}

vec3 applyMosaicGlassShading(vec3 col, vec2 uv){
  float cells = max(u_distCount, 1.0);
  float aspect = u_res.x / u_res.y;
  vec2 g = vec2(cells * aspect, cells);
  vec2 gx = uv * g;
  float x = flutePosition(gx.x);
  float y = flutePosition(gx.y);
  float xNS = fract(gx.x) + 0.0001;
  float yNS = fract(gx.y) + 0.0001;
  float shadows = max(pow(x, 1.3), pow(y, 1.3)) * pow(u_distShadows, 2.0);
  float highlights = max(glassEdgeHighlight(xNS), glassEdgeHighlight(yNS)) * u_distHighlights;
  col = mix(col, vec3(1.0), highlights);
  col *= (1.0 - shadows);
  return col;
}

vec3 applyRippleGlassShading(vec3 col, vec2 uv){
  float wave = sin(rippleGlassPhase(uv));
  float crest = smoothstep(0.55, 1.0, wave);
  float trough = smoothstep(-1.0, -0.55, -wave);
  col = mix(col, vec3(1.0), crest * u_distHighlights * 0.9);
  col *= (1.0 - trough * pow(u_distShadows, 1.5) * 0.38);
  return col;
}

// Frosted / organic glass: a noise vector field refracts the sampled UV, so the
// scene reads as if seen through hand-poured, bumpy glass (no repeating grid).
// distCount sets the bump scale, distAmount the overall push, distBump layers a
// finer, choppier octave on top for a rougher frost.
vec2 frostedGlassUv(vec2 uv){
  float aspect = u_res.x / u_res.y;
  float scale = max(u_distCount, 1.0) * 0.5;
  vec2 p = uv * scale;
  p.x *= aspect;
  // Base organic warp, centred at 0 so it pushes both ways.
  vec2 warp = vec2(fbm(p + loopOffset(0.08)),
                   fbm(p + vec2(5.2, 1.3) - loopOffset(0.08))) - 0.5;
  // Bumpiness: a higher-frequency octave adds fine chatter to the refraction.
  vec2 fine = vec2(fbm(p * 3.1 + vec2(1.7, 9.2)),
                   fbm(p * 3.1 + vec2(8.3, 2.8))) - 0.5;
  warp += fine * u_distBump;
  vec2 offset = warp * u_distAmount * 0.14;
  offset.x /= aspect;
  return uv + offset;
}

vec2 applyDistortion(vec2 uv){
  if(u_distortion == 1){
    return flutedGlassUv(uv);
  } else if(u_distortion == 2){
    return mosaicGlassUv(uv);
  } else if(u_distortion == 3){
    return rippleGlassUv(uv);
  } else if(u_distortion == 4){
    return frostedGlassUv(uv);
  }
  return uv;
}
`,m=`
float bayer2(vec2 p){
  float x = mod(floor(p.x), 2.0);
  float y = mod(floor(p.y), 2.0);
  if(y < 0.5){
    if(x < 0.5) return 0.0;
    return 0.5;
  }
  if(x < 0.5) return 0.75;
  return 0.25;
}

float bayer4(vec2 p){
  float x = mod(floor(p.x), 4.0);
  float y = mod(floor(p.y), 4.0);
  if(y < 1.0){
    if(x < 1.0) return 0.0 / 16.0;
    if(x < 2.0) return 8.0 / 16.0;
    if(x < 3.0) return 2.0 / 16.0;
    return 10.0 / 16.0;
  }
  if(y < 2.0){
    if(x < 1.0) return 12.0 / 16.0;
    if(x < 2.0) return 4.0 / 16.0;
    if(x < 3.0) return 14.0 / 16.0;
    return 6.0 / 16.0;
  }
  if(y < 3.0){
    if(x < 1.0) return 3.0 / 16.0;
    if(x < 2.0) return 11.0 / 16.0;
    if(x < 3.0) return 1.0 / 16.0;
    return 9.0 / 16.0;
  }
  if(x < 1.0) return 15.0 / 16.0;
  if(x < 2.0) return 7.0 / 16.0;
  if(x < 3.0) return 13.0 / 16.0;
  return 5.0 / 16.0;
}

float bayer8(vec2 p){
  float x = mod(floor(p.x), 8.0);
  float y = mod(floor(p.y), 8.0);
  if(y < 1.0){
    if(x < 1.0) return 0.0; if(x < 2.0) return 32.0; if(x < 3.0) return 8.0; if(x < 4.0) return 40.0;
    if(x < 5.0) return 2.0; if(x < 6.0) return 34.0; if(x < 7.0) return 10.0; return 42.0;
  }
  if(y < 2.0){
    if(x < 1.0) return 48.0; if(x < 2.0) return 16.0; if(x < 3.0) return 56.0; if(x < 4.0) return 24.0;
    if(x < 5.0) return 50.0; if(x < 6.0) return 18.0; if(x < 7.0) return 58.0; return 26.0;
  }
  if(y < 3.0){
    if(x < 1.0) return 12.0; if(x < 2.0) return 44.0; if(x < 3.0) return 4.0; if(x < 4.0) return 36.0;
    if(x < 5.0) return 14.0; if(x < 6.0) return 46.0; if(x < 7.0) return 6.0; return 38.0;
  }
  if(y < 4.0){
    if(x < 1.0) return 60.0; if(x < 2.0) return 28.0; if(x < 3.0) return 52.0; if(x < 4.0) return 20.0;
    if(x < 5.0) return 62.0; if(x < 6.0) return 30.0; if(x < 7.0) return 54.0; return 22.0;
  }
  if(y < 5.0){
    if(x < 1.0) return 3.0; if(x < 2.0) return 35.0; if(x < 3.0) return 11.0; if(x < 4.0) return 43.0;
    if(x < 5.0) return 1.0; if(x < 6.0) return 33.0; if(x < 7.0) return 9.0; return 41.0;
  }
  if(y < 6.0){
    if(x < 1.0) return 51.0; if(x < 2.0) return 19.0; if(x < 3.0) return 59.0; if(x < 4.0) return 27.0;
    if(x < 5.0) return 49.0; if(x < 6.0) return 17.0; if(x < 7.0) return 57.0; return 25.0;
  }
  if(y < 7.0){
    if(x < 1.0) return 15.0; if(x < 2.0) return 47.0; if(x < 3.0) return 7.0; if(x < 4.0) return 39.0;
    if(x < 5.0) return 13.0; if(x < 6.0) return 45.0; if(x < 7.0) return 5.0; return 37.0;
  }
  if(x < 1.0) return 63.0; if(x < 2.0) return 31.0; if(x < 3.0) return 55.0; if(x < 4.0) return 23.0;
  if(x < 5.0) return 61.0; if(x < 6.0) return 29.0; if(x < 7.0) return 53.0; return 21.0;
}

float bayerThreshold(vec2 cell){
  if(u_ditherMatrix == 2) return bayer2(cell);
  if(u_ditherMatrix == 8) return bayer8(cell) / 64.0;
  return bayer4(cell);
}

float hashRandom(vec2 p){
  return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

float interleavedGradientNoise(vec2 p){
  return fract(52.9829189 * fract(0.06711056 * p.x + 0.00583715 * p.y));
}

float ditherThreshold(vec2 cell){
  if(u_ditherMode == 1){
    return hashRandom(cell) - 0.5;
  }
  if(u_ditherMode == 2){
    return interleavedGradientNoise(cell) - 0.5;
  }
  return bayerThreshold(cell) - 0.5;
}

vec3 applyDitherAt(vec3 col, vec2 fragCoord){
  vec2 cell = floor(fragCoord / u_ditherPattern);
  float threshold = ditherThreshold(cell) * u_ditherStrength;
  float levels = max(u_ditherLevels, 2.0);
  if(u_ditherColor == 1){
    col += threshold / levels;
    col = floor(col * (levels - 1.0) + 0.5) / (levels - 1.0);
  } else {
    float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
    float ld = l + threshold / levels;
    float lq = floor(ld * (levels - 1.0) + 0.5) / (levels - 1.0);
    col *= (l > 0.001 ? lq / l : 1.0);
  }
  return clamp(col, 0.0, 1.0);
}
`,h=`
vec3 rgb2hsl(vec3 c){
  float maxC = max(c.r, max(c.g, c.b));
  float minC = min(c.r, min(c.g, c.b));
  float l = (maxC + minC) * 0.5;
  if(maxC == minC) return vec3(0.0, 0.0, l);
  float d = maxC - minC;
  float s = l > 0.5 ? d / (2.0 - maxC - minC) : d / (maxC + minC);
  float h = 0.0;
  if(maxC == c.r) h = (c.g - c.b) / d + (c.g < c.b ? 6.0 : 0.0);
  else if(maxC == c.g) h = (c.b - c.r) / d + 2.0;
  else h = (c.r - c.g) / d + 4.0;
  h /= 6.0;
  return vec3(h, s, l);
}

float hue2rgb(float p, float q, float t){
  if(t < 0.0) t += 1.0;
  if(t > 1.0) t -= 1.0;
  if(t < 1.0/6.0) return p + (q - p) * 6.0 * t;
  if(t < 1.0/2.0) return q;
  if(t < 2.0/3.0) return p + (q - p) * (2.0/3.0 - t) * 6.0;
  return p;
}

vec3 hsl2rgb(vec3 hsl){
  if(hsl.y <= 0.0) return vec3(hsl.z);
  float q = hsl.z < 0.5 ? hsl.z * (1.0 + hsl.y) : hsl.z + hsl.y - hsl.z * hsl.y;
  float p = 2.0 * hsl.z - q;
  return vec3(
    hue2rgb(p, q, hsl.x + 1.0/3.0),
    hue2rgb(p, q, hsl.x),
    hue2rgb(p, q, hsl.x - 1.0/3.0)
  );
}

vec3 blendMultiply(vec3 base, vec3 blend){ return base * blend; }
vec3 blendScreen(vec3 base, vec3 blend){ return 1.0 - (1.0 - base) * (1.0 - blend); }
float blendOverlayChannel(float base, float blend){
  return base < 0.5 ? 2.0 * base * blend : 1.0 - 2.0 * (1.0 - base) * (1.0 - blend);
}
vec3 blendOverlay(vec3 base, vec3 blend){
  return vec3(
    blendOverlayChannel(base.r, blend.r),
    blendOverlayChannel(base.g, blend.g),
    blendOverlayChannel(base.b, blend.b)
  );
}
vec3 blendSoftLight(vec3 base, vec3 blend){
  return mix(
    2.0 * base * blend + base * base * (1.0 - 2.0 * blend),
    sqrt(max(base, 0.0)) * (2.0 * blend - 1.0) + 2.0 * base * (1.0 - blend),
    step(vec3(0.5), blend)
  );
}
vec3 blendHardLight(vec3 base, vec3 blend){ return blendOverlay(blend, base); }
vec3 blendColor(vec3 base, vec3 blend){
  vec3 baseHsl = rgb2hsl(base);
  vec3 blendHsl = rgb2hsl(blend);
  return hsl2rgb(vec3(blendHsl.x, blendHsl.y, baseHsl.z));
}
vec3 blendDifference(vec3 base, vec3 blend){ return abs(base - blend); }
vec3 blendExclusion(vec3 base, vec3 blend){ return base + blend - 2.0 * base * blend; }

vec3 applyGradientBlend(vec3 base, vec3 blend, int mode){
  if(mode == 1) return blendMultiply(base, blend);
  if(mode == 2) return blendScreen(base, blend);
  if(mode == 3) return blendOverlay(base, blend);
  if(mode == 4) return blendSoftLight(base, blend);
  if(mode == 5) return blendHardLight(base, blend);
  if(mode == 6) return blendColor(base, blend);
  if(mode == 7) return blendDifference(base, blend);
  if(mode == 8) return blendExclusion(base, blend);
  return blend;
}
`,v=`
uniform sampler2D u_image;

vec2 imageUv(vec2 uv){
  float viewAspect = u_res.x / u_res.y;
  float imgAspect = u_imageRes.x / u_imageRes.y;

  // object-fit: cover — the image fills the frame at the selected aspect ratio,
  // cropping the overflowing dimension (centered).
  if(viewAspect > imgAspect){
    float factor = imgAspect / viewAspect;
    return vec2(uv.x, (uv.y - 0.5) * factor + 0.5);
  }
  float factor = viewAspect / imgAspect;
  return vec2((uv.x - 0.5) * factor + 0.5, uv.y);
}

// User zoom (around the frame centre) + pan, applied in frame space before the
// cover fit. Offset is in frame units, so a 0.5 pan moves the photo half a
// frame at any zoom level.
vec2 imageFrameUv(vec2 uv){
  return ((uv - u_imageOffset) - 0.5) / u_imageScale + 0.5;
}

// 1 inside the photo, 0 outside (zoomed out / panned away), with a hair of
// smoothing so the photo edge doesn't alias.
float imageMask(vec2 iuv){
  vec2 e = smoothstep(vec2(-0.002), vec2(0.0), iuv)
         * (vec2(1.0) - smoothstep(vec2(1.0), vec2(1.002), iuv));
  return e.x * e.y;
}

// One-click photo filters, layered after the adjustment sliders.
vec3 applyImageFilter(vec3 col, int f){
  float l = dot(col, vec3(0.299, 0.587, 0.114));
  if(f == 1) return vec3(l);                          // grayscale
  if(f == 2) return vec3(                              // sepia
    dot(col, vec3(0.393, 0.769, 0.189)),
    dot(col, vec3(0.349, 0.686, 0.168)),
    dot(col, vec3(0.272, 0.534, 0.131)));
  if(f == 3) return col * vec3(1.10, 1.02, 0.90);      // warm
  if(f == 4) return col * vec3(0.90, 1.00, 1.12);      // cool
  if(f == 5) return vec3(1.0) - col;                   // invert
  return col;
}

// Photo adjustments applied to the sampled image before the gradient blend:
// exposure (multiply, stops) then brightness (offset), contrast about mid-grey,
// saturation about luma, then the filter preset. All default to a no-op.
vec3 adjustImage(vec3 col){
  col *= exp2(u_imgExposure);
  col += u_imgBrightness;
  col = (col - 0.5) * u_imgContrast + 0.5;
  float l = dot(clamp(col, 0.0, 1.0), vec3(0.299, 0.587, 0.114));
  col = mix(vec3(l), col, u_imgSaturation);
  col = applyImageFilter(col, u_imgFilter);
  return clamp(col, 0.0, 1.0);
}

vec3 compositeUpload(vec2 uv){
  vec2 iuv = imageUv(imageFrameUv(uv));
  // The mask reveals the gradient through a *framing* gap — where the user
  // zoomed the photo out or panned it partly off. It must NOT fire for effect
  // displacement: glass/pixelate/aberration hand us a uv nudged past the frame
  // edge, and there the photo should clamp to its edge (as it did before image
  // positioning existed), not tear open to raw gradient. So when the photo is at
  // full cover (default framing, every look saved before this control), force
  // the mask solid; the gap logic only applies once it's actually moved.
  bool fullCover = u_imageScale >= 1.0
    && abs(u_imageOffset.x) < 0.0001 && abs(u_imageOffset.y) < 0.0001;
  vec4 tex = texture(u_image, clamp(iuv, 0.0, 1.0));
  // A cut-out PNG is see-through *inside* its frame, which the framing mask
  // above knows nothing about (it only feathers the frame's edges). Sampling
  // .rgb alone discarded the alpha, so transparent pixels composited as whatever
  // colour the file happened to store there, usually black, and the cut-out read
  // as a solid rectangle blended into the gradient. Folding alpha into the mask
  // lets the gradient through per pixel, exactly as it does outside the frame.
  // The texture is uploaded straight (never UNPACK_PREMULTIPLY_ALPHA_WEBGL), so
  // .rgb is un-premultiplied and needs no correction before use.
  float mask = (fullCover ? 1.0 : imageMask(iuv)) * tex.a;
  vec3 base = adjustImage(tex.rgb);
  if(u_gradientOverlay <= 0.001 && mask >= 0.999){
    return base;
  }
  // Outside the photo the gradient shows through — no edge smearing.
  vec3 grad = fieldColorGenerate(uv);
  vec3 col = u_gradientOverlay <= 0.001
    ? base
    : mix(base, applyGradientBlend(base, grad, u_blendMode), u_gradientOverlay);
  return mix(grad, col, mask);
}
`,_=`
// Light effects run on the already-composited colour only — they never re-sample
// the procedural field (which would inline fbm's loop many times), so they stay
// cheap. Single-select; the active mode is chosen at runtime.

vec3 applyGlow(vec2 uv, vec3 col){
  float aspect = u_res.x / u_res.y;
  vec2 d = (uv - u_lightCenter) * vec2(aspect, 1.0);
  float radius = mix(0.12, 0.95, u_lightSize);
  float glow = pow(1.0 - smoothstep(0.0, radius, length(d)), 1.5);
  return col + col * glow * u_lightAmount * 2.0 + glow * u_lightAmount * 0.25;
}

vec3 applyRays(vec2 uv, vec3 col){
  vec2 d = uv - u_lightCenter;
  float ang = atan(d.y, d.x);
  float freq = mix(6.0, 36.0, u_lightSize);
  float rays = pow(noise(vec2(ang * freq * 0.5 + 4.0, u_seed + loopOffset(0.4).y)), 2.0);
  float falloff = 1.0 - smoothstep(0.0, 1.1, length(d));
  return col + vec3(rays * falloff) * u_lightAmount * 1.8;
}

vec3 applyIridescence(vec2 uv, vec3 col){
  float aspect = u_res.x / u_res.y;
  vec2 p = uv;
  p.x *= aspect;
  p = p * u_scale + u_seed + loopOffset(0.15);
  float e = 0.04;
  float nc = noise(p);
  float hx = noise(p + vec2(e, 0.0)) - nc;
  float hy = noise(p + vec2(0.0, e)) - nc;
  vec3 n = normalize(vec3(-hx, -hy, mix(0.06, 0.012, u_lightSize)));
  float fres = pow(1.0 - clamp(n.z, 0.0, 1.0), 2.0);
  float bands = mix(2.0, 8.0, u_lightSize);
  float phase = (n.x * 0.5 + n.y * 0.5 + fres) * bands;
  vec3 irid = 0.5 + 0.5 * cos(6.2831853 * (phase + vec3(0.0, 0.33, 0.67)));
  return mix(col, col + irid * fres, u_lightAmount);
}

vec3 applyCaustics(vec2 uv, vec3 col){
  vec2 p = uv;
  p.x *= u_res.x / u_res.y;
  p *= mix(3.0, 11.0, u_lightSize);
  p += u_seed + loopOffset(0.3);
  float a = noise(p);
  float b = noise(p + vec2(a) + vec2(1.7, 9.2));
  float veins = pow(1.0 - abs(a - b), 6.0);
  return col + vec3(veins) * u_lightAmount * 1.6;
}

vec3 applyLight(vec2 uv, vec3 col){
  if(u_light == 1) return applyGlow(uv, col);
  if(u_light == 2) return applyRays(uv, col);
  if(u_light == 3) return applyIridescence(uv, col);
  if(u_light == 4) return applyCaustics(uv, col);
  return col;
}
`,g=`
uniform sampler2D u_asciiAtlas;

float asciiGlyph(vec2 cellUv, float lum){
  if(u_asciiStyle == 0){
    float idx = floor(lum * (u_asciiCharCount - 1.0));
    idx = clamp(idx, 0.0, u_asciiCharCount - 1.0);
    vec2 atlasUv = vec2((idx + cellUv.x) / u_asciiCharCount, 1.0 - cellUv.y);
    return texture(u_asciiAtlas, atlasUv).r;
  }
  if(u_asciiStyle == 1){
    return step(0.5, lum);
  }
  if(u_asciiStyle == 2){
    float r = lum * 0.48;
    float d = length(cellUv - 0.5);
    return 1.0 - smoothstep(r - 0.02, r, d);
  }
  if(u_asciiStyle == 3){
    float bands = 4.0;
    float py = fract(cellUv.y * bands);
    return step(py, lum);
  }
  if(u_asciiStyle == 4){
    float t = (1.0 - lum) * 0.45;
    float h = step(abs(cellUv.y - 0.5), t);
    float v = step(abs(cellUv.x - 0.5), t * 0.75);
    return max(h, v);
  }
  float stripes = fract((cellUv.x + cellUv.y) * 3.0);
  return step(stripes, lum);
}

vec3 applyAscii(vec2 uv, vec3 baseCol){
  float cellW = max(u_asciiSize * refPxScale(), 4.0);
  float cellH = max(cellW * u_asciiCellRatio, 4.0);
  float cols = max(floor(u_res.x / cellW), 4.0);
  float rows = max(floor(u_res.y / cellH), 4.0);

  vec2 cellSize = vec2(1.0 / cols, 1.0 / rows);
  vec2 cellId = floor(uv / cellSize);
  vec2 cellUv = fract(uv / cellSize);

  // Scatter — jitter each cell's colour-sample point for a looser, organic grid.
  vec2 jitter = (vec2(hash12(cellId + 11.3), hash12(cellId + 47.7)) - 0.5)
                * u_asciiScatter * cellSize;
  vec2 cellCenter = (cellId + 0.5) * cellSize + jitter;
  vec3 cellCol = colorPipelineAt(cellCenter);

  float lum = clamp(dot(cellCol, vec3(0.2126, 0.7152, 0.0722)), 0.0, 1.0);

  // Density — quantise tone into a limited number of glyph levels (selection
  // uses the raw luminance so Exposure never flattens the character variation).
  float levels = max(u_asciiDensity, 2.0);
  float sel = clamp(floor(lum * levels) / (levels - 1.0), 0.0, 1.0);

  float glyph = asciiGlyph(cellUv, sel);
  // Fill — glyph weight / coverage.
  glyph = clamp(glyph * u_asciiFill, 0.0, 1.0);

  // Ink follows the source tone — Mono = luminance grey, Source = colour — just
  // like Dither's Luma / RGB quantise. This natural falloff (dark cells → dark
  // glyphs) is what makes the image glow. Exposure multiplies the ink, so it's a
  // real, visible brightness control.
  vec3 base = u_asciiColor == 1 ? cellCol : vec3(lum);
  vec3 fg = clamp(base * u_asciiExposure, 0.0, 1.0);
  vec3 bg = mix(baseCol, vec3(0.0), u_asciiBackground);

  // Screen/Add composite ONLY the glyph ink (ink on black), so the gaps leave the
  // scene untouched and just the glyphs add light. Compositing the whole layer
  // (background included) would screen the bright scene over itself → white-out.
  vec3 ink = fg * glyph;

  vec3 blended;
  if(u_asciiBlend == 1){
    blended = 1.0 - (1.0 - baseCol) * (1.0 - ink); // screen — glyphs glow
  } else if(u_asciiBlend == 2){
    blended = min(baseCol + ink, vec3(1.0));        // add
  } else {
    blended = mix(bg, fg, glyph);                   // normal — uses Background
  }

  return mix(baseCol, blended, u_asciiOpacity);
}
`,b=`
vec2 halftoneSampleUv(vec2 uv, vec2 cellSize){
  vec2 sampleUv = uv;
  float rowIndex = floor(uv.y / cellSize.y);
  if(u_halftoneStagger == 1 && mod(rowIndex, 2.0) == 1.0){
    sampleUv.x += cellSize.x * 0.5;
  }
  return sampleUv;
}

float halftoneAa(){
  return 1.0 / max(u_halftoneSize * refPxScale(), 4.0);
}

// Signed distance to an upward equilateral triangle of size r, centred at the
// origin (IQ). Negative inside — thresholded like the other shapes so its area
// still scales with r-squared (and thus with coverage, for correct tone).
float sdHalftoneTriangle(vec2 p, float r){
  const float k = 1.7320508; // sqrt(3)
  p.x = abs(p.x) - r;
  p.y = p.y + r / k;
  if(p.x + k * p.y > 0.0) p = vec2(p.x - k * p.y, -k * p.x - p.y) * 0.5;
  p.x -= clamp(p.x, -2.0 * r, 0.0);
  return -length(p) * sign(p.y);
}

float halftoneInk(vec2 cellUv, float lum){
  float dist = length(cellUv);
  float aa = halftoneAa();
  float maxR = u_halftoneDotScale * 0.5;
  float coverage = clamp(lum, 0.0, 1.0);
  float radius = maxR * sqrt(0.08 + 0.92 * coverage);

  if(u_halftoneStyle == 1){
    float ringThick = maxR * 0.22;
    float innerR = max(radius - ringThick, 0.0);
    float outer = smoothstep(radius - aa, radius + aa, dist);
    float inner = smoothstep(innerR - aa, innerR + aa, dist);
    return inner * (1.0 - outer);
  }

  if(u_halftoneStyle == 2){
    if(coverage >= 0.5){
      return 1.0 - smoothstep(radius - aa, radius + aa, dist);
    }
    float squareEdge = maxR * 0.92;
    float square = 1.0 - smoothstep(squareEdge - aa, squareEdge + aa, max(abs(cellUv.x), abs(cellUv.y)));
    float invLum = clamp((0.5 - coverage) * 2.0, 0.0, 1.0);
    float whiteR = maxR * sqrt(invLum);
    float whiteDot = 1.0 - smoothstep(whiteR - aa, whiteR + aa, dist);
    return square * (1.0 - whiteDot);
  }

  if(u_halftoneStyle == 3){
    float uniformR = maxR * 0.92;
    return 1.0 - smoothstep(uniformR - aa, uniformR + aa, dist);
  }

  if(u_halftoneStyle == 4){
    // Triangle: same coverage-driven size, thresholded from the SDF.
    float sd = sdHalftoneTriangle(cellUv, radius);
    return 1.0 - smoothstep(-aa, aa, sd);
  }

  if(u_halftoneStyle == 5){
    // Rhombus (diamond): the L1 norm gives a square rotated 45\xb0.
    float dRhombus = abs(cellUv.x) + abs(cellUv.y);
    return 1.0 - smoothstep(radius - aa, radius + aa, dRhombus);
  }

  return 1.0 - smoothstep(radius - aa, radius + aa, dist);
}

vec3 halftoneEmbossShade(vec2 cellUv, vec3 col, float ink){
  if(u_halftoneEmboss <= 0.0 || ink <= 0.001) return col;
  float bevel = (-cellUv.x + cellUv.y) * 2.2;
  float shade = 1.0 + u_halftoneEmboss * bevel * 0.24;
  return col * clamp(shade, 0.58, 1.32);
}

vec3 applyHalftone(vec2 uv, vec3 baseCol){
  float cellPx = max(u_halftoneSize * refPxScale(), 4.0);
  vec2 cellSize = vec2(cellPx) / u_res;
  vec2 sampleUv = halftoneSampleUv(uv, cellSize);
  vec2 cellCenter = cellSize * (floor(sampleUv / cellSize) + 0.5);
  vec3 cellCol = colorPipelineAt(cellCenter);

  float lum = dot(cellCol, vec3(0.2126, 0.7152, 0.0722));
  lum = clamp(lum, 0.0, 1.0);

  vec2 cellUv = fract(sampleUv / cellSize) - 0.5;
  float ink = halftoneInk(cellUv, lum);

  vec3 inkCol = u_halftoneColor == 1 ? cellCol : vec3(lum);
  inkCol = halftoneEmbossShade(cellUv, inkCol, ink);
  vec3 paper = mix(baseCol, u_halftonePaperColor, u_halftoneBackground);
  return mix(paper, inkCol, clamp(ink, 0.0, 1.0));
}
`,x=`
vec3 applyPlaid(vec2 uv, vec3 baseCol){
  float aspect = u_res.x / u_res.y;
  float ca = cos(u_plaidAngle);
  float sa = sin(u_plaidAngle);

  // Rotate the sampling domain around the frame center (aspect-corrected) so
  // the grid can sit at any angle without skewing on non-square canvases.
  vec2 pu = uv - 0.5;
  pu.x *= aspect;
  vec2 ru = vec2(pu.x * ca + pu.y * sa, -pu.x * sa + pu.y * ca);

  vec2 cellSize = vec2(max(u_plaidColumnSize * refPxScale(), 4.0), max(u_plaidRowSize * refPxScale(), 4.0)) / u_res;
  float colCenterRu = cellSize.x * (floor(ru.x / cellSize.x) + 0.5);
  float rowCenterRu = cellSize.y * (floor(ru.y / cellSize.y) + 0.5);

  // Band coverage: 1 at the cell center, falling to 0 past plaidBandWidth so a
  // paper gap can show between bands (with a hairline of AA at the edge).
  float bw = clamp(u_plaidBandWidth, 0.02, 1.0);
  float aaX = 1.0 / max(u_plaidColumnSize * refPxScale(), 4.0);
  float aaY = 1.0 / max(u_plaidRowSize * refPxScale(), 4.0);
  float colFrac = abs(fract(ru.x / cellSize.x) - 0.5) * 2.0;
  float rowFrac = abs(fract(ru.y / cellSize.y) - 0.5) * 2.0;
  float colCoverage = 1.0 - smoothstep(bw - aaX, bw + aaX, colFrac);
  float rowCoverage = 1.0 - smoothstep(bw - aaY, bw + aaY, rowFrac);

  // Map each band's rotated cell-center back into real scene UV so its tint
  // can be sampled from the (possibly rotated) gradient itself.
  vec2 vSampleRu = vec2(colCenterRu, 0.0);
  vec2 vSampleUv = vec2(vSampleRu.x * ca - vSampleRu.y * sa, vSampleRu.x * sa + vSampleRu.y * ca);
  vSampleUv = clamp(vec2(vSampleUv.x / aspect, vSampleUv.y) + 0.5, 0.0, 1.0);

  vec2 hSampleRu = vec2(0.0, rowCenterRu);
  vec2 hSampleUv = vec2(hSampleRu.x * ca - hSampleRu.y * sa, hSampleRu.x * sa + hSampleRu.y * ca);
  hSampleUv = clamp(vec2(hSampleUv.x / aspect, hSampleUv.y) + 0.5, 0.0, 1.0);

  vec3 vTint = u_plaidColorMode == 1 ? colorPipelineAt(vSampleUv) : u_plaidInkColor;
  vec3 hTint = u_plaidColorMode == 1 ? colorPipelineAt(hSampleUv) : u_plaidInkColor;

  vec3 paper = mix(baseCol, vec3(1.0), u_plaidBackground);

  vec3 col = paper;
  vec3 vBlended = applyGradientBlend(col, vTint, u_plaidBlendMode);
  col = mix(col, vBlended, u_plaidColumnStrength * colCoverage);
  vec3 hBlended = applyGradientBlend(col, hTint, u_plaidBlendMode);
  col = mix(col, hBlended, u_plaidRowStrength * rowCoverage);

  return col;
}
`,y=`#version 300 es
precision highp float;
out vec4 fragColor;
uniform sampler2D u_image;
uniform vec2 u_res;
uniform vec2 u_direction;
uniform float u_spread;

void main(){
  vec2 uv = gl_FragCoord.xy / u_res;
  vec2 step = u_direction * u_spread / u_res;

  vec3 acc = texture(u_image, uv).rgb * 0.2270270270;
  acc += texture(u_image, uv + step * 1.3846153846).rgb * 0.3162162162;
  acc += texture(u_image, uv - step * 1.3846153846).rgb * 0.3162162162;
  acc += texture(u_image, uv + step * 3.2307692308).rgb * 0.0702702703;
  acc += texture(u_image, uv - step * 3.2307692308).rgb * 0.0702702703;

  fragColor = vec4(acc, 1.0);
}
`,S=`#version 300 es
precision highp float;
out vec4 fragColor;
uniform sampler2D u_image;
uniform vec2 u_res;

void main(){
  fragColor = vec4(texture(u_image, gl_FragCoord.xy / u_res).rgb, 1.0);
}
`;function w(e,t,a){let o=e.createShader(t);if(!o)throw Error("Failed to create blur shader");if(e.shaderSource(o,a),e.compileShader(o),!e.getShaderParameter(o,e.COMPILE_STATUS)){let t=e.getShaderInfoLog(o);throw e.deleteShader(o),Error(`Blur shader compile error: ${t}`)}return o}function C(e,t){let a=w(e,e.VERTEX_SHADER,l),o=w(e,e.FRAGMENT_SHADER,t),r=e.createProgram();return r?(e.attachShader(r,a),e.attachShader(r,o),e.linkProgram(r),e.deleteShader(a),e.deleteShader(o),e.getProgramParameter(r,e.LINK_STATUS))?r:(e.deleteProgram(r),null):null}function E(e,t,a){let o=e.createFramebuffer(),r=e.createTexture();return o&&r?(e.bindTexture(e.TEXTURE_2D,r),e.texImage2D(e.TEXTURE_2D,0,e.RGBA,t,a,0,e.RGBA,e.UNSIGNED_BYTE,null),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.LINEAR),e.bindFramebuffer(e.FRAMEBUFFER,o),e.framebufferTexture2D(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,r,0),e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindTexture(e.TEXTURE_2D,null),{framebuffer:o,texture:r,width:t,height:a}):null}function T(e,t){e.deleteFramebuffer(t.framebuffer),e.deleteTexture(t.texture)}function R(e,t){if(t)for(let a of t.levels)T(e,a.a),T(e,a.b)}function A(e,t,a){e.bindBuffer(e.ARRAY_BUFFER,t),e.enableVertexAttribArray(a),e.vertexAttribPointer(a,2,e.FLOAT,!1,0,0),e.drawArrays(e.TRIANGLES,0,3)}function P(e,t,a,o,r,l,i){e.bindFramebuffer(e.FRAMEBUFFER,r.framebuffer),e.viewport(0,0,r.width,r.height),e.useProgram(t.program),e.activeTexture(e.TEXTURE0),e.bindTexture(e.TEXTURE_2D,o),e.uniform1i(t.uImage,0),e.uniform2f(t.uRes,r.width,r.height),e.uniform2f(t.uDirection,+!!i,+!i),e.uniform1f(t.uSpread,l),A(e,a,t.blurAttrib),e.bindFramebuffer(e.FRAMEBUFFER,null)}class F{entries=new Map;lastReadyProgram=null;get(e){return this.entries.get(e)}setPending(e,t){this.entries.has(e)||this.entries.set(e,{status:"pending",dispatched:t})}setReady(e,t){this.entries.set(e,{status:"ready",program:t}),this.lastReadyProgram=t}setFailed(e,t){this.entries.set(e,{status:"failed",message:t})}markUsed(e){let t=this.entries.get(e);t?.status==="ready"&&(this.lastReadyProgram=t.program)}lastReady(){return this.lastReadyProgram}pendingEntries(){let e=[];for(let[t,a]of this.entries)"pending"===a.status&&e.push({key:t,dispatched:a.dispatched});return e}hasPending(){for(let e of this.entries.values())if("pending"===e.status)return!0;return!1}get size(){return this.entries.size}readyPrograms(){let e=[];for(let t of this.entries.values())"ready"===t.status&&e.push(t.program);return e}clear(){this.entries.clear(),this.lastReadyProgram=null}}let U=["u_res","u_time","u_warp","u_flow","u_scale","u_octaves","u_contrast","u_grain","u_grainsize","u_grainBlendMode","u_seed","u_shape","u_angle","u_center","u_softness","u_blur","u_aberration","u_distortion","u_distAmount","u_distCount","u_distShadows","u_distHighlights","u_distBump","u_pixelate","u_ditherMode","u_ditherMatrix","u_ditherPattern","u_ditherLevels","u_ditherStrength","u_ditherColor","u_asciiSize","u_asciiCellRatio","u_asciiStyle","u_asciiColor","u_asciiBackground","u_asciiExposure","u_asciiFill","u_asciiDensity","u_asciiScatter","u_asciiOpacity","u_asciiBlend","u_asciiCharCount","u_asciiAtlas","u_halftoneSize","u_halftoneStyle","u_halftoneStagger","u_halftoneDotScale","u_halftoneColor","u_halftoneBackground","u_halftonePaperColor","u_halftoneEmboss","u_plaidColumnSize","u_plaidRowSize","u_plaidColumnStrength","u_plaidRowStrength","u_plaidBandWidth","u_plaidBackground","u_plaidAngle","u_plaidColorMode","u_plaidInkColor","u_plaidBlendMode","u_light","u_lightAmount","u_lightSize","u_lightCenter","u_waves","u_wavesFrequency","u_wavesAmplitude","u_wavesPhase","u_wavesFalloff","u_wavesDisplace","u_wavesCenter","u_blobCount","u_blobSize","u_blobSpread","u_blobSoftness","u_blobMerge","u_blobSeed","u_blobDrift","u_blobAmount","u_blobLayout","u_blobDensity","u_blobShape","u_blobShapeAmount","u_gradientOverlay","u_blendMode","u_grainSeed","u_imageRes","u_imageScale","u_imageOffset","u_imgBrightness","u_imgContrast","u_imgSaturation","u_imgExposure","u_imgFilter","u_image","u_stopCount","u_stopPos[0]","u_stopPos[1]","u_stopPos[2]","u_stopPos[3]","u_stopPos[4]","u_stopPos[5]","u_stopPos[6]","u_stopPos[7]","u_stopCol[0]","u_stopCol[1]","u_stopCol[2]","u_stopCol[3]","u_stopCol[4]","u_stopCol[5]","u_stopCol[6]","u_stopCol[7]"];function B(e,t){t&&(e.deleteFramebuffer(t.framebuffer),e.deleteTexture(t.texture))}class D{gl;onError;buffer;sourceTexture;asciiTexture;displayTexture;programCache=new F;parallelExt;blurProgram=null;blurResources=null;exportFbo=null;lastUploadedImage=null;constructor(e,o={}){const r=e.createBuffer(),l=e.createTexture(),i=e.createTexture();if(!r||!l||!i)throw Error("Failed to create WebGL buffers");this.parallelExt=e.getExtension("KHR_parallel_shader_compile"),e.bindBuffer(e.ARRAY_BUFFER,r),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),e.STATIC_DRAW),e.enable(e.BLEND),e.blendFunc(e.SRC_ALPHA,e.ONE_MINUS_SRC_ALPHA),function(e,t,a){e.activeTexture(e.TEXTURE1),e.bindTexture(e.TEXTURE_2D,t),e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,!0),e.texImage2D(e.TEXTURE_2D,0,e.RGBA,e.RGBA,e.UNSIGNED_BYTE,a),e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,!1),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.NEAREST)}(e,i,function(){let e=document.createElement("canvas");e.width=32*a,e.height=32;let o=e.getContext("2d");if(!o)return e;o.fillStyle="#000000",o.fillRect(0,0,e.width,e.height),o.fillStyle="#ffffff",o.font=`500 ${Math.round(26.24)}px "Courier New", Courier, monospace`,o.textAlign="center",o.textBaseline="middle";for(let e=0;e<a;e++)o.fillText(t[e],(e+.5)*32,16.64);return e}()),this.gl=e,this.onError=o.onError,this.buffer=r,this.sourceTexture=l,this.asciiTexture=i,this.displayTexture=l}syncImage(e,t,a){if(e){if(e!==this.lastUploadedImage){var o,r;o=this.gl,r=this.sourceTexture,o.activeTexture(o.TEXTURE0),o.bindTexture(o.TEXTURE_2D,r),o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,!0),o.texImage2D(o.TEXTURE_2D,0,o.RGBA,o.RGBA,o.UNSIGNED_BYTE,e.canvas),o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,!1),o.texParameteri(o.TEXTURE_2D,o.TEXTURE_WRAP_S,o.CLAMP_TO_EDGE),o.texParameteri(o.TEXTURE_2D,o.TEXTURE_WRAP_T,o.CLAMP_TO_EDGE),o.texParameteri(o.TEXTURE_2D,o.TEXTURE_MIN_FILTER,o.LINEAR),o.texParameteri(o.TEXTURE_2D,o.TEXTURE_MAG_FILTER,o.LINEAR),this.lastUploadedImage=e}this.updateBlur(e,t?a:0)}else this.displayTexture=this.sourceTexture,this.lastUploadedImage=null}updateBlur(e,t){let a=this.gl;if(t<=.001){this.displayTexture=this.sourceTexture;return}this.blurProgram||(this.blurProgram=function(e){try{let t=C(e,y),a=C(e,S);if(!t||!a)return t&&e.deleteProgram(t),a&&e.deleteProgram(a),null;return{program:t,copyProgram:a,blurAttrib:e.getAttribLocation(t,"p"),copyAttrib:e.getAttribLocation(a,"p"),uImage:e.getUniformLocation(t,"u_image"),uRes:e.getUniformLocation(t,"u_res"),uDirection:e.getUniformLocation(t,"u_direction"),uSpread:e.getUniformLocation(t,"u_spread"),cImage:e.getUniformLocation(a,"u_image"),cRes:e.getUniformLocation(a,"u_res")}}catch{return null}}(a));let o=this.blurProgram;if(!o){this.displayTexture=this.sourceTexture;return}this.blurResources=function(e,t,a,o,r){if(!a)return null;if(t&&t.baseWidth===o&&t.baseHeight===r&&t.program===a)return t;t&&R(e,t);let l=[];for(let t=0;t<=5;t++){let a=Math.max(4,Math.ceil(o/2**t)),i=Math.max(4,Math.ceil(r/2**t)),s=E(e,a,i),u=E(e,a,i);if(!s||!u){s&&T(e,s),u&&T(e,u);break}if(l.push({a:s,b:u}),a<=4&&i<=4)break}return 0===l.length?null:{program:a,baseWidth:o,baseHeight:r,levels:l}}(a,this.blurResources,o,e.width,e.height);let r=this.blurResources;if(!r){this.displayTexture=this.sourceTexture;return}this.displayTexture=function(e,t,a,o,r,l,i){let s=Math.max(r,l)*(i*i*.09+.015*i);if(s<.5)return o;let u=t.levels.length-1,n=Math.floor(Math.log2(Math.max(s,1)/4));n=Math.min(Math.max(n,0),u);let f=Math.max(.6,s/2**n/1.69),c=o;for(let o=1;o<=n;o++){var p,d,m;p=t.program,d=c,m=t.levels[o].a,e.bindFramebuffer(e.FRAMEBUFFER,m.framebuffer),e.viewport(0,0,m.width,m.height),e.useProgram(p.copyProgram),e.activeTexture(e.TEXTURE0),e.bindTexture(e.TEXTURE_2D,d),e.uniform1i(p.cImage,0),e.uniform2f(p.cRes,m.width,m.height),A(e,a,p.copyAttrib),e.bindFramebuffer(e.FRAMEBUFFER,null),c=t.levels[o].a.texture}let h=t.levels[n];P(e,t.program,a,c,h.b,f,!0),P(e,t.program,a,h.b.texture,h.a,f,!1);let v=h.a.texture;for(let o=n;o>0;o--){let r=t.levels[o-1];P(e,t.program,a,v,r.b,1.3,!0),P(e,t.program,a,r.b.texture,r.a,1.3,!1),v=r.a.texture}return v}(a,r,this.buffer,this.sourceTexture,e.width,e.height,t)}resolve(e,t){try{var a;let o,r=(a=this.gl,o=e=>{throw a.deleteShader(t.vs),a.deleteShader(t.fs),a.deleteProgram(t.program),Error(e)},a.getShaderParameter(t.vs,a.COMPILE_STATUS)||o(`Shader compile error: ${a.getShaderInfoLog(t.vs)}`),a.getShaderParameter(t.fs,a.COMPILE_STATUS)||o(`Shader compile error: ${a.getShaderInfoLog(t.fs)}`),a.getProgramParameter(t.program,a.LINK_STATUS)||o(`Program link error: ${a.getProgramInfoLog(t.program)}`),a.deleteShader(t.vs),a.deleteShader(t.fs),t.program),l={program:r,uniforms:function(e,t){let a={};for(let o of U)a[o]=e.getUniformLocation(t,o);return a}(this.gl,r),attrib:this.gl.getAttribLocation(r,"p")};return this.programCache.setReady(e,l),l}catch(a){let t=a instanceof Error?a.message:"Shader compilation failed";return this.programCache.setFailed(e,t),console.error(t),this.onError?.(t),null}}isCompileDone(e){return!this.parallelExt||this.gl.getProgramParameter(e,this.parallelExt.COMPLETION_STATUS_KHR)}getProgram(e,t="block"){let a,o=(e.image?"1":"0")+(e.aberration?"1":"0")+(e.glass?"1":"0")+(e.wavesDisplace?"1":"0")+(e.dither?"1":"0")+(e.ascii?"1":"0")+(e.halftone?"1":"0")+(e.plaid?"1":"0")+(e.light?"1":"0")+(e.blobs?"1":"0")+(e.grainBlend?"1":"0"),r=this.programCache.get(o);if(r?.status==="failed")return null;if(r?.status==="ready")return this.programCache.markUsed(o),r.program;let y=r?.status==="pending"?r.dispatched:(a=function(e,t){let a,o,r=e.createShader(e.VERTEX_SHADER),y=e.createShader(e.FRAGMENT_SHADER),S=e.createProgram();if(!r||!y||!S)throw Error("Failed to create program");return e.shaderSource(r,l),e.compileShader(r),e.shaderSource(y,(a=i+s+(t.blobs?u:n)+f+c,t.wavesDisplace&&(a+=p),t.glass&&(a+=d),t.dither&&(a+=m),(t.image||t.plaid||t.grainBlend)&&(a+=h),t.image&&(a+=v),a+=(o=`
vec3 fieldColorAt(vec2 uv){
  uv = applyPixelate(uv);
${t.wavesDisplace?"  uv = wavesDisplaceUv(uv);\n":""}${t.glass?"  uv = applyDistortion(uv);\n":""}${t.image?"  return compositeUpload(uv);\n":"  return fieldColorGenerate(uv);\n"}}
`,o+`
vec3 sceneWithAberration(vec2 uv){
${t.aberration?`  vec2 dir = normalize(uv - 0.5 + 1e-5);
  float amt = u_aberration * 0.02;
  vec3 cR = fieldColorAt(uv + dir * amt);
  vec3 cG = fieldColorAt(uv);
  vec3 cB = fieldColorAt(uv - dir * amt);
  return vec3(cR.r, cG.g, cB.b);
`:"  return fieldColorAt(uv);\n"}}
`+`
vec3 colorPipelineAt(vec2 uv){
  vec3 col = sceneWithAberration(uv);
${t.glass?`  if(u_distortion == 1){ col = applyFlutedGlassShading(col, uv); }
  else if(u_distortion == 2){ col = applyMosaicGlassShading(col, uv); }
  else if(u_distortion == 3){ col = applyRippleGlassShading(col, uv); }
`:""}${t.dither?"  col = applyDitherAt(col, uv * u_res);\n":""}  return col;
}
`),t.light&&(a+=_),t.ascii&&(a+=g),t.halftone&&(a+=b),t.plaid&&(a+=x),a+=`
void main(){
  vec2 uv = gl_FragCoord.xy / u_res;
  vec3 col = colorPipelineAt(uv);
${t.light?"  col = applyLight(uv, col);\n":""}${t.plaid?"  col = applyPlaid(uv, col);\n":""}${t.halftone?"  col = applyHalftone(uv, col);\n":""}${t.ascii?"  col = applyAscii(uv, col);\n":""}  float gr = hash12(floor(gl_FragCoord.xy / max(u_grainsize, 0.5)) + u_grainSeed + mod(floor(u_time * 24.0), floor(TWO_PI * 24.0)) * 137.0) - 0.5;
${t.grainBlend?"  vec3 grainLayer = clamp(vec3(0.5 + gr), 0.0, 1.0);\n  col = mix(col, applyGradientBlend(col, grainLayer, u_grainBlendMode), u_grain);\n":"  col += gr * u_grain;\n"}
  // Sub-LSB triangular dither breaks 8-bit banding on smooth gradients. It's
  // imperceptible on screen but keeps exported PNG/video gradients buttery
  // (the encoder no longer has hard bands to blockify).
  float dth = (hash12(gl_FragCoord.xy) + hash12(gl_FragCoord.xy + 41.7) - 1.0) / 255.0;
  col += dth;
  fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
`)),e.compileShader(y),e.attachShader(S,r),e.attachShader(S,y),e.linkProgram(S),{program:S,vs:r,fs:y}}(this.gl,e),this.programCache.setPending(o,a),a);if("block"===t||this.isCompileDone(y.program)){let e=this.resolve(o,y);return e&&this.programCache.markUsed(o),e}return"fallback"===t?this.programCache.lastReady():null}pollPending(){let e=!1;for(let{key:t,dispatched:a}of this.programCache.pendingEntries())this.isCompileDone(a.program)&&(this.resolve(t,a),e=!0);return e}hasPending(){return this.programCache.hasPending()}setUniforms(e,t,l,i,s){let u=this.gl,{gradientParams:n,image:f,imageLayer:c}=t,p=null!==f&&c.enabled;u.uniform2f(e.u_res,i,s),u.uniform1f(e.u_time,l),u.uniform1f(e.u_warp,n.warp),u.uniform1f(e.u_flow,n.flow),u.uniform1f(e.u_scale,n.scale),u.uniform1i(e.u_octaves,n.detail),u.uniform1f(e.u_contrast,n.contrast),u.uniform1f(e.u_grain,n.grainEnabled?n.grain:0),u.uniform1f(e.u_grainsize,n.grainSize),u.uniform1i(e.u_grainBlendMode,n.grainBlendMode),u.uniform1f(e.u_seed,n.seed),u.uniform1f(e.u_grainSeed,n.seed),u.uniform1i(e.u_shape,n.shape),u.uniform1f(e.u_angle,n.angle),u.uniform2f(e.u_center,n.centerX,n.centerY),u.uniform1f(e.u_softness,n.softness),u.uniform1f(e.u_blur,0),u.uniform1f(e.u_gradientOverlay,p?c.opacity:0),u.uniform1i(e.u_blendMode,p?c.blendMode:0),u.uniform1f(e.u_imgBrightness,p?c.brightness:0),u.uniform1f(e.u_imgContrast,p?c.contrast:1),u.uniform1f(e.u_imgSaturation,p?c.saturation:1),u.uniform1f(e.u_imgExposure,p?c.exposure:0),u.uniform1i(e.u_imgFilter,p?c.filter:0),u.uniform1f(e.u_aberration,n.aberration),u.uniform1i(e.u_distortion,n.distortion),u.uniform1f(e.u_distAmount,n.distAmount),u.uniform1f(e.u_distCount,n.distCount),u.uniform1f(e.u_distShadows,n.distShadows),u.uniform1f(e.u_distHighlights,n.distHighlights),u.uniform1f(e.u_distBump,n.distBump),u.uniform1f(e.u_pixelate,n.pixelate),u.uniform1i(e.u_ditherMode,n.ditherMode),u.uniform1i(e.u_ditherMatrix,n.ditherMatrix),u.uniform1f(e.u_ditherPattern,n.ditherPattern),u.uniform1f(e.u_ditherLevels,n.ditherLevels),u.uniform1f(e.u_ditherStrength,n.ditherStrength),u.uniform1i(e.u_ditherColor,+!!n.ditherColor),u.uniform1f(e.u_asciiSize,n.asciiSize),u.uniform1f(e.u_asciiCellRatio,n.asciiCellRatio),u.uniform1i(e.u_asciiStyle,n.asciiStyle),u.uniform1i(e.u_asciiColor,+!!n.asciiColor),u.uniform1f(e.u_asciiBackground,n.asciiBackground),u.uniform1f(e.u_asciiExposure,n.asciiExposure),u.uniform1f(e.u_asciiFill,n.asciiFill),u.uniform1f(e.u_asciiDensity,n.asciiDensity),u.uniform1f(e.u_asciiScatter,n.asciiScatter),u.uniform1f(e.u_asciiOpacity,n.asciiOpacity),u.uniform1i(e.u_asciiBlend,n.asciiBlend),u.uniform1f(e.u_asciiCharCount,a),u.uniform1f(e.u_halftoneSize,n.halftoneSize),u.uniform1i(e.u_halftoneStyle,n.halftoneStyle),u.uniform1i(e.u_halftoneStagger,+!!n.halftoneStagger),u.uniform1f(e.u_halftoneDotScale,n.halftoneDotScale),u.uniform1i(e.u_halftoneColor,+!!n.halftoneColor),u.uniform1f(e.u_halftoneBackground,n.halftoneBackground);{let[t,a,o]=r(n.halftonePaperColor);u.uniform3f(e.u_halftonePaperColor,t,a,o)}u.uniform1f(e.u_halftoneEmboss,n.halftoneEmboss),u.uniform1f(e.u_plaidColumnSize,n.plaidColumnSize),u.uniform1f(e.u_plaidRowSize,n.plaidRowSize),u.uniform1f(e.u_plaidColumnStrength,n.plaidColumnStrength),u.uniform1f(e.u_plaidRowStrength,n.plaidRowStrength),u.uniform1f(e.u_plaidBandWidth,n.plaidBandWidth),u.uniform1f(e.u_plaidBackground,n.plaidBackground),u.uniform1f(e.u_plaidAngle,n.plaidAngle),u.uniform1i(e.u_plaidColorMode,+!!n.plaidColorMode);{let[t,a,o]=r(n.plaidInkColor);u.uniform3f(e.u_plaidInkColor,t,a,o)}u.uniform1i(e.u_plaidBlendMode,n.plaidBlendMode),u.uniform1i(e.u_light,n.light),u.uniform1f(e.u_lightAmount,n.lightAmount),u.uniform1f(e.u_lightSize,n.lightSize),u.uniform2f(e.u_lightCenter,n.lightCenterX,n.lightCenterY),u.uniform1i(e.u_waves,+!!n.waves),u.uniform1f(e.u_wavesFrequency,n.wavesFrequency),u.uniform1f(e.u_wavesAmplitude,n.wavesAmplitude),u.uniform1f(e.u_wavesPhase,n.wavesPhase),u.uniform1f(e.u_wavesFalloff,n.wavesFalloff),u.uniform1f(e.u_wavesDisplace,n.wavesDisplace),u.uniform2f(e.u_wavesCenter,n.wavesCenterX,n.wavesCenterY),u.uniform1i(e.u_blobCount,Math.round(n.blobCount)),u.uniform1f(e.u_blobSize,n.blobSize),u.uniform1f(e.u_blobSpread,n.blobSpread),u.uniform1f(e.u_blobSoftness,n.blobSoftness),u.uniform1f(e.u_blobMerge,n.blobMerge),u.uniform1f(e.u_blobSeed,n.blobSeed),u.uniform1f(e.u_blobDrift,n.blobDrift),u.uniform1f(e.u_blobAmount,n.blobs?n.blobAmount:0),u.uniform1i(e.u_blobLayout,n.blobLayout),u.uniform1f(e.u_blobDensity,n.blobDensity),u.uniform1i(e.u_blobShape,n.blobShape),u.uniform1f(e.u_blobShapeAmount,n.blobShapeAmount);let d=(0,o.normalizeColorStops)(n.colorStops);u.uniform1i(e.u_stopCount,d.length);for(let t=0;t<o.MAX_COLOR_STOPS;t++){let a=e[`u_stopPos[${t}]`],o=e[`u_stopCol[${t}]`];if(t<d.length){let[e,l,i]=r(d[t].color);a&&u.uniform1f(a,d[t].position),o&&u.uniform3f(o,e,l,i)}else if(a&&o){let e=d[d.length-1],[t,l,i]=r(e.color);u.uniform1f(a,e.position),u.uniform3f(o,t,l,i)}}this.asciiTexture&&(u.activeTexture(u.TEXTURE1),u.bindTexture(u.TEXTURE_2D,this.asciiTexture),u.uniform1i(e.u_asciiAtlas,1)),p&&this.displayTexture&&f&&(u.activeTexture(u.TEXTURE0),u.bindTexture(u.TEXTURE_2D,this.displayTexture),u.uniform1i(e.u_image,0),u.uniform2f(e.u_imageRes,f.width,f.height),u.uniform1f(e.u_imageScale,Math.max(c.scale,.01)),u.uniform2f(e.u_imageOffset,c.offsetX,-c.offsetY))}paint(e,t,a,o,r=null,l="block"){let i=this.gl;if(a<=0||o<=0)return!1;let{gradientParams:s,image:u,imageLayer:n}=e,f={image:null!==u&&n.enabled,aberration:s.aberration>.001,glass:0!==s.distortion,wavesDisplace:s.wavesDisplace>0,dither:s.dither,ascii:s.ascii,halftone:s.halftone,plaid:s.plaid,light:0!==s.light,blobs:s.blobs,grainBlend:s.grainEnabled&&0!==s.grainBlendMode},c=this.getProgram(f,l);return!!c&&!(c.attrib<0)&&(i.bindFramebuffer(i.FRAMEBUFFER,r),i.viewport(0,0,a,o),i.clearColor(0,0,0,0),i.clear(i.COLOR_BUFFER_BIT),i.useProgram(c.program),this.setUniforms(c.uniforms,e,t,a,o),i.bindBuffer(i.ARRAY_BUFFER,this.buffer),i.enableVertexAttribArray(c.attrib),i.vertexAttribPointer(c.attrib,2,i.FLOAT,!1,0,0),i.drawArrays(i.TRIANGLES,0,3),i.bindFramebuffer(i.FRAMEBUFFER,null),!0)}renderExport(e,t,a,o){let r=this.gl;if(t<=0||a<=0)return null;let l=function(e,t,a,o){if(t?.width===a&&t.height===o)return t;B(e,t);let r=e.createFramebuffer(),l=e.createTexture();if(!r||!l)return null;e.bindTexture(e.TEXTURE_2D,l),e.texImage2D(e.TEXTURE_2D,0,e.RGBA,a,o,0,e.RGBA,e.UNSIGNED_BYTE,null),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.LINEAR),e.bindFramebuffer(e.FRAMEBUFFER,r),e.framebufferTexture2D(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,l,0);let i=e.checkFramebufferStatus(e.FRAMEBUFFER)===e.FRAMEBUFFER_COMPLETE;return(e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindTexture(e.TEXTURE_2D,null),i)?{framebuffer:r,texture:l,width:a,height:o}:(e.deleteFramebuffer(r),e.deleteTexture(l),null)}(r,this.exportFbo,t,a);l&&(this.exportFbo=l);let i=l&&this.paint(e,o,t,a,l.framebuffer)?l:null,s=null;return i&&(r.bindFramebuffer(r.FRAMEBUFFER,i.framebuffer),s=function(e,t,a){let o=new Uint8Array(t*a*4);e.readPixels(0,0,t,a,e.RGBA,e.UNSIGNED_BYTE,o);let r=4*t,l=new Uint8Array(r);for(let e=0;e<Math.floor(a/2);e++){let t=e*r,i=(a-e-1)*r;l.set(o.subarray(t,t+r)),o.copyWithin(t,i,i+r),o.set(l,i)}let i=document.createElement("canvas");i.width=t,i.height=a;let s=i.getContext("2d");if(!s)return null;let u=s.createImageData(t,a);return u.data.set(o),s.putImageData(u,0,0),i}(r,t,a),r.bindFramebuffer(r.FRAMEBUFFER,null)),s}dispose(){let e=this.gl;for(let t of this.programCache.readyPrograms())e.deleteProgram(t.program);if(this.programCache.clear(),B(e,this.exportFbo),this.exportFbo=null,R(e,this.blurResources),this.blurResources=null,this.blurProgram){var t;(t=this.blurProgram)&&(e.deleteProgram(t.program),e.deleteProgram(t.copyProgram)),this.blurProgram=null}e.deleteBuffer(this.buffer),e.deleteTexture(this.sourceTexture),e.deleteTexture(this.asciiTexture)}}e.s(["GradientEngine",0,D],73667)}]);